## ---- echo=FALSE, message=FALSE-----------------------------------------------
library(knitr)
library(rMQanalysis)
data("proteinGroups")
pg <- proteinGroups
# opts_chunk$set(fig.width=7, # standard figure size
#                fig.height=5, 
# #                fig.path='figs/', # directory for the high quality images
#                echo=TRUE, # set to FALSE to remove the code output
#                eval=TRUE,
#                warning=FALSE, 
#                message=FALSE)

## ---- eval=FALSE--------------------------------------------------------------
#  pg <- read.delim('proteinGroups.txt')

## -----------------------------------------------------------------------------
dim(pg)
names(pg)
# summary(pg)

## -----------------------------------------------------------------------------
table(pg$Number.of.proteins)
barplot(table(pg$Number.of.proteins))

## ---- fig.show='hold'---------------------------------------------------------
plot(1:10)
plot(10:1)

## ---- echo=FALSE, results='asis'----------------------------------------------
knitr::kable(head(mtcars, 10))

