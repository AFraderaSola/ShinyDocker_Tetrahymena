###############################################################################
#
# Execute these commands once you installed a new version of R and/or RStudio
#
# developer: Mario Dejung <m.dejung@imb.de>
# version: 0.0.1
# date: 2018.02.12
#
###############################################################################
install.packages(c(
  "plotly", 
  "RColorBrewer", 
  "sp", 
  "tidyverse", 
  "plyr", 
  "reshape2", 
  "zoo", 
  "grid", 
  "gridExtra", 
  "gplots", 
  "splitstackshape", 
  "scales", 
  "logspline", 
  "data.table", 
  "readr", 
  "R6", 
  "ggrepel", 
  "stringr", 
  "testthat", 
  "knitr", 
  "cfpscripts",
  "markdown",
  "seqinr",
  "GGally",
  "rjson",
  "NMF",
  "logging", 
  "xlsx"
)
)

source("https://bioconductor.org/biocLite.R")
biocLite("BiocStyle")
biocLite("mzR")



