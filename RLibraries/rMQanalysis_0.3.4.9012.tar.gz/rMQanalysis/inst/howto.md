rMQanalysis - automize MaxQuant downstream analysis
========================================================
author: Mario Dejung  
date: 2017.03.30
autosize: true




MaxQuant - the quantitative proteomics software package
========================================================

- It is free
- It is straight forward and fool proof
- Give reliable results
- My boss is a former Mann PostDoc :-)

For more details on MaxQuant check <http://www.biochem.mpg.de/5111795/maxquant>.



Perseus - Proteomics downstream Analysis
========================================================

- It is free 
- For non computer scientists
- NOT automizable


For more details on Perseus check <http://www.biochem.mpg.de/5111810/perseus>


rMQanalysis - create workflows for downstream analysis
========================================================

- identify standard tasks and create functions
- plotting nice pictures for analysis
- handling missing values


read MaxQuant output files
========================================================

Using `readr` package for quick file loading.


```r
pg <- read_MQtsv(file.path(mq_data, 'proteinGroups.txt'))
```

Working on file chunks is also possible.


```r
my_subset_f <- function(x, pos) subset(x, Peptides > 5)
pg <- read_MQtsv(file.path(mq_data, 'proteinGroups.txt'), my_subset_f)
```

- handling the correct columns as numeric, text, factor, etc



filter protein group files
=======================================================

- filtering contaminants, reverse binders and only identified by site


```r
pg_flt <- filterWholeDataset(pg, by_contaminant=TRUE, by_reverse=TRUE, by_bysite=TRUE)
```

- check for identified proteins

```r
pg_ident <- filterIdentifiedProteins(pg_flt, razor=2, unique=1)
sapply(list(pg=pg, pg_flt=pg_flt, dpg_ident=pg_ident), nrow)
```

```
       pg    pg_flt dpg_ident 
     5294      5017      4805 
```

Filter peptides
=======================================================

Can do the same for peptides


```r
peptides <- read_MQtsv(file.path(mq_data, 'peptides.txt'))
peptides_flt <- filterWholeDataset(peptides)
```

```
2017-03-29 16:57:29 WARN: Column "Only.identified.by.site" does not exist in this data.frame!
2017-03-29 16:57:29 WARN: Column "Only.identified.by.site" was not filtered!
```



missed cleavage analysis
=======================================================


```r
mc_data <- getMissedCleavageDF(peptides_flt)
plotMissedCleavages(mc_data, enzyme='Trypsin')
```

<img src="howto-figure/unnamed-chunk-7-1.png" title="plot of chunk unnamed-chunk-7" alt="plot of chunk unnamed-chunk-7" style="display: block; margin: auto;" />


Abundance analysis
=======================================================


```r
plotAbundanceRank(pg_ident)
```

<img src="howto-figure/unnamed-chunk-8-1.png" title="plot of chunk unnamed-chunk-8" alt="plot of chunk unnamed-chunk-8" style="display: block; margin: auto;" />


Imputing methods
=======================================================
Handling missing values by imputing

- normal distribution (modify mean, sd factor)
- beta distribution (start, end)

First replace `0` by `NA` and log2 transform

```r
pg_ident <- replaceValueInColumn(pg_ident, '^LFQ', 0, NA)
pg_ident <- 
  cbind(pg_ident,
        log2=log2(pg_ident[
          getColumnIndex(pg_ident, '^LFQ')
          ]))
log2_lfq_cols <- grep('^log2.LFQ', names(pg_ident))
```



Normal distribution
=======================================================
- measure mean and standard deviation of each replicate
- modify the `mean` (normally reducing) and the lower the `sd`
- depends strongly on `modify_mean`

```r
norm_imputed_values <- 
  imputeNormRandomNumbersPerColumn(
           pg_ident[log2_lfq_cols],
           modify_mean=-2, sd_factor=.3)
```

```
2017-03-30 07:22:09 INFO: modify_mean "-2" will be used instead of reduce_mean
```



Imputed values
=======================================================

```r
imphist <- dplyr::filter(norm_imputed_values$imputed_histogram,
                  grepl('\\.0h_', column))
plotImputedValues(imphist, ncol=4)
```

<img src="howto-figure/unnamed-chunk-11-1.png" title="plot of chunk unnamed-chunk-11" alt="plot of chunk unnamed-chunk-11" style="display: block; margin: auto;" />



beta distribution
=======================================================
- define a start and end point as percentile
- always in a *good* range since depends on measured values

```r
beta_imputed_values <- 
  imputeBetaRandomNumbersPerColumn(
           pg_ident[log2_lfq_cols],
           start=.01, end=.05)
```



Imputed values
=======================================================



```r
plotImputedValues(imphist, ncol=4)
```

<img src="howto-figure/unnamed-chunk-14-1.png" title="plot of chunk unnamed-chunk-14" alt="plot of chunk unnamed-chunk-14" style="display: block; margin: auto;" />


integrate the imputed values
=======================================================


```r
pg_ident <- cbind(pg_ident,
                  beta_imputed_values$imputed_values)
plotImputedBars(beta_imputed_values$imputed_histogram)
```

<img src="howto-figure/unnamed-chunk-15-1.png" title="plot of chunk unnamed-chunk-15" alt="plot of chunk unnamed-chunk-15" style="display: block; margin: auto;" />


Calculating averages
=======================================================

- calculating `mean1` of measured values
- calculating `mean2` of measured and imputed values
- calculating `mean3` of imputed if no measured value
- caclulating `value_count` for each experiment
- calculating the same for median


```r
pg_ident <- calculateAverages(pg_ident)
```

Why all these values
=======================================================

![no text](missing.png)

Analysing quantification
=======================================================

```r
countProteinGroups(pg, pg_flt, pg_ident)$plot
```

<img src="howto-figure/unnamed-chunk-17-1.png" title="plot of chunk unnamed-chunk-17" alt="plot of chunk unnamed-chunk-17" style="display: block; margin: auto;" />


Filtering quantification
=======================================================

Proteins with 2 LFQ values in minimum 1 experiment are marked as quantified.


```r
pg_quant <- 
    pg_ident[apply(
      pg_ident[grep('value_count',names(pg_ident))] >= 2,
      1,
      any),]
```



Correlation heatmap
=======================================================


```r
plotReplicateCorrelation(pg_ident)()
```

<img src="howto-figure/unnamed-chunk-19-1.png" title="plot of chunk unnamed-chunk-19" alt="plot of chunk unnamed-chunk-19" style="display: block; margin: auto;" />



Principal component analysis
=======================================================



```r
prcomp_list <- 
  list(the=prcomp(t(na.omit(pg_quant[,pca_columns])), 
                  scale.=TRUE))
multiPCAPlot('the', prcomp_list, TRUE)
```

<img src="howto-figure/unnamed-chunk-21-1.png" title="plot of chunk unnamed-chunk-21" alt="plot of chunk unnamed-chunk-21" style="display: block; margin: auto;" />

```
TableGrob (2 x 2) "arrange": 3 grobs
  z     cells    name                grob
1 1 (2-2,1-1) arrange     gtable[arrange]
2 2 (2-2,2-2) arrange   gtable[guide-box]
3 3 (1-1,1-2) arrange text[GRID.text.368]
```


Some convenient functions I
=======================================================


```r
getExperiments(pg)
```

```
[1] "0h"  "12h" "24h" "2h"  "48h" "4h"  "6h"  "LS"  "PC" 
```

```r
head(
  getLabel(pg_ident, 'Gene.names', 'Protein.IDs', fallback_regex='([^;]+);.*')
  )
```

```
[1] "Tb927.5.4450" "Tb927.5.4460" "Tb927.5.4470" "Tb927.5.4480"
[5] "Tb927.5.4500" "Tb927.5.4530"
```

```r
copySourcedScript()
```


Some convenient functions II
=======================================================


```r
jnk <- mixupProteinGroups(pg_ident)
head(
  splitColumnBySep(pg_ident[,c('Protein.IDs','id')], 'Protein.IDs')
)
```

```
    Protein.IDs  id
1: Tb927.5.4450 235
2: Tb05.5K5.100 235
3: Tb927.5.4460 236
4: Tb05.5K5.110 236
5: Tb11.v5.0866 236
6: Tb927.5.4470 237
```


Multiple species
=======================================================

- Most of the functions work with multiple species
- Show files in folder.


