library(testthat)
library(rMQanalysis)

test_check("rMQanalysis")

