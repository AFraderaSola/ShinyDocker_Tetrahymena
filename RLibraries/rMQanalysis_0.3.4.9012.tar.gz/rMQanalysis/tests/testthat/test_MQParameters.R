context("MQParameters")

parameters_file <- 'parameters.txt'
test_data <- data.frame(
  Parameter = c("Version", "Date of writing", "Re-quantify", "Match between runs", "Fasta file"), 
  Value = c("1.5.2.8", "01/12/2016 08:31:23", "False", "False", 
            "E:\\Fasta_UNIPROT\\Arabidopsis_thaliana_(ARATH)_Uniprot_20170123.fasta;E:\\Fasta_UNIPROT\\Escherichia_coli_(ECOLI)_Uniprot_(strain_K12)_20170123.fasta"))
write.table(test_data, parameters_file, sep='\t', row.names=FALSE, col.names=TRUE)


test_that('getVersion returns the correct version', {
  p <- MQParameters$new(parameters_file)
  expect_equal(p$getVersion(), "1.5.2.8")
})

test_that('getTimestamp returns the time object', {
  p <- MQParameters$new(parameters_file)
  expect_equal(p$getTimestamp(), 
               as.POSIXlt("01/12/2016 08:31:23", 
                          format='%m/%d/%Y %H:%M:%S'))
})


test_that('getMatchBetweenRuns returns the correct setting', {
  p <- MQParameters$new(parameters_file)
  expect_equal(p$getMatchBetweenRuns(), FALSE)
})


test_that('getReQuantify returns the correct setting', {
  p <- MQParameters$new(parameters_file)
  expect_equal(p$getReQuantify(), FALSE)
})


test_that('getFastaFile returns the correct files', {
  p <- MQParameters$new(parameters_file)
  fastas <- p$getFastaFile()
  expect_equal(length(fastas), 2)
  expect_equal(fastas,
               c('E:/Fasta_UNIPROT/Arabidopsis_thaliana_(ARATH)_Uniprot_20170123.fasta',
                 'E:/Fasta_UNIPROT/Escherichia_coli_(ECOLI)_Uniprot_(strain_K12)_20170123.fasta'))
})

test_that('getFastaFile can change basedir', {
  p <- MQParameters$new(parameters_file)
  fastas <- p$getFastaFile(alternative_dirs='/Volumes/Proteomics-Data/Fasta_UNIPROT')
  expect_equal(length(fastas), 2)
  expect_equal(fastas,
               c('/Volumes/Proteomics-Data/Fasta_UNIPROT/Arabidopsis_thaliana_(ARATH)_Uniprot_20170123.fasta',
                 '/Volumes/Proteomics-Data/Fasta_UNIPROT/Escherichia_coli_(ECOLI)_Uniprot_(strain_K12)_20170123.fasta'))
})












file.remove(parameters_file)


