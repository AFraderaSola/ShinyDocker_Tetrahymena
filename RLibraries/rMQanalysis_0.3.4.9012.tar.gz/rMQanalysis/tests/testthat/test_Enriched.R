context("Enriched")
options(rMQanalysis.dbg_level = 0)
set.seed(1234)
df <- 
  data.frame(gene_names=c(letters[1:25],LETTERS[1:25]),
             difference=rnorm(500, 0, 10),
             log10_pvalue=abs(rnorm(500,1,5)))

test_that('Enriched has the correct values for pvalue 0.05', {  
  enriched <- Enriched(df[c(2,3)], pvalue=0.05)
  expect_that(327, equals(sum(enriched$enriched)))
  expect_that(173, equals(sum(enriched$background)))
  expect_that(155, equals(sum(enriched$positive)))
  expect_that(172, equals(sum(enriched$negative)))
})

test_that('Enriched has the correct values for pvalue 0.01', {  
  enriched <- Enriched(df[c(2,3)], pvalue=0.01)
  expect_that(278, equals(sum(enriched$enriched)))
  expect_that(222, equals(sum(enriched$background)))
  expect_that(133, equals(sum(enriched$positive)))
  expect_that(145, equals(sum(enriched$negative)))
})

test_that('Enriched has the correct values for pvalue 0.01 and s0 2.5 ', {  
  enriched <- Enriched(df[c(2,3)], s0=2.5, pvalue=0.01)
  expect_that(248, equals(sum(enriched$enriched)))
  expect_that(252, equals(sum(enriched$background)))
  expect_that(118, equals(sum(enriched$positive)))
  expect_that(130, equals(sum(enriched$negative)))
})


