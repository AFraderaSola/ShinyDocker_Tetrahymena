context("convertFileString")
options(rMQanalysis.dbg_level = 0)

test_that('/Volumes/Proteomics-Data is mounted', {
  expect_true(dir.exists('/Volumes/Proteomics-Data/'),
              info='"/Volumes/Proteomics-Data" is not mounted!')
}) 

test_that('convertFileString can handle a single existing file', {
  expect_equal(convertFileString('test_convertFileString.R'),
               c('test_convertFileString.R'))
})

test_that('convertFileString can handle two existing files', {
  expect_equal(
    convertFileString('test_convertFileString.R;test_convertFileString.R'),
               c('test_convertFileString.R','test_convertFileString.R'))
})

test_that('convertFileString suppresses the not existing file', {
  test_string <- 'test_convertFileString.R;test_TESTTEST.R'
  expect_warning(result <- convertFileString(test_string), 'test_TESTTEST.R')
  expect_identical(result,
                   c('test_convertFileString.R'))
})

test_that('convertFileString searches at alternative_path', {
  test_string <- 'test_convertFileString.R;testthat.R'
  expect_equal(
    convertFileString(test_string, alternative_path='..'),
    c('test_convertFileString.R', '../testthat.R'))
  expect_warning(convertFileString(test_string), 'testthat.R')
})

test_that('convertFileString searches at MQFASTADIR and alternative path', {
  test_string <- 'test_convertFileString.R;testthat.R;MOUSE.fasta'
  expect_equal(
    convertFileString(test_string, alternative_path='..'),
    c('test_convertFileString.R', '../testthat.R', 
      file.path(getOption('MQFASTADIR'), 'MOUSE.fasta')))
})

test_that('convertFileString searches at MQFASTADIR path', {
  test_string <- 'test_convertFileString.R;MOUSE.fasta'
  expect_equal(
    convertFileString(test_string),
    c('test_convertFileString.R', 
      file.path(getOption('MQFASTADIR'), 'MOUSE.fasta')))
})

test_that('convertFileString searches at MQFASTADIR path', {
  test_string <- 'test_convertFileString.R;MOUSE.fasta'
  expect_equal(
    convertFileString(test_string),
    c('test_convertFileString.R', 
      file.path(getOption('MQFASTADIR'), 'MOUSE.fasta')))
})

