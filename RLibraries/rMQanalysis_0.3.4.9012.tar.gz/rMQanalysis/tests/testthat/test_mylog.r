context("mylog")

test_that('mylog works as expected', {
  options(rMQanalysis.dbg_level = Inf)
  expect_that(mylog('test'), prints_text('INFO: test'))
  expect_that(mylog('test','WARN'), prints_text('WARN: test'))
  expect_that(mylog('test','a'), prints_text('a: test'))
})