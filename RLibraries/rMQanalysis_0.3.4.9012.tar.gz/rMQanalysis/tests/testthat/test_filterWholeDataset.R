context("filterWholeDataset")
options(rMQanalysis.dbg_level = 0)

test_that('filterWholeDataset works as expected', {
  proteinGroups_withNA <- read.delim(
    system.file('extdata', 'proteinGroups_withNA.txt', package = 'rMQanalysis' ))
  proteinGroups_noNA <- read.delim(
    system.file('extdata', 'proteinGroups_noNA.txt', package = 'rMQanalysis' ))
  
  expect_that(80, equals(nrow(filterWholeDataset(proteinGroups_noNA,by_reverse=F,by_bysite=F,by_contaminant=T))))
  expect_that(80, equals(nrow(filterWholeDataset(proteinGroups_noNA,by_reverse=F,by_bysite=T,by_contaminant=F))))
  expect_that(78, equals(nrow(filterWholeDataset(proteinGroups_noNA,by_reverse=T,by_bysite=F,by_contaminant=F))))
  expect_that(58, equals(nrow(filterWholeDataset(proteinGroups_noNA,by_reverse=T,by_bysite=T,by_contaminant=T))))
  expect_that(70, equals(nrow(filterWholeDataset(proteinGroups_noNA,by_reverse=T,by_bysite=T,by_contaminant=F))))
  expect_that(64, equals(nrow(filterWholeDataset(proteinGroups_noNA,by_reverse=T,by_bysite=F,by_contaminant=T))))
  expect_that(68, equals(nrow(filterWholeDataset(proteinGroups_noNA,by_reverse=F,by_bysite=T,by_contaminant=T))))
  expect_that(95, equals(nrow(filterWholeDataset(proteinGroups_noNA,by_reverse=F,by_bysite=F,by_contaminant=F))))
  
  expect_that(var <- nrow(filterWholeDataset(proteinGroups_withNA,by_reverse=T,by_bysite=F,by_contaminant=F)), 
              prints_text('\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2} WARN: There are "NAs" in column ".*" and will not be filtered.'))
  expect_that(var, equals(95))
  expect_that(var <- nrow(filterWholeDataset(proteinGroups_withNA,by_reverse=F,by_bysite=T,by_contaminant=F)), 
              prints_text('\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2} WARN: There are "NAs" in column ".*" and will not be filtered.'))
  expect_that(var, equals(95))
  
  expect_that(80, equals(nrow(filterWholeDataset(proteinGroups_withNA,by_reverse=F,by_bysite=F,by_contaminant=T))))
})
