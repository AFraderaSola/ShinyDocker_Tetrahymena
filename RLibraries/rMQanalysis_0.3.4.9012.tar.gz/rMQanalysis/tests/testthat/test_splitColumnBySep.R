context("splitColumnBySep")
options(rMQanalysis.dbg_level = 0)
jnk <- data.frame(a=c('1;2;3','2;3'),
                  b=c('a;b;c','a;b'),
                  c=c(5,4))


test_that('splitColumnBySep uses the original cSplit function', { 
  expect_that(splitColumnBySep(jnk, 'a'), 
              equals(cSplit(jnk, 'a', ';', 'long')))
})

# test_that('splitColumnBySep uses drop=FALSE AND direction="long"', { 
#   expected_result <- data.frame(a=c(1,2,3,2,3),
#                                 b=c('a;b;c','a;b;c','a;b;c','a;b','a;b'),
#                                 c=c(5,5,5,4,4),
#                                 a_orig=c('1;2;3','1;2;3','1;2;3','2;3','2;3'))
#   expect_that(splitColumnBySep(jnk, 'a', drop=FALSE), 
#               equals(expected_result))
# })