context("plotRatioScatter")

pg <- 
  read.delim(system.file('extdata', 
                         'SILAC_1to3_proteinGroups.txt', 
                         package='rMQanalysis'))
pg$my_label <- getLabel(pg, 'Gene.names', 'Protein.IDs', '([^;]+).*', '([^;]+).*')


test_that('plotRatioScatter works with sample data', {
  expect_error(plotRatioScatter(pg, labels='my_label', experiment=''), 
              NA)
})