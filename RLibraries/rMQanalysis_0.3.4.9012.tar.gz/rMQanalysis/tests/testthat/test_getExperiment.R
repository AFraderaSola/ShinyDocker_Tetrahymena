context('getExpermints')
df_list <- list(Intensity=1,
                `Intensity exp`=1,
                `Intensity exp1_1`=1,
                `Intensity exp1_2`=1,
                `Intensity exp1_3`=1,
                `Intensity exp2`=1,
                `Intensity exp3_1`=1,
                `Intensity exp3_2`=1,
                `Intensity exp3_4`=1,
                `Intensity exp4 1`=1,
                `Intensity exp4 2`=1,
                `Intensity exp4 3`=1)
df_no_check <- as.data.frame(df_list, check.names=FALSE)
df_with_check <- as.data.frame(df_list)
df_names_no_check <- names(df_no_check)
df_names_with_check <- names(df_with_check)

test_that('getExpermint can handle data frames with name.check=TRUE', {
  df_correct_names <- df_with_check[,c(3:5,7:9)]
  expect_equal(getExperiments(df_correct_names),
               c('exp1','exp3'))
})

test_that('getExpermint trows error on missing replicate number', {
  expect_error(getExperiments(df_with_check))
})