context("AA")
options(rMQanalysis.dbg_level = 0)
test_that('AA works as expected', {
  expect_that('Arginine', equals(AA('R')))
  expect_that('Arg', equals(AA('R','three')))
  expect_that('R', equals(AA('R','one')))
  expect_that('Arginine', equals(AA('R','full')))
  expect_that('Aspartic', equals(AA('Aspartic')))
  expect_that('Asp', equals(AA('Aspartic','three')))
  expect_that('D', equals(AA('D','one')))
  expect_that('Aspartic', equals(AA('D','full')))
  
})
