context("calculateAverages")
options(rMQanalysis.dbg_level = 0)
df <- data.frame(
  log2.LFQ.intensity.SDC_1=   c(28,  NA,  25),
  log2.LFQ.intensity.SDC_2=   c(27,  NA,  26),
  log2.LFQ.intensity.SDC_3=   c(27.8,NA,  25.6),
  log2.LFQ.intensity.SDCme_1= c(24,  23,  NA),
  log2.LFQ.intensity.SDCme_2= c(24.6,24,  NA),
  log2.LFQ.intensity.SDCme_13=c(24.2,23.2,25))
impute_value <- 17
imputed_beta_values <-
  imputeBetaRandomNumbersPerColumn(df[grep('^log2.LFQ', names(df))],
                                   impute_value,impute_value,seed=1234)
df <- cbind(df,imputed_beta_values$imputed_values)
df_result <- calculateAverages(df)

test_that('calculateAverages calculates the correct value_counts', {  
  SDC <- c(3,0,3)
  SDCme <- c(3,3,1)
  expect_that(SDC, equals(df_result$value_count_SDC))
  expect_that(SDCme, equals(df_result$value_count_SDCme))
})

test_that('calculateAverages calculates the correct mean_meas_imp', {  
  SDC <- c(mean(c(28.0,27.0,27.8)),
           mean(c(impute_value,impute_value,impute_value)),
           mean(c(25,26,25.6)))
  SDCme <- c(mean(c(24,24.6,24.2)),
             mean(c(23,24,23.2)),
             mean(c(impute_value,impute_value,25)))
  expect_that(SDC, equals(df_result$mean2_naimp_meas_SDC))
  expect_that(SDCme, equals(df_result$mean2_naimp_meas_SDCme))
})

test_that('calculateAverages calculates the correct median_meas_imp', {  
  SDC <- c(median(c(28.0,27.0,27.8)),
           median(c(impute_value,impute_value,impute_value)),
           median(c(25,26,25.6)))
  SDCme <- c(median(c(24,24.6,24.2)),
             median(c(23,24,23.2)),
             median(c(impute_value,impute_value,25)))
  expect_that(SDC, equals(df_result$median2_naimp_meas_SDC))
  expect_that(SDCme, equals(df_result$median2_naimp_meas_SDCme))
})

test_that('calculateAverages calculates the correct mean_meas', {  
  SDC <- c(mean(c(28.0,27.0,27.8), na.rm=TRUE),
           mean(c(NA,NA,NA), na.rm=TRUE),
           mean(c(25,26,25.6), na.rm=TRUE))
  SDCme <- c(mean(c(24,24.6,24.2), na.rm=TRUE),
             mean(c(23,24,23.2), na.rm=TRUE),
             mean(c(NA,NA,25), na.rm=TRUE))
  expect_that(SDC, equals(df_result$mean1_meas_SDC))
  expect_that(SDCme, equals(df_result$mean1_meas_SDCme))
})


test_that('calculateAverages calculates the correct median_meas', {  
  SDC <- c(median(c(28.0,27.0,27.8), na.rm=TRUE),
           median(c(NA,NA,NA), na.rm=TRUE),
           median(c(25,26,25.6), na.rm=TRUE))
  SDCme <- c(median(c(24,24.6,24.2), na.rm=TRUE),
             median(c(23,24,23.2), na.rm=TRUE),
             median(c(NA,NA,25), na.rm=TRUE))
  expect_that(SDC, equals(df_result$median1_meas_SDC))
  expect_that(SDCme, equals(df_result$median1_meas_SDCme))
})

test_that('calculateAverages calculates the correct mean_meas_only1', {  
  SDC <- c(mean(c(28.0,27.0,27.8), na.rm=TRUE),
           mean(c(impute_value,impute_value,impute_value), na.rm=TRUE),
           mean(c(25,26,25.6), na.rm=TRUE))
  SDCme <- c(mean(c(24,24.6,24.2), na.rm=TRUE),
             mean(c(23,24,23.2), na.rm=TRUE),
             mean(c(NA,NA,25), na.rm=TRUE))
  expect_that(SDC, equals(df_result$mean3_less1_imp_SDC))
  expect_that(SDCme, equals(df_result$mean3_less1_imp_SDCme))
})


test_that('calculateAverages calculates the correct median_meas_only1', {  
  SDC <- c(median(c(28.0,27.0,27.8), na.rm=TRUE),
           median(c(impute_value,impute_value,impute_value), na.rm=TRUE),
           median(c(25,26,25.6), na.rm=TRUE))
  SDCme <- c(median(c(24,24.6,24.2), na.rm=TRUE),
             median(c(23,24,23.2), na.rm=TRUE),
             median(c(NA,NA,25), na.rm=TRUE))
  expect_that(SDC, equals(df_result$median3_less1_imp_SDC))
  expect_that(SDCme, equals(df_result$median3_less1_imp_SDCme))
})


