context("calculateAverages2")
options(rMQanalysis.dbg_level = 0)
df <- data.frame(
  log2.LFQ.intensity.SDC_1=   c(28,NA,NA,NA),
  log2.LFQ.intensity.SDC_2=   c(30,NA,NA,NA),
  log2.LFQ.intensity.SDC_3=   c(32,30,NA,NA),
  log2.LFQ.intensity.SDC_4=   c(32,NA,NA,NA),
  log2.LFQ.intensity.SDCme_1= c(24,23,NA,NA),
  log2.LFQ.intensity.SDCme_2= c(26,24,NA,NA),
  log2.LFQ.intensity.SDCme_13=c(28,NA,NA,NA),
  log2.LFQ.intensity.SDCme_4= c(NA,NA,25,NA),
  log2.1LFQ.intensity.SDC_1=   c(28,24,20,NA),
  log2.1LFQ.intensity.SDC_2=   c(30,22,22,NA),
  log2.1LFQ.intensity.SDC_3=   c(32,30,24,NA),
  log2.1LFQ.intensity.SDC_4=   c(32,NA,NA,26),
  log2.1LFQ.intensity.SDCme_1= c(24,23,NA,NA),
  log2.1LFQ.intensity.SDCme_2= c(26,24,NA,NA),
  log2.1LFQ.intensity.SDCme_13=c(28,26,25,NA),
  log2.1LFQ.intensity.SDCme_4=c(28,NA,25,28))


test_that('calculateAverages2 uses the log2.LFQ values as standard and averages it', {  
  df_result <- calculateAverages2(df)
  SDC <- apply(df[grep('log2.LFQ.intensity.SDC_', names(df))],1,mean,na.rm=TRUE)
  SDCme <- apply(df[grep('log2.LFQ.intensity.SDCme_', names(df))],1,mean,na.rm=TRUE)
  expect_that(SDC, equals(df_result$averages$mean_SDC))
  expect_that(SDCme, equals(df_result$averages$mean_SDCme))
})

# test_that('calculateAverages2 uses the log2.LFQ and log2.1LFQ values', {  
#   df_result <- 
#     calculateAverages2(
#       df,
#       average_function='mean',
#       columns_regexs=c('^log2.LFQ','^log2.1LFQ'),
#       min_values=list(A=c(2,0),
#                       B=c(0,3),
#                       C=c(1,2)),
#       multiply_values=list(A=c(1,0),
#                            B=c(0,1),
#                            C=c(2,1))
#       )
#   
#   SDC <- apply(df[grep('log2.LFQ.intensity.SDC_', names(df))],1,mean,na.rm=TRUE)
#   SDCme <- apply(df[grep('log2.LFQ.intensity.SDCme_', names(df))],1,mean,na.rm=TRUE)
#   expect_that(SDC, equals(df_result$averages$mean_SDC))
#   expect_that(SDCme, equals(df_result$averages$mean_SDCme))
# })