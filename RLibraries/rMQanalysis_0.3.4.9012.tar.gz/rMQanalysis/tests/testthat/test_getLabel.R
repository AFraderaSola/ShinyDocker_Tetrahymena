context("getLabel")
options(rMQanalysis.dbg_level = 0)
pg_file <- system.file('extdata', 
                  'SILAC_1to3_proteinGroups.txt', 
                  package='rMQanalysis' )
pg <- filterWholeDataset(read.delim(pg_file))
pg <- pg[1560:1563,]

test_that('getLabels returns the correct column', { 
  expect_that(getLabel(pg, 'Gene.names'), 
              equals(c('CWF19L1','','LRRC8E','LPCAT3')))
  expect_that(getLabel(pg, 'Protein.IDs'), 
              equals(c('Q69YN2-3;Q69YN2','Q6LC01','Q6NSJ5','Q6P1A2-2;Q6P1A2')))
})

test_that('getLabels returns warning if column does not exist and returns "Protein.IDs', {
  expect_that(var <- getLabel(pg, 'TESTCOLUMN'), 
              gives_warning('Column "TESTCOLUMN" and "" does not exist. Using "Protein.IDs" instead!'))
  expect_that(var, 
              equals(c('Q69YN2-3;Q69YN2','Q6LC01','Q6NSJ5','Q6P1A2-2;Q6P1A2')))
  expect_that(var <- getLabel(pg, 'TESTCOLUMN', 'Protein.IDs'), 
              gives_warning('Column "TESTCOLUMN" does not exist. Using "Protein.IDs" instead!'))
  expect_that(var, 
              equals(c('Q69YN2-3;Q69YN2','Q6LC01','Q6NSJ5','Q6P1A2-2;Q6P1A2')))
})


test_that('getLabels returns the fallback column', {
  expect_that(getLabel(pg, 'Gene.names', fallback='Protein.IDs'), 
              equals(c('CWF19L1','Q6LC01','LRRC8E','LPCAT3')))
  expect_that(getLabel(pg, 'Gene.names', fallback='Peptide.counts..all.'), 
              equals(c('CWF19L1','13','LRRC8E','LPCAT3')))
})

test_that('getLabels applies regex on input colname', {
  expect_that(getLabel(pg, 'Protein.IDs', 
                       colname_regex='([^;]+).*'), 
              equals(c('Q69YN2-3','Q6LC01','Q6NSJ5','Q6P1A2-2')))
})

test_that('getLabels applies regex on fallback colname', {
  pg2 <- pg
  pg2['Protein.IDs'] <- c('a;b','c;d','e;f','g;h')
  expect_that(getLabel(pg2, 'Gene.names', 
                       fallback='Protein.IDs',
                       fallback_regex='([^;]+).*'), 
              equals(c('CWF19L1','c','LRRC8E','LPCAT3')))
})
test_that('getLabels applies colname_regex on Protein.IDs in case of missing input column', {
  pg2 <- pg
  pg2['Protein.IDs'] <- c('a;b','c;d','e;f','g;h')
  expect_that(var <- getLabel(pg2, 'Gene.names2', 
                              colname_regex='([^;]+).*',
                              fallback='Protein.IDs',
                              fallback_regex='([^;]+).*'), 
              gives_warning('Column "Gene.names2" does not exist. Using "Protein.IDs" instead!'))
  expect_that(var, equals(c('a','c','e','g')))
})

test_that('getLabels also works with NA in prefered column', {
  pg2 <- pg
  pg2[2,'Gene.names'] <- NA
  expect_that(getLabel(pg2, 'Gene.names', fallback='Protein.IDs'), 
              equals(c('CWF19L1','Q6LC01','LRRC8E','LPCAT3')))
})

test_that('getLabels uses fallback in case colname does not exist', {
  expect_that(var <- getLabel(pg, 'Gene.names2', 
                              colname_regex='([^;]+).*',
                              fallback='Gene.names',
                              fallback_regex='([^;]+).*'), 
              gives_warning('Column "Gene.names2" does not exist. Using "Gene.names" instead!'))
  expect_that(var, equals(c('CWF19L1','','LRRC8E','LPCAT3')))
})


test_that('getLabels uses Protein.IDS in case colname AND fallback does not exist', {
  expect_that(var <- getLabel(pg, 'Gene.names2', 
                              colname_regex='([^;]+).*',
                              fallback='Gene.names3',
                              fallback_regex='([^;]+).*'), 
              gives_warning('Column "Gene.names2" and "Gene.names3" does not exist. Using "Protein.IDs" instead!'))
  expect_that(var, equals(c('Q69YN2-3;Q69YN2','Q6LC01','Q6NSJ5','Q6P1A2-2;Q6P1A2')))
})
