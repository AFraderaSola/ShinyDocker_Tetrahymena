#' @export
MQPeptides <- R6::R6Class(
  'MQPeptides',
  inherit=MQFile,
  public = list(
    initialize = function(file_path=NA) {
      super$readFile(file_path)
      
    },
    filterData = function(reverse=TRUE, contaminants=TRUE) {
      filter_list <- list()
      if(reverse) {
        filter_list[['reverse']] <- is.na(private$data[['Reverse']]) | private$data[['Reverse']] == ''
      } else {
        filter_list[['reverse']] <- TRUE
      }
      if(contaminants) {
        contaminant_column <- ifelse('Potential.contaminant' %in% names(private$data),
                                     'Potential.contaminant',
                                     'Contaminant')
        filter_list[['contaminants']] <- is.na(private$data[[contaminant_column]]) | private$data[[contaminant_column]] == ''
      } else {
        filter_list[['contaminants']] <- TRUE
      }
      super$setFilter(Reduce('&', filter_list))
    },
    getPeptides = function(ids, column='Proteins') {
      result <- data.frame()
      for(id in ids) {
        result <- 
          rbind(result, 
                super$getRowsByIdentifier(id, column=column, ignore_case=TRUE))
      }
      return(unique(result))
    },
    getMissedCleavageDF = function() {
      df <- as.data.frame(table(super$getData()$Missed.cleavages))
      df$amount <- df$Freq / sum(df$Freq) * 100
      df$round_amount <- round(df$amount, 1)
      names(df) <- c('index', 'count', 'amount', 'round_amount')
      return(df)
    }
  ),
  private = list(
    
  )
)



# p <- MQPeptides$new('../../cfppdfs/cfppdfs/tests/SILAC_DML_DATA/silac_triple_for/combined/txt/peptides.txt')
# p$getPeptides('q497e8')


