#' This function creates a plot comparing Intensity to LFQ values
#' 
#' The function expects a data frame with Intensity columns per experiment plus
#' the LFQ columns. It will create a facet wrapped plot. In case a species 
#' column is provided, the facets will be species specific.
#' @export
#' @param data_set The protein groups file containing Intensity* and LFQ* 
#' columns.
#' @import ggplot2
plotIntensityLFQComparison <- function(data_set) {
  repl <- type <- value <- NULL
  intensity_comp_df <- data_set[c(grep('species', names(data_set)), 
                                  grep('Intensity.', names(data_set)), 
                                  grep('^LFQ.', names(data_set)))]
  if('species' %in% names(intensity_comp_df)) {
    mintensity_comp_df <- melt(intensity_comp_df, 'species')
  } else {
    suppressWarnings(
      mintensity_comp_df <- melt(intensity_comp_df)
    )
  }
  mintensity_comp_df <- mintensity_comp_df[!is.na(mintensity_comp_df$value),]
  mintensity_comp_df$value <- log2(mintensity_comp_df$value)
  mintensity_comp_df$type <- 
    sub('(.+sity)\\..*','\\1', mintensity_comp_df$variable)
  mintensity_comp_df$timepoint <- 
    sub('.+sity\\.(.+)_\\d','\\1', mintensity_comp_df$variable)
  mintensity_comp_df$repl <- 
    sub('.+sity\\..+_(\\d+)','\\1', mintensity_comp_df$variable)
  
  shortenLabel <- function(x) {
    lab <- sub('(\\d+)\\..*','\\1', x)
  }
  
  intensity_comp_graph <- 
    ggplot(mintensity_comp_df, aes(interaction(repl, type), value, fill=type)) + 
    geom_boxplot(na.rm=TRUE) + 
    rMQanalysis::theme_imb() +
    scale_x_discrete(label=shortenLabel) + 
    xlab('replicate') +
    ylab('Intensity') + 
    ggtitle('Intensity vs. LFQ Intensity w/o imputed')
  if('species' %in% names(data_set)) {
    intensity_comp_graph <- 
      intensity_comp_graph + facet_wrap(species ~ timepoint)
  } else {
    intensity_comp_graph <- 
      intensity_comp_graph + facet_wrap( ~ timepoint)
  }
  return(intensity_comp_graph)
}
