#' create an object of class MQanalysis for compact representation of a complete
#' MaxQuant analysis
#' 
#' The function is under development, so not much implemented yet. 
#' 
#' This function creates an object with all MQ analysis files in one list. By 
#' providing the path to the "txt" files from the analysis, several files get
#' automatically read in an efficient way. You can add a project name as well as
#' a detailed description.
#' 
#' @export
#' @param path path to MQ analysis txt files
#' @param name a project name
#' @param comment a detailed description of your project
#' @param proteinGroups read the proteinGroups.txt file
#' @param peptides read the peptides.txt file
#' @param evidence read the evidence.txt file
#' @param allPeptides read the allPeptides.txt file
#' @param dataset_sub provide a regex to replace part of the rawfile name for 
#' easy to read stats
#' @importFrom readr read_tsv col_character cols
MQanalysis <- function(path, 
                       name='An MQ analysis', 
                       comment=NULL,
                       proteinGroups=TRUE,
                       peptides=FALSE,
                       evidence=FALSE,
                       allPeptides=FALSE,
                       dataset_sub=NULL) {
  result <- list(data_path=file.path(getwd(), path),
                 name=name,
                 comment=comment)
  class(result) <- append(class(result), 'MQanalysis')
  
  # Always read parameters and summary
  result[['parameters']] <- 
    readr::read_tsv(file.path(result[['data_path']], 'parameters.txt'),
                    col_types=readr::cols(Parameter = readr::col_character(),
                                          Value = readr::col_character()))
  suppressMessages(
    result[['summary']] <- 
      readr::read_tsv(file.path(result[['data_path']], 'summary.txt'))
  )
  result[['fasta_db']] <- 
    strsplit(as.character(
      result[['parameters']][result[['parameters']][[1]] == 'Fasta file',2]),
      ';')[[1]]
  result[['analysis_date']] <- 
    strptime(as.character(
      result[['parameters']][result[['parameters']][[1]] == 'Date of writing',2]),
      '%m/%d/%Y %H:%M:%S')
  
  if(proteinGroups) {
    result[['proteinGroups']] <- 
      read_MQtsv(file.path(result[['data_path']], 'proteinGroups.txt'))
  } else {
    result[['proteinGroups']] <- NULL
  }
  if(peptides) {
    result[['peptides']] <- 
      read_MQtsv(file.path(result[['data_path']], 'peptides.txt'))
  } else {
    result[['peptides']] <- NULL
  }
  if(evidence) {
    result[['evidence']] <- 
      read_MQtsv(file.path(result[['data_path']], 'evidence.txt'))
  } else {
    result[['evidence']] <- NULL
  }
  if(allPeptides) {
    result[['allPeptides']] <- 
      read_MQtsv(file.path(result[['data_path']], 'allPeptides.txt'))
    if(!is.null(dataset_sub)) {
      result[['allPeptides']][['dataset']] <- 
        gsub(dataset_sub, '', result[['allPeptides']][['Raw file']])
    } else {
      result[['allPeptides']][['dataset']] <- 
        result[['allPeptides']][['Raw file']]
    }
  } else {
    result[['allPeptides']] <- NULL
  }
  
  return(result)
}

#' generic print function to represent a MQanalysis object
#' @export
#' @param x an object used to select a method
#' @param ... further arguments passed to or from other methods
print.MQanalysis <- function(x, ...) {
  cat(sprintf('%s\nLocation: %s\n',
              x$name, x$data_path))
  cat(sprintf('Analysis from: %s\n', x$analysis_date))
  if(!is.null(x$comment)) cat(sprintf('Comment: %s\n', x$comment))
  cat(sprintf('Fasta DBs: %s\n', paste(basename(x$fasta_db), collapse=', ')))
  if(!is.null(x$proteinGroups)) cat(sprintf('proteinGroups:%5d\t',
                                            nrow(x$proteinGroups)))
  if(!is.null(x$peptides)) cat(sprintf(     'peptides:%6d     \t',
                                            nrow(x$peptides)))
  if(!is.null(x$evidence)) cat(sprintf(     'evidence:%6d     \t',
                                            nrow(x$evidence)))
  if(!is.null(x$allPeptides)) {
    cat(sprintf(  'allPeptides:%7d  \t', nrow(x$allPeptides)))
  }
}