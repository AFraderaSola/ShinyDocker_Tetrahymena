#' Counting measured values (not NA) per experiment.
#' 
#' We count the not NA values for each experiment per protein group. Make sure
#' to use _ and any number to separate the replicate number from the experiment 
#' name. Good names are "cont_1, cont_2, cont_3". In case of two words for the
#' experiment name, please use a - and no space or _ "anti-sense_01, anti-sense_02".
#' Please make sure to set missing values to NA. 0 will be counted as measured 
#' values.
#' @export
#' @param df a data frame with only columns used for counting
#' @param rep_separator Separator used before the replicate number, _ is recommended!
#' @param col_suffix The suffix to use for the output table
#' @examples 
#' set.seed(1234)
#' df <- matrix(rnorm(120, 25, 5), 20, 6)
#' df[round(runif(70, 1, length(df)))] <- NA
#' df <- as.data.frame(df)
#' names(df) <- paste(rep(c('LFQ.intensity.cont','LFQ.intensity.mbp'), each=3), 
#'                    c(1,2,3), sep='_')
#' countValuesPerExperiment(df)
countValuesPerExperiment <- function(df, rep_separator='_', col_suffix='value_count_') {
  col_regex <- paste0('(.*)', rep_separator, '\\d+$')
  unique_colnames <- unique(sub(col_regex, '\\1', names(df)))
  search_colnames <- paste0(unique_colnames, rep_separator)
  for(df_colname in search_colnames) {
    value_count_df <- 
      as.data.frame(apply(df[grep(df_colname, names(df))], 
                          1, 
                          function(x) sum(!is.na(x))))
    names(value_count_df) <- 
      paste0(col_suffix, gsub('.*\\.([^\\.]+)_', '\\1',df_colname))
    df <- cbind(df, value_count_df)
  }
  return(df[grep(col_suffix, names(df))])
}