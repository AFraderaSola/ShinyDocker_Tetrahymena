#' read MQ files using the readr package
#' 
#' This function reads MaxQuant files via the readr::read_tsv function and 
#' automatically handles problematic columns like the Intensities or so, since
#' they sometimes have high values but get recognized as integer. So this 
#' function automatically sets the column types to a proper format.
#' It is also possible by providing a FUN to read in the data as little chunks
#' (useful for big files).
#' 
#' @param file the file name of the MQ txt file
#' @param FUN a function to execute on each chunk
#' @param check.names should names be checked to be syntactically valid variable names
#' @export
#' @importFrom readr read_tsv_chunked read_tsv col_double col_character DataFrameCallback
#' @importFrom stats setNames
#' @importFrom utils read.delim
#' @importFrom dplyr as_data_frame
#' @examples 
#' mq_file <- system.file('extdata','proteinGroups_withNA.txt', 
#'                        package='rMQanalysis')
#' df <- read_MQtsv(mq_file)
#' 
#' my_subset <- function(x, pos) subset(x, Peptides > 5)
#' df <- read_MQtsv(mq_file, my_subset)
read_MQtsv <- function(file, FUN=NULL, check.names=TRUE) {
  jnk <- utils::read.delim(file, nrows=1, check.names=FALSE)
  
  # column names which should be read as double
  col_double_names <- grep('Intensity|LFQ|iBAQ', 
                           names(jnk), value=TRUE)
  
  # column names which should be read as character
  col_character_names <- c('MSMS Scan Numbers', 'MSMS Isotope Indices')
  col_character_names <- grep(paste0(col_character_names, collapse='|'), 
                                names(jnk), value=TRUE)
  
  # column names which should be read as factors
  col_factor_names <- c('Reverse', 'Potential contaminant', 'Contaminant', 
                        'Only identified by site')
  col_factor_names <- grep(paste0(col_factor_names, collapse='|'), 
                           names(jnk), value=TRUE)
  # a list of column names and the correct type
  my_col_types <- stats::setNames(
    c(rep(list(readr::col_double()), length(col_double_names)),
      rep(list(readr::col_character()), length(col_character_names)),
      rep(list(readr::col_factor(c('','+'))), 
          length(col_factor_names))), 
    c(col_double_names, col_character_names, col_factor_names))
  
  na_col_regex <- 'Potential.contaminant|Contaminant|Reverse|Only.identified.by.site'
  if(is.null(FUN)) {
    df <- readr::read_tsv(file, 
                    col_types=my_col_types)
  } else {
    df <- readr::read_tsv_chunked(file, 
                                  readr::DataFrameCallback$new(FUN),
                                  col_types=my_col_types)
  }
  na_cols <- grep(na_col_regex, names(df))
  df <- as.data.frame(df)
  df[na_cols][is.na(df[na_cols])] <- '' 
  df <- dplyr::as_data_frame(df)
  if(check.names) names(df) <- make.names(names(df))
  return(df)
}


