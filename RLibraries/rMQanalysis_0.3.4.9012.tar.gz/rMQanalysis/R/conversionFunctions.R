#' A function to convert between single and three letter code of amino acids 
#' and the full name.
#' 
#' This functions returns the full name of an amino acid, for a one or three 
#' letter code. The output can be changed to return other codes. At the moment, 
#' "full", "three" and "one" are supported. 
#' Your search has to fit the convention of capitalized words, such as Alanine,
#' Ala or A. alanine or ala would not return the correct amino acid.
#' 
#' @param aa a string of the aminoacid you are looking for
#' @param code how to convert the given amino acid. Supported are "full", 
#' "three" and "one" letter code, "formular", "monoisotopic_mass" and "average_mass" 
#' @export
#' @examples
#' print(AA('R'))
#' print(AA('R', 'three'))
#' print(AA('Alanine', 'three'))
#' print(AA('Lysine', 'one'))
#' print(AA('L','average_mass'))
#' print(AA('W','formular'))
AA <- function(aa, code='full') {
  return(
    rMQanalysis::aminoacid_mass[
      apply(rMQanalysis::aminoacid_mass,
            1,
            function(x) any(grepl(paste0('^',aa,'$'),x))),code])
}
