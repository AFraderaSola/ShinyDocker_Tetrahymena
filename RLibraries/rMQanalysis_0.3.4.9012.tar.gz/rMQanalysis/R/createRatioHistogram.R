#' This function uses a protein groups table of a labeled experiment and creates
#' a histogram of the selected column.
#' @export
#' @param pg_ratios A data frame of protein groups with ratios for labels
#' @param column_name The column name with the ratios in it
#' @param normalized If we look for '.normalized' columns
#' @param plot_range The range to plot the graph.
#' @import  ggplot2
createRatioHistogram <- function(pg_ratios, 
                                 column_name, 
                                 normalized=FALSE, 
                                 plot_range=c(-5,5)) {
  median_experiment <- 
    median(pg_ratios[[column_name]], na.rm=TRUE)
  temp_log2_ratio <- log2(pg_ratios[[column_name]])
  
  experiment_regex <- 'Ratio\\.(.)\\.(.)\\.(normalized\\.)?'
  boxplot_xlab <- sub(experiment_regex, '', column_name)
  ratio_label <- sub(paste0(experiment_regex, '.*'), '\\1/\\2', column_name)
  gg_title_string <- ifelse(normalized,
                            '%s normalized\nMedian-Ratio: %.2f',
                            '%s \nMedian-Ratio: %.2f')
  
  g <- 
    ggplot(NULL, aes(x=temp_log2_ratio)) + 
    geom_histogram(binwidth=.2,color='black',fill='grey', na.rm=TRUE) + 
    geom_vline(xintercept=log2(median_experiment), color='red') +
    xlab(sprintf('log2 ( %s )', ratio_label)) + ylab("Frequency") + 
    xlim(plot_range) +
    theme_bw() +
    ggtitle(sprintf(gg_title_string,
                    boxplot_xlab,
                    median_experiment))
  return(g)
}
