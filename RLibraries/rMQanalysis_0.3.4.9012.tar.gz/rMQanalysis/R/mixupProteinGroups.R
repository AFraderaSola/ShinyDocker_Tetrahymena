#' Function to mix a protein groups file to make it irrecognizable.
#' 
#' This function basically samples the rows of specific columns. This might be 
#' helpful in case you want to use an original data set but make the analysis
#' inccorect. The file will be usable as normal but the intensities etc are no 
#' longer in the correct protein group.
#' @export
#' @param x the data frame from a proteinGroups.txt file
#' @param columns the columns we will randomize
#' @param seed a random seed to make it reproducible
mixupProteinGroups <- function(
  x, 
  columns=c('Protein.IDs', 'Majority.protein.IDs','Fasta.headers','Gene.names',
            'Only.identified.by.site', 'Reverse', 'Potential.contaminant'),
  seed=1234) {
  set.seed(seed)
  row_count <- nrow(x)
  mixup_order <- sample(seq(row_count), row_count)
  existing_columns <- columns[columns %in% names(x)]
  if(length(existing_columns) != length(columns)) {
    warning(sprintf('The following columns do not exist: "%s".',
                    paste(columns[!columns %in% names(x)]), collapse=', '), 
            call.=FALSE)
  }
  x_mixup <- x
  x_mixup[existing_columns] <- x[mixup_order, existing_columns]
  x_mixup
}
