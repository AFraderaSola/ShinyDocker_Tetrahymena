#' Create a statistic on ms1 and ms2 per rawfile.
#' 
#' This script created a data frame similar to msScan.txt table from MQ. It 
#' needs the spectrum table created with proteome wizard within a folder. This
#' data can easily created with the spectrumTableFromRaw() function.
#' @param pwiz_directory the folder with the spectrum_table.tsv files
#' @importFrom data.table rbindlist
#' @import dplyr
#' @export
spectrumTableStatistics <- function(pwiz_directory='pwiz_data') {
  Raw.file <- minute <- event <- NULL
  spec_ending <- '.spectrum_table.tsv'
  pwiz_files <- list.files(pwiz_directory, full.names=TRUE)
  pwiz_list <- list()
  for(pwiz_file in pwiz_files) {
    pwiz_df <- read.delim(pwiz_file, comment.char='#', stringsAsFactors=FALSE)
    raw_file <- sub(spec_ending, '', basename(pwiz_file))
    pwiz_df <- cbind(Raw.file=raw_file,
                     pwiz_df)
    pwiz_list[[raw_file]] <- pwiz_df
  }
  pwiz_df <- 
    as.data.frame(data.table::rbindlist(pwiz_list), stringsAsFactors=FALSE)
  pwiz_df <- pwiz_df[order(pwiz_df$rt),]
  pwiz_df$minute <- round(pwiz_df$rt / 60)
  
  pwiz_stat <- 
    pwiz_df %>%
    dplyr::group_by(Raw.file, minute) %>%
    dplyr::summarise(ms1=sum(event == 1),
                     ms2=sum(event == 2))

  return(pwiz_stat)
}
