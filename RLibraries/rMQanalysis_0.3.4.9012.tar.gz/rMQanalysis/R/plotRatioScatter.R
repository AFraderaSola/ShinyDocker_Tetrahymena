#' This function will create a scatter plot with automatically labeling protein
#' groups above a given threshold.
#' 
#' The function expects a data frame, for example a proteinGroups table. It 
#' uses as default value the \code{Ratio.H.L.normalized} column as x axis and 
#' \code{Intensity} column as y axis. In case of a forward or reverse 
#' experiment, it is possible to define the experiment name as an argument. 
#' It will search for the right column name (please do not forget the dot 
#' "\code{.for}"). To label the outliers, we have to define a column name, 
#' the default is \code{Protein.IDs}. Alternatively, you can use the function
#' \code{getLabel} to create a new column specific for labeling.
#' 
#' @param data this is the input data frame, for example a protein groups file
#' @param labels the column to use as label (you can use \code{getLabel} 
#' function to create this)
#' @param experiment define an experiment (ex. ".for" or ".rev")
#' @param threshold define a minimum foldchange in log2 scale
#' @param x_col the column to use on x axis
#' @param y_col the column to use on y axis
#' @param color_col the column to color the dots by
#' @param log_x indicate if you want to log2 transform the x axis
#' @param invert_x inverts x axis values log2(1/x_col)
#' @param negative in contrast to \code{invert_x}, this will just 
#' highlight the negative part and also inverts the threshold.
#' @import ggplot2
#' @importFrom scales trans_breaks trans_format math_format
#' @export
#' @examples
#' pg <- 
#'   read.delim(system.file('extdata', 
#'                          'SILAC_1to3_proteinGroups.txt', 
#'                          package='rMQanalysis'))
#' pg$my_label <- getLabel(pg, 'Gene.names', 'Protein.IDs', '([^;]+).*', '([^;]+).*')
#' plotRatioScatter(pg, labels='my_label', experiment='')
#' # if you have a forward and reverse experiment, you could set 
#' # experiment to experiment='.for' for example.
plotRatioScatter <- function(data, 
                             labels='Protein.IDs', 
                             experiment='', 
                             threshold=1, 
                             x_col='Ratio.H.L.normalized', 
                             y_col='Intensity', 
                             color_col='Peptides',
                             log_x=TRUE,
                             invert_x=FALSE,
                             negative=FALSE) {
  x  <- .x <- y <- color <- label <- NULL
  x_column <- paste0(x_col, experiment)
  y_column <- paste0(y_col, experiment)
  color_column <- paste0(color_col, experiment)
  if(invert_x) {
    data[[x_column]] <- 1 / data[[x_column]]
  }
  df <- data.frame(x=if(log_x) log2(data[[x_column]]) else data[[x_column]],
                   y=data[[y_column]],
                   label=data[[labels]],
                   color=data[[color_column]])
  if(negative) {
    ggplot(df, aes(x, y)) + 
      geom_point(data=subset(df, x > -threshold), color='black', alpha=.3) + 
      scale_y_log10(breaks = trans_breaks("log10", function(x) 10^x),
                    labels = trans_format("log10", math_format(10^.x))) + 
      scale_x_continuous(limits=c(min(df$x, na.rm=TRUE) - 2, max(df$x, na.rm=TRUE)), 
                         breaks=seq(-500, 500, 2), 
                         minor_breaks=seq(-500, 500, .5)) +
      annotation_logticks(sides='l') +
      geom_point(data=subset(df, x <= -threshold), aes(color=color)) +
      geom_text(data=subset(df, x <= -threshold), hjust=1.1, size=2.3, aes(label=label)) + 
      theme_imb() +
      scale_color_gradient(color_col, low='blue', high='red') +
      geom_vline(xintercept=-threshold, color='red', linetype='dashed') +
      xlab(ifelse(log_x, sprintf('log2( %s )', x_column), x_column)) + 
      ylab(y_column)
  } else {
    ggplot(df, aes(x, y)) + 
      geom_point(data=subset(df, x < threshold), color='black', alpha=.3) + 
      scale_y_log10(breaks = trans_breaks("log10", function(x) 10^x),
                    labels = trans_format("log10", math_format(10^.x))) + 
      scale_x_continuous(limits=c(min(df$x, na.rm=TRUE), max(df$x, na.rm=TRUE) + 2), 
                         breaks=seq(-500, 500, 2), 
                         minor_breaks=seq(-500, 500, .5)) +
      annotation_logticks(sides='l') +
      geom_point(data=subset(df, x >= threshold), aes(color=color)) +
      geom_text(data=subset(df, x >= threshold), hjust=-0.1, size=2.3, aes(label=label)) + 
      theme_imb() +
      scale_color_gradient(color_col, low='blue', high='red') +
      geom_vline(xintercept=threshold, color='red', linetype='dashed') +
      xlab(sprintf('log2( %s )', x_column)) + ylab(y_column)
  }
}