#' Shortcut for writing our table files
#' 
#' This is a shortcut for the build in write.table function with our most used
#' settings.
#' @export
#' @param data data frame to write into file
#' @param file filename to write the data
#' @param row.names if row.names should be printed, default is FALSE
#' @param sep default seperator is set to tab
#' @param quote quoting is set to off
#' @importFrom utils write.table
write.table_imb <- function(data,file,
                            row.names = FALSE,
                            sep = '\t',
                            quote = FALSE) {
  utils::write.table(data, 
                     file=file, 
                     row.names = row.names, 
                     sep = sep, 
                     quote = quote)
  mylog(sprintf('wrote file "%s"',file))
}




