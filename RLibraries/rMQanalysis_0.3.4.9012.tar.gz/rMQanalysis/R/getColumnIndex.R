#' This functions returns the column index or names based on a regex from a data
#' frame.
#' @param data_set the data frame we want to search
#' @param regex a regex to extract the column names
#' @param names set TRUE to get names instead of index
#' @export
#' @examples 
#' \dontrun{
#' getColumnIndex(pg, '^LFQ')
#' getColumnIndex(pg, '^LFQ', names=TRUE)
#' }
getColumnIndex <- function(data_set, regex, names=FALSE) {
  grep(regex, names(data_set), value=names)
}
