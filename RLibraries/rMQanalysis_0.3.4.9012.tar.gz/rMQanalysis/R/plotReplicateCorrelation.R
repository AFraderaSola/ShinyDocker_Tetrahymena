#' Function to create heatmaps to visualise replicate correlation.
#' @export
#' @param data_set A protein groups data frame
#' @param white_area The amount of white compared to blue area
#' @param regex The regex to search for columns to plot
#' @param species In case there is no species column, we use this parameter within title
#' @examples 
#' \dontrun{
#' replicate_plot_functions <- 
#'   lapply(unique(pg_ident$species), function(x) {
#'     filter(pg_quant, species == x) %>%
#'       select(species, matches(pca_column_regex)) %>%
#'       rMQanalysis::plotReplicateCorrelation(., 
#'                                             heatmap_white_area_size, 
#'                                             heatmap_column_regex)
#'   })
#' jnk <- lapply(replicate_plot_functions, function(f) f())
#' 
#' pdf(file=file.path(out_dir, 'replicate_correlation_plots.pdf'),
#'     width=9, height=8, pointsize=8)
#' jnk <- lapply(replicate_plot_functions, function(f) f())
#' dev.off()
#' }
plotReplicateCorrelation <- function(data_set, 
                                     white_area=1,
                                     regex='^imputed.log2.LFQ.intensity.',
                                     species=NULL,
                                     cluster=FALSE) {
  if(!'species' %in% names(data_set)) {
    # warning('There is no "species" column in the data frame so we use parameter.')
    species_name <- ifelse(is.null(species), '', paste0(species, ': '))
    main_title <- sprintf("%scorrelation between replicates", species_name)
  } else {
    species_name <- paste(unique(data_set$species), collapse=', ')
    main_title <- sprintf("%s: correlation between replicates", species_name)
  }
  if(cluster) {
    main_title <- paste(main_title, 'with clustering')
  }
  pal <- c(rep("white",each=9 * white_area), 
           brewer.pal(9,"Blues"))
  lfq <- data_set[,grep(regex, names(data_set))]
  colnames(lfq) <- gsub(regex,'',colnames(lfq))
  
  group   <- as.factor(gsub("_[1-4]$","",colnames(lfq)))
  lfq.avg <- t(apply(lfq,1,function(x) tapply(x,group,mean,na.rm=T)))
  v <- apply(lfq,1,sd)
  corr <- apply(lfq[rev(order(v)),],2,function(x) {
    apply(lfq[rev(order(v)),],2,function(y) {
      cor(x,y,use="na.or.complete")
    })
  })
  
  rMQanalysis::createHeatmap(corr,
                             trace="none",
                             Colv=cluster,
                             Rowv=cluster,
                             dendrogram="none",
                             density.info="density",
                             srtCol=45,
                             main=main_title,
                             margins=c(10, 10), 
                             key.xlab="Pearson's correlation coefficient",
                             key.title="",
                             keysize=1.5,
                             col=pal)
}


#' Helper function to create qplots heatmaps
#' @export
#' @param ... All parameters will be forwarded to gplots heatmap.2
#' @importFrom gplots heatmap.2
createHeatmap <- function(...) {
  plotHeatmap <- function() gplots::heatmap.2(...)
}