updatePackageVersion <- function(packageLocation='.') {
  desc <- readLines(file.path(packageLocation, 'DESCRIPTION'))
  vLine <- grep('^Version\\:', desc)
  vNumber <- gsub('^Version\\:\\s*', '', desc[vLine])
  versionNumber <- strsplit(vNumber, '\\.')[[1]]
  versionParts <- length(versionNumber)
  vNumberKeep <- paste(versionNumber[1:(versionParts-1)], sep='', collapse='.')
  vNumberUpdate <- versionNumber[versionParts]
  oldVersion <- as.numeric(vNumberUpdate)
  newVersion <- oldVersion + 1
  vFinal <- paste(vNumberKeep, newVersion, sep='.')
  desc[vLine] <- paste0('Version: ', vFinal)
  writeLines(desc, file.path(packageLocation, 'DESCRIPTION'))
  return(vFinal)
}
