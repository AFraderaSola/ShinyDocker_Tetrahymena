#' Get the rows of proteinGroups table, filtered by different columns
#'
#' This function filters the proteinGroups table by three columns, 
#' \code{Only.identified.by.site}, \code{Reverse} and 
#' \code{Potential.contaminant}. The result will be a vector of \code{TRUE} 
#' and \code{FALSE} values, which indicate if a row can be used (TRUE) or is 
#' filtered (FALSE).
#'
#' @param data a proteinGroups table produced by MaxQuant
#' @param by_bysite filter the table by the \code{Only.identified.by.site} 
#' column 
#' @param by_reverse filter the table by the \code{Reverse} column
#' @param by_contaminant filter the table by the \code{Potential.contaminant} 
#' column
#' @return 
#' a vector with \code{TRUE} and \code{FALSE} indicating if a line can be used
#' (TRUE) or is filtered (FALSE).
getFilteredRowsFromDataset <- function(data, 
                               by_bysite = TRUE, 
                               by_reverse = TRUE, 
                               by_contaminant = TRUE) {
  logstring <- "Filtered dataset by the following columns:"
  by_site <- NULL
  reverse <- NULL
  contaminant <- NULL
  if(any(grepl('Contaminant',names(data)))) {
    names(data)[
      grep('Contaminant',names(data))] <- 'Potential.contaminant'
  } 
  list[by_site,logstring] <- 
    helperFilterColumn(by_bysite,'Only.identified.by.site',data,logstring)
  list[reverse,logstring] <- 
    helperFilterColumn(by_reverse,'Reverse',data,logstring)
  list[contaminant,logstring] <- 
    helperFilterColumn(by_contaminant,'Potential.contaminant',data,logstring)
  filtered <- by_site & reverse & contaminant
  mylog(logstring)
  mylog(sprintf('Filtered %s rows out of %s rows.',
    sum(!filtered),
    nrow(data)))
  return(filtered)
}

helperFilterColumn <- function(filter,colname,data,logstring) {
  if (filter) {
      rows <- filterByColumn(data,colname)
      logstring <- paste(logstring,colname) 
  } else {
    rows <- TRUE
  }
  return(list(rows,logstring))
}


#' Use the list[] command to assign multiple values with one command
#' 
#' This function was introduced by Gabor Grothendieck in a post from June 2004
#' and provides the functionality to assign multiple return values of a 
#' function to multiple variables.
## @usage
## list[QR,,QRaux]  <- qr(c(1,1:3,3:1))
## list[,Green,Blue]  <- col2rgb("aquamarine")
list <- structure(NA,class="result")
"[<-.result" <- function(x,...,value) {
  args <- as.list(match.call())
  args <- args[-c(1:2,length(args))]
  length(value) <- length(args)
  for(i in seq(along=args)) {
    a <- args[[i]]
    if(!missing(a)) eval.parent(substitute(a <- v,list(a=a,v=value[[i]])))
  }
  x
}

#' Filter a proteinGroups table by identified proteins
#' 
#' This function filters the proteinGroups table by minimum 2 razor peptides
#' and 1 unique peptide. In case of a combined dataset, it can return also 
#' just the appropriate columns, depending on the experiments.
#' 
#' The proteomics core facility defines a protein as identified, if minimum 
#' 2 peptides (razor) are found and 1 of these must be a unique peptide. It
#' is possible to change these default values with the equivalent parameters.
#' In case of combined experiments, we also filter the columns for razor and
#' unique peptides, but we return only the experiment related columns.
#' @param data a proteinGroups table produced by MaxQuant
#' @param razor minimum number of peptides
#' @param unique minimum number of unique peptides
#' @param experiment uses columns for a specific experiment, like \code{.for}
#' @param combined returns only the experiment related columns
#' @examples
#' proteinGroups_filename <- 
#'   system.file('extdata', 
#'               'SILAC_1to3_proteinGroups.txt', 
#'               package='rMQanalysis' )
#' proteinGroups <- read.delim(proteinGroups_filename)
#' 
#' data_filtered <- filterWholeDataset(proteinGroups)
#' data_identified <- filterIdentifiedProteins(data_filtered)
#' data_identified_5_2 <- filterIdentifiedProteins(data_filtered, 5, 2)
#' 
#' \dontrun{
#' # if you want to filter a specific experiment in case of multiple.
#' data_identified_for <- 
#'   filterIdentifiedProteins(data_filtered, experiment='.for')
#' }
#' @export
#' @return Returns the filtered proteinGroups table
filterIdentifiedProteins <- function(data,
                                     razor=2,
                                     unique=1,
                                     experiment='',
                                     combined=FALSE) {
  razor_column <- paste0('Razor...unique.peptides', experiment)
  razor_identified <- data[[razor_column]] >= razor
  unique_column <- paste0('Unique.peptides', experiment)
  unique_identified <- data[[unique_column]] >= unique
  identified <- data[razor_identified & unique_identified,]
  if(combined) {
    columns_to_keep <- c(grep("Fasta.headers",names(data)),
                         grep("Protein.names",names(data)),
                         grep("Gene.names",names(data)),
                         grep("Sequence.coverage....",names(data)),
                         grep("Razor...unique.peptides\\..*",names(data)),
                         grep("Unique.peptides\\..*",names(data)))
    identified <- identified[columns_to_keep]
  }
  return(identified)
}

#' Filter a proteinGroups table by different columns
#'
#' This function filters the proteinGroups table by three columns, 
#' \code{Only.identified.by.site}, \code{Reverse} and 
#' \code{Potential.contaminant}. The result will be the filtered 
#' proteinGroups table.
#' 
#' In practice, if the proteinTable is very short and you read in the table 
#' with read.delim(), columns with no value will be saved with NAs in it. If 
#' you now try to filter by just "!= '+'", the result might be wrong. This 
#' function takes care of this case and also prints some information during 
#' the filter process.
#' 
#' @param data a proteinGroups table produced by MaxQuant
#' @param by_bysite filter the table by the \code{Only.identified.by.site} 
#' column 
#' @param by_reverse filter the table by the \code{Reverse} column
#' @param by_contaminant filter the table by the \code{Potential.contaminant} 
#' column.
#' @export
#' @examples
#' proteinGroups_filename <- 
#'   system.file('extdata', 
#'               'SILAC_1to3_proteinGroups.txt', 
#'               package='rMQanalysis' )
#' proteinGroups <- read.delim(proteinGroups_filename)
#' proteinGroups_filtered <- filterWholeDataset(proteinGroups)
#' proteinGroups_only_reverse_filtered <- 
#'     filterWholeDataset(proteinGroups,
#'                        by_bysite=FALSE,
#'                        by_contaminant=FALSE)
#' @return
#' the filtered proteinGroups table
filterWholeDataset <- function(data, 
                               by_bysite = TRUE, 
                               by_reverse = TRUE, 
                               by_contaminant = TRUE) {
  if(any(grepl('Contaminant',names(data)))) {
    names(data)[
      grep('Contaminant',names(data))] <- 'Potential.contaminant'
  } 
  filtered_rows <- getFilteredRowsFromDataset(data,
                                              by_bysite,
                                              by_reverse,
                                              by_contaminant)
  return(data[filtered_rows,])
}


#' Filter a column by '+' or other value
#' 
#' @param data a dataframe to filter
#' @param colname a column name to filter on
#' @param filter a string which indicate to filter the row
#' @return 
#' a vector with \code{TRUE} and \code{FALSE} indicating if a line can be used
#' (TRUE) or is filtered (FALSE).
filterByColumn <- function(data,colname,filter='+') {
  if(checkIfColumnInDataframe(data,colname)) {
    if (any(is.na(data[[colname]]))) {
      rows <- TRUE 
      mylog(sprintf('There are "NAs" in column "%s" and will not be filtered.',
                    colname),
            'WARN')
    } else {
      rows <- data[[colname]] != filter
      mylog(sprintf(
        'Filtered %s rows with "%s" out of the %s column in the dataset.',
        sum(!rows),
        filter,
        colname),dbg_level=2)
    }
  } else {
    rows <- TRUE
  }
  return(rows)
}

checkIfColumnInDataframe <- function(dataframe,colname) {
  column_in_dataframe <- FALSE
  if(length(grep(colname,names(dataframe))) == 1) {
    column_in_dataframe <- TRUE
  } else {
    mylog(sprintf('Column "%s" does not exist in this data.frame!',colname),
          'WARN')
    mylog(sprintf('Column "%s" was not filtered!',colname),
          'WARN')
  }
  return(column_in_dataframe)
}
