#' Create spectrum table for each rawfile.
#' 
#' This function uses msaccess.exe from proteome wizard to create a spectrum
#' table for each raw file and saves them in a subfolder. You can use the 
#' function spectrumTableStatistics() to create a statistic on ms1 and ms2.
#' Make sure to install proteowizard and set the option 'MSACCESSEXE' in 
#' .Rprofile
#' @param rawfile the rawfile to work on
#' @param pwiz_dir the output directory for spectrum tables
#' @param msaccess_path the path to the msaccess.exe script (will be read from options)
#' @export
spectrumTableFromRaw <- function(rawfile,  
                                 pwiz_dir='pwiz_data',
                                 msaccess_path=NULL) {
  Raw.file <- minute <- event <- NULL
  spec_ending <- '.spectrum_table.tsv'
  msaccess_parameters <- '-x "spectrum_table delimiter=tab"'
  
  if(is.null(msaccess_path)) {
    msaccess_exe <- cfpscripts::getGlobalOption(
      'MSACCESSEXE', 
      'options(MSACCESSEXE="C:/programs/proteowizard/msaccess.exe")')
  } else {
    if(file.exists(msaccess_path)) {
      msaccess_exe <- msaccess_path
    } else {
      stop(sprintf('File "%s" does not exist.', msaccess_path))
    }
  }
  
  if(!dir.exists(pwiz_dir)) dir.create(pwiz_dir)
  
  cmd_line <- sprintf('"%s" %s %s', 
                      msaccess_exe, 
                      msaccess_parameters, 
                      rawfile, intern=TRUE)
  
  message(sprintf('Create spectra table for %s', basename(rawfile)))
  system(cmd_line)
  
  spec_file <- paste0(rawfile, spec_ending)
  if(file.exists(spec_file)) {
    file.rename(spec_file, file.path(pwiz_dir, spec_file))
  } else {
    message(sprintf('looks like %s was not created!', spec_file))
  }
}
