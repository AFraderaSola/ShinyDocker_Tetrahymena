#' This function prints aligned sequences on the screen in a readable way.
#' 
#' The functions expects a data frame with one sequence per column and one 
#' letter per row. Look at the example to get an idea. It works with multiple
#' sequences.
#' 
#' @return
#' Just prints the alignment on the screen.
#' @param sequences_df A data frame with one sequence per column and one letter
#' per row.
#' @param width how many characters per row
#' @export
#' @examples
#' \dontrun{
#' # creating some sample sequence
#' x <- sample(LETTERS,100,replace=T)
#' y <- c(rep('-',20),x[21:40],rep('-',60))
#' 
#' # creating a data frame
#' seq_df <- data.frame(blabla=x,blabla2345=y)
#' printAlignment(seq_df)
#' 
#' # to print the alignment into a file:
#' sink(file = "alignment.txt", type = "output")
#' printAlignment(seq_df, width=59)
#' sink()
#' }
printAlignment <- function(sequences_df, width=69) {
  name_length <- max(nchar(names(sequences_df)))
  sequence_length <- nrow(sequences_df)
  start_index <- 1
  seq_df <- apply(sequences_df, 2, paste,collapse='')
  while(start_index < sequence_length) {
    temp_end <- start_index + width
    name_string <- sprintf('%%%ds    %%s\n', name_length)
    ifelse(temp_end >= sequence_length,
           temp_width <- sequence_length - start_index + 1,
           temp_width <- width + 1) 
    cat(sprintf('%s%4d%s%-4d\n',
                paste(rep(' ',name_length),collapse=''),
                start_index,
                paste(rep(' ', temp_width),collapse=''),
                start_index + temp_width - 1))
    for(name in names(seq_df)) {
      cat(sprintf(name_string,
                  name,
                  substr(seq_df[[name]],start_index,temp_end)))
    }
    cat('\n')
    start_index <- temp_end + 1
  }
}


#' logging function
#' 
#' This function tries to use logging functionality. If the logging package 
#' is not installed, or is not setup properly, it uses a normal print command.
#' The function will test the global debug level before printing. To set the 
#' global debug level to a specific value use 
#' \code{options(rMQanalysis.dbg_level = 1)} or maybe something higher.
#' Use \code{Inf} to print all messages!
#' 
#' @param string the string to print
#' @param level the level of the log output, for example \code{WARN}, 
#' \code{INFO} or \code{ERROR}
#' @param dbg_level the minimum level to print the message
#' @export
#' @examples
#' mylog('for your information')
#' mylog('this is a warning','WARN')
mylog <- function(string,level='INFO',dbg_level=1) {
  if(level != 'INFO') dbg_level <- 0
  if(getOption("rMQanalysis.dbg_level", default = 0) >= dbg_level){
    cat(sprintf('%s %s: %s\n',
              format(Sys.time(),'%Y-%m-%d %H:%M:%S'),
              level,string))
  }
}