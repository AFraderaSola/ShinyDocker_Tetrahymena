#' Split files by separator and check if they exist
#' 
#' @param string String to convert into list of files
#' @param sep How are multiple files separated
#' @param alternative_path A path where to search for single file names
#' @param make_backslash Change forward slashes to backslashes (used for MQ)
#' @export
convertFileString <- function(string, sep=';', alternative_path=NULL,
                              make_backslash=FALSE) {
  files <- strsplit(string, sep)[[1]]
  file_exist <- file.exists(files)
  existing_files <- files[file_exist]
  if(any(!file_exist)) {
    not_existing_files <- files[!file_exist]
    search_paths <- c(alternative_path, getOption('MQFASTADIR'))
    newpath_files <- 
      file.path(rep(search_paths, each=length(not_existing_files)),
                basename(not_existing_files))
    newpath_exist <- file.exists(newpath_files)
    existing_files <- c(existing_files,
                        unique(newpath_files[newpath_exist]))
  }
  files_found <- basename(files) %in% basename(existing_files)
  if(any(!files_found)) {
    warning(sprintf('File "%s" does not exists. ',
                    paste(files[!files_found])))
  }
  return(existing_files)
  
}
