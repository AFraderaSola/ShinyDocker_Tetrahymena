#' Function to filter and extract all created modification files.
#' 
#' @export
#' @importFrom utils read.delim
#' @param name a name to ad to the file name
#' @param path path to the "*.Sites.txt" files
filterModifications <- function(name=NULL, path='combined/txt') {
  PEP <- Localization.prob <- NULL
  
  modification_files <- list.files(path, pattern='.*Sites.txt', full.names=TRUE)
  for(modification_file in modification_files) {
    filename <- ifelse(is.null(name),
                       paste0('modification_',basename(modification_file)),
                       sub('\\.txt',paste0('_',name,'.txt'), 
                           paste0('modification_',basename(modification_file))))
    mod <- tryCatch(utils::read.delim(modification_file), 
                    error=function(e) {
                      cat(sprintf('modification file %s might be empty.\n', 
                                  modification_file))
                      })
    if(!is.null(mod)) {
      options(rMQanalysis.dbg_level = -1)
      mod <- rMQanalysis::filterWholeDataset(mod, by_bysite=FALSE)
      mod <- subset(mod, 
                    PEP < 0.05 &
                      Localization.prob >= 0.75)
    }
    rMQanalysis::write.table_imb(mod,
                                 filename)
  }
}

