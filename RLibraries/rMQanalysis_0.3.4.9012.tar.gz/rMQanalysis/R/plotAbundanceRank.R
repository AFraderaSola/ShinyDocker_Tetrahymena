#' Plotting the protein abundance overview
#' @export
#' @import ggplot2
#' @importFrom tidyr gather_
#' @importFrom stats quantile
#' @import dplyr
#' @importFrom ggrepel geom_label_repel
#' @param data_set The data set to check for protein abundance
#' @param label_column The column used for labeling if a subset_column is provided
#' @param subset_colum A column with TRUE and FALSE to indicated if it should be labeled
#' @param font_size The font size of the labels
plotAbundanceRank <- function(data_set, label_column='Protein.IDs', subset_column=NULL,
                              font_size=3) {
  Intensity <- percent <- log10_intensity <- label <- NULL
  protein_abundance <- data_set[order(-data_set[['Intensity']]),
                                c(grep('species', names(data_set)), 
                                  grep('Protein.IDs', names(data_set)),
                                  if(!is.null(subset_column)) grep(subset_column, names(data_set)),
                                  if(label_column != 'Protein.IDs') grep(label_column, names(data_set)), 
                                  grep('Intensity', names(data_set)))]
  protein_abundance$rank <- order(-protein_abundance[['Intensity']])
  protein_abundance$percent <- 
    protein_abundance$rank / max(protein_abundance$rank) * 100
  protein_abundance$log10_intensity <- log10(protein_abundance[['Intensity']])
  
  suppressWarnings(
    quantile_df <- 
      data_set %>% 
      dplyr::group_by_at(vars(matches('^species$'))) %>%
      dplyr::summarise(`5%`=stats::quantile(log10(Intensity),.05),
                       `50%`=stats::quantile(log10(Intensity),.50),
                       `95%`=stats::quantile(log10(Intensity),.95)) %>% 
      tidyr::gather_('label', 'quantile', c('5%','50%','95%'))
  )
  if(!is.null(subset_column)) {
    label_subset <- protein_abundance[protein_abundance[[subset_column]],]
    protein_abundance <- protein_abundance[!protein_abundance[[subset_column]],]
  } else {
    label_subset <- data.frame()
  }
  
  graph_abundance_rank <- 
    ggplot(protein_abundance, aes(percent, log10_intensity)) + 
    geom_point(alpha=.3, na.rm=TRUE) +
    geom_hline(data=quantile_df, 
               aes(yintercept=quantile, linetype=label), 
               color='red', show.legend=TRUE) +
    scale_linetype_discrete(name='quantile') + theme_imb() + 
    scale_y_continuous(breaks=seq(20)) + 
    xlab('Percent') +
    ylab(sprintf('log10(%s)', 'Intensity'))
  if(nrow(label_subset) > 0) {
    graph_abundance_rank <- graph_abundance_rank +
      geom_point(data=label_subset,
                 alpha=1, na.rm=TRUE, color='red', size=3) +
      geom_label_repel(data=label_subset, 
                       aes_string(label=label_column),
                       size=font_size,
                       box.padding = 0.80, point.padding = 0.5)
  }
  if('species' %in% names(data_set)) {
    graph_abundance_rank <- 
      graph_abundance_rank + facet_wrap(~ species) 
  } else {
    graph_abundance_rank <- 
      graph_abundance_rank + 
      ggtitle(sprintf('90%% of the intensities change in %.1f orders or magnitude',
                      max(quantile_df$quantile) - min(quantile_df$quantile)))
  }
  return(graph_abundance_rank)
}
