#' Scatterplot with mouse over functionality to identify individual proteins
#' 
#' This function uses a data frame and prints the x and y coordinates as a 
#' scatter plot. The data frame needs to have a column "label" and "Protein.IDs"
#' since both will be used for the mouse over label.
#' @export
#' @param data a data frame to plot (needs "label" and "Protein.IDs" column!)
#' @param x_col the column name to plot on x axis
#' @param y_col the column name to plot on y axis
#' @param x_label the x axis label
#' @param y_label the y axis label
#' @param x_threshold the position of the threshold line on x axis
#' @param y_threshold the position of the threshold line on y axis
#' @import ggplot2
#' @importFrom plotly ggplotly
#' @examples 
#' df <- data.frame(label=letters, Protein.IDs=LETTERS, x=runif(26), y=runif(26))
#' interactiveScatterPlot(df, 'x', 'y', 'my x label', 'my y label', 1, 2)
interactiveScatterPlot <- function(data, x_col, y_col, 
                            x_label=x_col, y_label=y_col, 
                            x_threshold=1, y_threshold=1) {
  label <- Protein.IDs <- NULL
  if(!all(c('label','Protein.IDs') %in% names(data))) {
    message('The data is missing the "label" or "Protein.IDs" column!',
         call.=FALSE)
  } else {
    mymax <- max(abs(data[c(x_col, y_col)]), na.rm=TRUE)
    plotly_limits <- c(-mymax, mymax) * 1.1
    g <- ggplot(data, aes_string(x=x_col, y=y_col)) + 
      theme_imb() + ggtitle('Scatterplot') + 
      geom_hline(aes(yintercept=0), color='grey', size=.2) + 
      geom_vline(aes(xintercept=0), color='grey', size=.2) +
      geom_hline(yintercept=c(-1,1),linetype='dashed',color='red', size=.1) +
      geom_vline(xintercept=c(-1,1),linetype='dashed',color='red', size=.1) +
      geom_point(aes(text = sprintf("Label: %s<br />First ProtID: %s", 
                                    label, sub(';.*','', Protein.IDs)))) +
      scale_x_continuous(x_label, breaks=seq(-100,100,1), 
                         minor_breaks=seq(-100,100,.5), limits=plotly_limits) + 
      scale_y_continuous(y_label, breaks=seq(-100,100,1), 
                         minor_breaks=seq(-100,100,.5), limits=plotly_limits)
    gg <- plotly::ggplotly(g)
    print(gg)
  }
}


