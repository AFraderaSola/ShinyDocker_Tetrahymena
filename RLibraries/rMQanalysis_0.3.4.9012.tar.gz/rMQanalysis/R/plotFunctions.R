#' Creates a barplot for the missed cleavages
#' 
#' This function creates the barplot of the missed cleavage data frame, created
#' by the \code{getMissedCleavageDF} function. It still needs the sample_data 
#' list. The sample_data list has some informations about the dataset, for 
#' example the digestion enzymes.
#' @param data the data frame created by \code{getMissedCleavageDF}
#' @param sample_data a list with informations about the dataset
#' @param title an additional title
#' @param enzyme set an enzyme manually
#' @export
#' @import ggplot2
#' @return Returns a graph which can be printed
#' @examples
#' # read the peptides list, filter and create the missed cleavage data frame
#' peptides <- 
#'   read.delim(system.file('extdata', 
#'                          'SILAC_1to3_peptides.txt', 
#'                          package='rMQanalysis'))
#' peptides_filtered <- filterWholeDataset(peptides, by_bysite=FALSE)
#' mc_df <- getMissedCleavageDF(peptides_filtered)
#' 
#' # create the missed cleavages plot and save it
#' mc_plot <- plotMissedCleavages(mc_df, enzyme='Trypsin')
#' print(mc_plot)
#' 
#' # It is possible to overwrite the title by
#' mc_plot <- mc_plot + ggtitle('my new title')
#' print(mc_plot)
plotMissedCleavages <- function(data, 
                                sample_data=list(), 
                                title='', 
                                enzyme='"set enzyme"') {
  index <- amount <- round_amount <- NULL
  if(title != "") {
    title <- paste0(title,"\n")
  }
  if(length(sample_data) == 0) {
    sample_data$enzymes = c(enzyme)
  }
  sorted_amount <- sort(data$round_amount)
  text_y <- sorted_amount[[1]] + 5
  if(text_y + 6 >= sorted_amount[[2]]) {
    text_y <- sorted_amount[[2]] + 5
  }
  ggplot(data) + 
    geom_bar(stat="identity",
             aes(x=index,y=amount),
             colour="black",
             fill="grey") +
    geom_text(y=text_y,aes(x=index,label=round_amount)) +
    xlab("Missed Cleavages") + ylab("% of missed cleavage") +
    ggtitle(sprintf("%sMissed cleavages of %s",title,
                    sample_data$enzymes[[1]])) +
    ylim(0,100) + theme_imb()
}


#' This function will plot the imputed and original values in a density graph.
#' 
#' The function expects the \code{$imputed_histogram} part of the 
#' \code{imputeNormRandomNumbersPerColumn} function result.
#' 
#' @param imputed_histogram output of \code{imputeNormRandomNumbersPerColumn}
#' @param ncol number of graphs per row. Should be similar to number of 
#' replicates
#' @export
#' @examples
#' \dontrun{
#' imputed_values_list <- 
#'     imputeNormRandomNumbersPerColumn(data_identified[30:36])
#' graph <- plotImputedValues(imputed_values_list$imputed_histogram)
#' print(graph)
#' graph_title <- graph + ggtitle('my new title')
#' print(graph_title)
#' }
#' @import ggplot2
#' @return a ggplot graph to print or save with ggsave
plotImputedValues <- function(imputed_histogram, ncol=1) {
  value_type <- value <- NULL
  legend_title <- 'Value type'
  graph <- 
    ggplot(imputed_histogram,
           aes(x=value,
               fill=as.factor(value_type),
               colour=as.factor(value_type))) + 
    geom_density(alpha=.3, na.rm=TRUE) + 
    facet_wrap(~ column, ncol = ncol) +
    ggtitle('Comparison of imputed and measured values, grouped by replicate') +
    scale_fill_manual(values=c('red','blue'), name=legend_title) +
    scale_colour_manual(values=c('red','blue'), name=legend_title)
  return(graph)
}


#' This function will create a boxplot with automatically labeling outliers.
#' 
#' The function expects a data frame, for example a proteinGroups table. It 
#' uses as default value the \code{Ratio.H.L} column for printing, but this 
#' editable. In case of a forward or reverse experiment, it is possible to 
#' define the experiment name as an argument. It will search for the right
#' column name (please do not forget the dot "\code{.for}").
#' To label the outliers, we have to define a column name, the default is 
#' \code{Gene.names}. 
#' In case of very much outliers, it is possible to reduce the fontsize and to 
#' activate \code{jitter}. Jitter will print the labels not right next to the 
#' point, but somewhere on the same y position. The default values is 0, so 
#' no jitter. A good value might be up to 0.4.
#' It is also possible to reverse the boxplot, to compare a forward and reverse
#' experiment.
#' 
#' @param data_set the data set, for example proteinGroups table
#' @param colname the column name with the y data
#' @param experiment the experiment name (will be append to the colname)
#' @param labels the column name with the labels
#' @param fontsize you might want to minimize the font size
#' @param jitter to reduce overplotting, try something between 0 and .4
#' @param reverse you can reverse the boxplot
#' @export
#' @examples
#' \dontrun{
#' plotRatioBoxplot(data_identified, labels='Protein.IDs')
#' plotRatioBoxplot(data_identified, experiment='.for', jitter=.4)
#' plotRatioBoxplot(data_identified, experiment='.rev', reverse=TRUE, jitter=.4)
#' plot <- plotRatioBoxplot(data_identified) + xlab('my x axis label')
#' }
#' @import ggplot2
#' @importFrom grDevices boxplot.stats
#' @return a ggplot graph to print or save with ggsave
plotRatioBoxplot <- function(data_set, 
                             colname='Ratio.H.L', 
                             experiment='', 
                             labels='Gene.names', 
                             fontsize=3,  
                             jitter=0,
                             reverse=FALSE) {
  outlier <- y <- NULL
  data_column <- paste0(colname,experiment)
  if(!data_column %in% names(data_set)) {
    stop(sprintf('column "%s" not found', data_column))
  }
  if(!labels %in% names(data_set)) {
    stop(sprintf('labels column "%s" not found', labels))
  }
  plot_data <- log2(data_set[[data_column]])
  ylabel <- 'log2 ( H/L )'
  if(reverse) {
    plot_data <- log2(1 / data_set[[data_column]])
    ylabel <- 'log2 ( L/H )'
  }
  my_data <- data.frame(y=plot_data,
                        labels=data_set[[labels]])
  boxplot_stats <- grDevices::boxplot.stats(my_data$y)
  my_data$outlier <-  
    my_data$y > boxplot_stats$stats[5] | 
    my_data$y < boxplot_stats$stats[1]
  
  labels_df <- subset(my_data,outlier == TRUE)
  labels_df <- labels_df[order(labels_df$y), ]
  
  exp_boxplot <- 
    ggplot(my_data, aes(x=factor(0),y=y)) + 
    geom_boxplot(na.rm=TRUE) +
    ylab(ylabel) + xlab('experiment') 
  
  if(jitter > 0) {
    exp_boxplot <- exp_boxplot + 
      geom_text(data=labels_df,
                aes(label=labels),
                position=position_jitter(width=jitter),
                size=fontsize, na.rm=TRUE)
  } else {
    if(nrow(labels_df) >= 1) {
      left_labels <- labels_df[seq(1,nrow(labels_df),by=2),]
      exp_boxplot <- exp_boxplot + geom_text(data=left_labels,
                                             aes(label=labels),
                                             hjust=1.05,
                                             size=fontsize, na.rm=TRUE)  
    }
    if(nrow(labels_df) >= 2) {
      right_labels <- labels_df[seq(2,nrow(labels_df),by=2),]
      exp_boxplot <- exp_boxplot + geom_text(data=right_labels,
                                               aes(label=labels),
                                               hjust=-.05,
                                               size=fontsize, na.rm=TRUE)
    }
  }
  return(exp_boxplot)
}


#' Calculating the incorporation rate and creating a histogram for 
#' visualisation.
#' 
#' This function reads the peptide.txt file or an already filtered data frame
#' and calculates the incorporation of a specific heavy amino acid. Please make
#' sure to provide the amino acid with the one letter code.
#' 
#' @param data Data can be a filename or a data frame of a peptide file
#' @param aminoacid Amino acid to check for incorporation (one letter code) 
#' \emph{OR} set to \code{DML} for DiMethylLabeling
#' @param threshold Incorporation threshold to pass, set 0 to remove red line
#' @param no_filter Set to TRUE if the data frame is already filtered
#' @param remove_zeros Not count zero heavy intensities
#' @export
#' @importFrom utils read.delim
#' @examples
#' peptides_filename <- 
#'   system.file('extdata', 
#'               'SILAC_1to3_peptides.txt', 
#'               package='rMQanalysis' )
#' ic <- getIncorporationRate(peptides_filename)
#' print(ic$graph)
#' 
#' # works also with data frames
#' peptides <- 
#'   read.delim(system.file('extdata', 
#'                          'SILAC_1to3_peptides.txt', 
#'                          package='rMQanalysis' ))
#' ic <- getIncorporationRate(peptides, 'K')
#' print(ic$graph)
#' 
#' # It is possible to overwrite the title by
#' ic$graph <- ic$graph + ggtitle('my new title')
#' print(ic$graph)
#' 
#' # multiple graphs at one call needs gridExtra package
#' library(gridExtra)
#' g <- gridExtra::arrangeGrob(getIncorporationRate(peptides_filename,'R')$graph,
#'                  getIncorporationRate(peptides_filename,'K')$graph)
#' library(grid)
#' grid::grid.newpage()
#' grid::grid.draw(g)
getIncorporationRate <- function(data,
                                 aminoacid='K',
                                 threshold=95,
                                 no_filter=FALSE,
                                 remove_zeros=FALSE) {
  my_env <- environment()
  Missed.cleavages <- Intensity <- Intensity.H <- NULL
  if(typeof('') == typeof(data)) {
    filename <- data
    if(file.exists(filename)) {
      peptides <- utils::read.delim(filename)
      peptides_flt <- filterWholeDataset(peptides, by_bysite=FALSE)
    } else {
      stop(sprintf('File "%s" does not exist!', filename))
    }
  } else if(typeof(data.frame()) == typeof(data)) {
    filename <- 'data.frame()'
    peptides_flt <- data
  } else {
    stop('Could not read "data"! "getIncorporationRate" expects data.frame or filename!')
  }
  
  my_subset <- subset(peptides_flt, Intensity != 0 & Missed.cleavages == 0)
  if(aminoacid != 'DML') {
    aa_column <- paste0(aminoacid, '.Count')
    if(aa_column %in% names(my_subset)) {
      my_subset <- my_subset[my_subset[,aa_column] == 1, ]
    } else {
      stop(sprintf('There is no column "%s" in the data frame.', aa_column))
    }
  }
  
  if(remove_zeros) {
    my_subset <- subset(my_subset, Intensity.H != 0)
  }
  
  my_subset <- within(my_subset,
                      incorporation_rate <- Intensity.H / Intensity * 100)
  
  incorporation_mean <- mean(my_subset$incorporation_rate, na.rm=TRUE)
  
  graph <- ggplot(my_subset, aes(x=incorporation_rate),
                  environment=my_env) + 
    geom_histogram(binwidth=2, colour="black", fill="grey") +
    coord_cartesian(xlim=c(0,100)) + theme_imb() +
    xlab('Incorporation rate') + ylab('Peptide count') +
    ggtitle(sprintf('Incorporation of %s is %.1f%%', 
                    AA(aminoacid), incorporation_mean))
  if(threshold > 0) {
    graph <- 
      graph + geom_vline(aes(xintercept=threshold), 
                         color="red", 
                         linetype="dashed", 
                         size=1)
  }
  result <- list(graph=graph,
                 passed=incorporation_mean > threshold,
                 value=incorporation_mean,
                 threshold=threshold,
                 aminoacid=AA(aminoacid),
                 n_peptides=nrow(my_subset))
  return(result)
}

#' Return content of columns for labeling in plots
#' 
#' This function returns basically the content of one column, but if there is 
#' no content, it uses the content of a fallback column. You can use this, in
#' case there are some gene names missing and you want to return the protein id
#' to have a labeled dot in your plot.
#' 
#' There is the possibility to provide a regex for each column. The regex uses
#' only the first (bracket) for replacement! In case of the first column is
#' missing, it will be replaced by \code{Protein.IDs} since we expect this 
#' column always exist. In this case, the \code{column_regex} gets applied to 
#' \code{Protein.IDs}.
#' 
#' @export
#' @param data_set the data set the function has to work on
#' @param colname the column name with the prefered content
#' @param fallback the column to use content in case of missing data
#' @param colname_regex regex to convert the prefered column (ex. 
#' \emph{'([^;]+).*'} to get only the first ID)
#' @param fallback_regex regex to convert the fallback column (ex. 
#' \emph{'([^;]+).*'} to get only the first ID)
#' @param replace_na in case of NA it will be changed to '' and replaced
#' @examples
#' pg_file <- system.file('extdata', 
#'                        'SILAC_1to3_proteinGroups.txt', 
#'                        package='rMQanalysis' )
#' # reading a small subset with one missing gene name
#' pg <- filterWholeDataset(read.delim(pg_file))[1560:1563,] 
#' # ploting the dots without label
#' plot <- ggplot(pg, aes(log2(Intensity.L), log2(Intensity.H))) + geom_point()
#' 
#' # plotting only the gene names
#' plot + geom_text(aes(label=getLabel(pg, 'Gene.names')))
#' # plotting only the gene names and replace missing ones by protein ids
#' plot + geom_text(aes(label=getLabel(pg, 'Gene.names', 'Protein.IDs')))
#' # plotting only the first protein id
#' plot + geom_text(aes(label=getLabel(pg, 'Protein.IDs', colname_regex='([^;]+).*')))
#' # compared to the complete protein id
#' plot + geom_text(aes(label=getLabel(pg, 'Protein.IDs')))
getLabel <- function(data_set, colname, 
                     fallback='', 
                     colname_regex='', 
                     fallback_regex='',
                     replace_na=TRUE) {
  colname_exists <- colname %in% names(data_set)
  fallback_exists <- fallback %in% names(data_set)
  if(!colname_exists) {
    if(!fallback_exists) {
      warning(sprintf('Column "%s" and "%s" does not exist. Using "%s" instead!', 
                      colname, fallback, 'Protein.IDs'))
      result <- as.character(data_set$Protein.IDs)
    } else {
      warning(sprintf('Column "%s" does not exist. Using "%s" instead!', 
                      colname, fallback))
      result <- rep('',nrow(data_set))
    }
  } else {
    result <- as.character(data_set[[colname]])  
  }
  if(replace_na) {
    result[is.na(result)] <- ''
  }
  if(colname_regex != '' & colname_exists) {
    result <- sub(colname_regex, '\\1', result)
  }
  if(fallback != '') {
    empty_lines <- result == ''
    result_fallback <- as.character(data_set[[fallback]])[empty_lines]
    if(fallback_regex != '') {
      result_fallback <- sub(fallback_regex, '\\1', result_fallback)
    }
    result[empty_lines] <- result_fallback
  }
  return(result)
}


#' Create a correlation matrix plot
#' 
#' use this function to create a correlation matrix for \strong{all columns} in
#' a given data set. In case there or other columns, such as 
#' \code{Protein.ids, etc}, make sure to subset your dataframe to only have 
#' numeric columns.
#' 
#' For labeling the rows and the columns, we use the column name. You can 
#' shorten the name before using the function to get a nicer result.
#' 
#' @param df a data frame with numeric values to correlate
#' @param limits define the limits to scale red to blue fade
#' @export
#' @import ggplot2
#' @importFrom reshape2 melt
#' @importFrom stats cor
#' @examples
#' # creating some sample data
#' set.seed(1234)
#' df <- data.frame(
#'    Protein.IDs=sample(c(LETTERS,letters), 50, replace=TRUE),
#'    LFQ.intensity.exp_1=sample(c(rnorm(40,5,1) + 30,rep(NA,10))),
#'    LFQ.intensity.exp_2=sample(c(rnorm(30,5,1) + 30,rep(NA,20))),
#'    LFQ.intensity.exp_3=sample(c(rnorm(35,5,1) + 30,rep(NA,15))),
#'    LFQ.intensity.expb_1=sample(c(rnorm(40,5,1) + 30,rep(NA,10))),
#'    LFQ.intensity.expb_2=sample(c(rnorm(40,5,1) + 30,rep(NA,10))),
#'    LFQ.intensity.expb_3=sample(c(rnorm(40,5,1) + 30,rep(NA,10))))
#' df <- cbind(df,log2=log2(df[grep('^LFQ',names(df))]))
#' imputed_beta_values <- 
#'    imputeBetaRandomNumbersPerColumn(df[grep('^log2.LFQ', names(df))],
#'    20,30,seed=1234)
#' df <- cbind(df,imputed_beta_values$imputed_values)
#' names(df)
#' 
#' # now renaming our selected columns and make them a bit shorter
#' df_subset <- df[grep('^imputed', names(df))]
#' names(df_subset) <- sub('imputed.log2.LFQ.intensity.', '', names(df_subset))
#' names(df_subset)
#' 
#' # using this example data frame to plot our correlation plot
#' createCorrelationPlot(df_subset)
createCorrelationPlot <- function(df, limits=c(-1,1)) {
  Var1 <- Var2 <- value <- label <- NULL
  ratio_corr <- 
    stats::cor(scale(df), use="complete.obs", method="pearson")
  
  melt_ratio_corr <- reshape2::melt(ratio_corr)
  melt_ratio_corr$label <- reshape2::melt(upper.tri(ratio_corr))[[3]]
  
  correlation_matrix_plot2 <- 
    ggplot(melt_ratio_corr, 
           aes(Var1, Var2, fill=value)) + 
    geom_tile() + 
    geom_text(data=subset(melt_ratio_corr, label), 
              aes(label=sub('^0', '', sprintf("%1.2f", value))), size=3) +
    ylim(rev(levels(melt_ratio_corr$Var2))) +
    scale_fill_gradient2(low="red4", high="steelblue", limits=limits) +
    theme(axis.text.x = element_text(angle = 90, hjust=1, vjust=.5),
          axis.title.x = element_blank(),
          axis.title.y = element_blank())
  return(correlation_matrix_plot2)
}


#' Plot log2 transformed values grouped by value counts (found in # replicates)
#' 
#' This plot expects a protein groups file which has alread log2 transformed
#' LFQ intensity columns and also columns for each experiments with value 
#' counts.
#' @param data_set The protein groups file
#' @param facet Facet wrap for each experiment
#' @param xvalue_regex The value count columns regex
#' @param yvalue_regex The log2 transformed LFQ intensities
#' @export
createValueCountPlot <- function(data_set, facet=TRUE, 
                                 xvalue_regex='^value_count_', 
                                 yvalue_regex='^log2.LFQ.intensity.') {
  value.x <- value.y <- NULL
  df <- melt(
    data_set[c('Protein.IDs',
               grep(yvalue_regex, names(data_set), value=TRUE))], 
    'Protein.IDs')
  df$variable <- sub(paste0(yvalue_regex,'([^_]+)_\\d+'), '\\1', df$variable)
  df2 <- melt(
    data_set[c('Protein.IDs',
               grep(xvalue_regex, names(data_set), value=TRUE))], 
    'Protein.IDs')
  df2$variable <- sub(paste0(xvalue_regex, '([^_]+)'), '\\1', df2$variable)
  df3 <- subset(merge(df, df2, by=c('Protein.IDs','variable')), value.y > 0)
  graph <- ggplot(df3, aes(factor(value.y), value.x, color=factor(value.y))) + 
    geom_point(position=position_jitter(width=.3), alpha=.2, na.rm=TRUE) + 
    geom_boxplot(alpha=.5, color='black', outlier.shape=3, na.rm=TRUE) + 
    scale_y_continuous(minor_breaks=seq(100), breaks=seq(0,100,5)) +
    theme_imb() + xlab('value count') + ylab('log2(LFQ intensity)') +
    ggtitle('Measured intensity grouped by value counts') +
    guides(color=FALSE)
  if(facet) {
    graph <- graph + facet_wrap(~ variable)
  }
  return(graph)
}
