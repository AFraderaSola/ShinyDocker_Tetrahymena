#' This function will impute missing values (NA) with normal distributed random
#' numbers.
#' 
#' The function expects just the columns to replace the NAs of a data set and 
#' will replace these column by column with normal distributed random numbers. 
#' 
#' @return
#' It returns the a list with two data frames. One (\code{imputed_values}) with 
#' the original and the imputed values in the same format as the original data. 
#' This data frame can be cbind to the original data set. Additionally, there 
#' will be a data frame (\code{imputed_histogram}) of the original and imputed 
#' values to  use the function \code{plotImputedValues()} to check for the 
#' distribution of imputed values.
#' 
#' @param data_set the columns to impute values, mostly the LFQ columns
#' @param reduce_mean the amount to 'reduce' the mean for the imputed values (DEPRECATED)
#' @param sd_factor factor to narrow the standard distribution
#' @param impute_data_frame logical value to create the histogram data frame
#' @param impute_prefix prefix to put infront the column names
#' @param seed set a seed for the random number generator (default is 1234)
#' @param modify_mean the value to modify (+/-) the mean for imputing
#' @importFrom stats rnorm sd
#' @export
#' @examples
#' data_identified <- 
#'    data.frame(Protein.IDs=c(letters,LETTERS),
#'               Intensity.A=c(rnorm(40),rep(NA,12)),
#'               Intensity.B=c(rnorm(35),rep(NA,17)),
#'               Intensity.C=c(rnorm(45),rep(NA,7)),
#'               Intensity.D=c(rnorm(42),rep(NA,10)))
#' imputed_values_list <- 
#'     imputeNormRandomNumbersPerColumn(data_identified[2:5])
#' data_identified <- cbind(data_identified,
#'                          imputed_values_list$imputed_values)
imputeNormRandomNumbersPerColumn <- function(data_set,
                                             reduce_mean=4,
                                             sd_factor=.2,
                                             impute_data_frame=TRUE,
                                             impute_prefix='imputed.',
                                             seed=1234,
                                             modify_mean=NA) {
  original_data <- data_set
  if(!is.na(modify_mean)) {
    mylog(sprintf('modify_mean "%s" will be used instead of reduce_mean', modify_mean),
          'INFO', 0)
  } else {
    mylog('reduce_mean is declared as deprecated and will be removed in future versions',
          'DEPRECATED', 0)
    modify_mean <- - reduce_mean
  }
  if(impute_data_frame) {
    imputed_values_df  <- data.frame()
  }
  set.seed(seed)
  imputing_data <- data.frame()
  for(col_name in names(data_set)){
    count_NA_values <- sum(is.na(data_set[[col_name]]))
    column_mean <- mean(data_set[[col_name]], na.rm=TRUE)
    standard_deviation <- sd(data_set[[col_name]], na.rm=TRUE)
    random_numbers <- stats::rnorm(count_NA_values,
                                   mean=column_mean + modify_mean,
                                   sd=standard_deviation * sd_factor)
    seed_as_string <- ifelse(is.null(seed),'NULL',seed)
    imputing_data <- 
      rbind(imputing_data, 
            data.frame(column=col_name,
                       mean=column_mean,
                       standard_deviation=standard_deviation,
                       NA_values=count_NA_values,
                       modify_mean=modify_mean,
                       sd_factor=sd_factor,
                       new_mean=column_mean + modify_mean,
                       new_sd=standard_deviation * sd_factor,
                       seed=seed_as_string))
    if(impute_data_frame) {
      imputed_values_df <- 
        rbind(imputed_values_df,
              data.frame(value_type=c('original'),
                         value=na.omit(data_set[[col_name]]),
                         column=c(col_name),
                         stringsAsFactors=FALSE))
      if(length(random_numbers) > 0) {
        imputed_values_df <- 
          rbind(imputed_values_df,
                data.frame(value_type=c('imputed'),
                           value=random_numbers,
                           column=c(col_name)))
      }
    }
    data_set[col_name] <- replace(data_set[col_name],
            is.na(data_set[col_name]),
            random_numbers)
  }
  colnames(data_set) <- paste0(impute_prefix, names(data_set))
  result <- list(imputed_values=data_set,
                 imputing_data=imputing_data,
                 original_data=original_data)
  if(impute_data_frame) {
    result$imputed_histogram <- imputed_values_df
  }
  return(result)
}

#' This function will impute missing values (NA) with beta distributed random
#' numbers.
#' 
#' The function expects just the columns to replace the NAs of a data set and 
#' will replace these column by column with beta distributed random numbers. 
#' The parameters \code{start} and \code{end} have two different meanings. If 
#' the values are smaller then 1, the value represents the percentage of the 
#' smalles values in your data set. If the value is bigger then one, it is 
#' taken as the exact borders for the distribution.
#' 
#' @return
#' It returns the a list with two data frames. One (\code{imputed_values}) 
#' with the original and the imputed values in the same format as the original 
#' data. This data frame can be cbind to the original data set. Additionally, 
#' there will be a data frame (\code{imputed_histogram}) of the original and 
#' imputed values to  use the function \code{plotImputedValues()} to check for 
#' the distribution of imputed values. 
#' 
#' @param data_set the columns to impute values, mostly the LFQ columns
#' @param start if <= 1 it is taken as percentage of the smalles values, 
#' otherwise as the smalles value
#' @param end if <= 1 it is taken as percentage of the highest values, 
#' otherwise as the highest value
#' @param shape1 non-negative parameters of the Beta distribution
#' @param shape2 non-negative parameters of the Beta distribution
#' @param impute_data_frame logical value to create the histogram data frame
#' @param impute_prefix prefix to put infront the column names
#' @param seed set a seed for the random number generator (default is 1234)
#' @export
#' @importFrom stats rbeta
#' @examples
#' data_identified <- 
#'    data.frame(Protein.IDs=c(letters,LETTERS),
#'               Intensity.A=c(rnorm(40),rep(NA,12)),
#'               Intensity.B=c(rnorm(35),rep(NA,17)),
#'               Intensity.C=c(rnorm(45),rep(NA,7)),
#'               Intensity.D=c(rnorm(42),rep(NA,10)))
#' imputed_values_list <- 
#'     imputeBetaRandomNumbersPerColumn(data_identified[2:5])
#' data_identified <- cbind(data_identified,
#'                          imputed_values_list$imputed_values)
imputeBetaRandomNumbersPerColumn <- function(data_set,
                                             start=.01,
                                             end=.05,
                                             shape1=2,
                                             shape2=2,
                                             impute_data_frame=TRUE,
                                             impute_prefix='imputed.',
                                             seed=1234) {
  original_data <- data_set
  if(impute_data_frame) {
    imputed_values_df  <- data.frame()
  }
  set.seed(seed)
  imputing_data = data.frame()
  for(col_name in names(data_set)){
    if(start <= 1) {
      # min_index <- 
      #   ifelse(as.integer(length(data_set[[col_name]]) * start) < 1, 
      #          1, 
      #          as.integer(length(data_set[[col_name]]) * start))
      # beta_min <- sort(data_set[[col_name]], na.last=TRUE)[min_index]
      beta_min <- quantile(data_set[[col_name]], start, na.rm=TRUE)
    } else {
      beta_min <- start
    }
    if(end <= 1) {
      # max_index <- 
      #   ifelse(as.integer(length(data_set[[col_name]]) * end) < 1, 
      #          1, 
      #          as.integer(length(data_set[[col_name]]) * end))
      # beta_max <- sort(data_set[[col_name]], na.last=TRUE)[max_index]
      beta_max <- quantile(data_set[[col_name]], end, na.rm=TRUE)
    } else {
      beta_max <- end
    } 
    count_NA_values <- sum(is.na(data_set[[col_name]]))
    seed_as_string <- ifelse(is.null(seed),'NULL',seed)
    imputing_data <- 
      rbind(imputing_data, 
            data.frame(column=col_name,
                       start=start,
                       end=end,
                       shape1=shape1,
                       shape2=shape2,
                       NA_values=count_NA_values,
                       beta_min=beta_min,
                       beta_max=beta_max,
                       seed=seed_as_string))
    random_numbers <- stats::rbeta(count_NA_values,
                                   shape1,
                                   shape2) * (beta_max - beta_min) + beta_min
    if(impute_data_frame) {
      imputed_values_df <- 
        rbind(imputed_values_df,
              data.frame(value_type=c('original'),
                         value=na.omit(data_set[[col_name]]),
                         column=c(col_name),
                         stringsAsFactors=FALSE))
      if(length(random_numbers) > 0) {
        imputed_values_df <- 
          rbind(imputed_values_df,
                data.frame(value_type=c('imputed'),
                           value=random_numbers,
                           column=c(col_name)))
      }
    }
    data_set[col_name] <- replace(data_set[col_name],
                                  is.na(data_set[col_name]),
                                  random_numbers)
  }
  colnames(data_set) <- paste0(impute_prefix, names(data_set))
  result <- list(imputed_values=data_set,
                 imputing_data=imputing_data,
                 original_data=original_data)
  if(impute_data_frame) {
    result$imputed_histogram <- imputed_values_df
  }
  return(result)
}



#' This function will impute missing values (NA) with beta distributed random
#' numbers.
#' 
#' The function expects just the columns to replace the NAs of a data set and 
#' will replace these column by column with beta distributed random numbers. 
#' The parameters \code{start} and \code{end} have two different meanings. If 
#' the values are smaller then 1, the value represents the percentage of the 
#' smalles values in your data set. If the value is bigger then one, it is 
#' taken as the exact borders for the distribution.
#' 
#' @return
#' It returns the a list with two data frames. One (\code{imputed_values}) 
#' with the original and the imputed values in the same format as the original 
#' data. This data frame can be cbind to the original data set. Additionally, 
#' there will be a data frame (\code{imputed_histogram}) of the original and 
#' imputed values to  use the function \code{plotImputedValues()} to check for 
#' the distribution of imputed values. 
#' 
#' @param data_set the columns to impute values, mostly the LFQ columns
#' @param start if <= 1 it is taken as percentage of the smalles values, 
#' otherwise as the smalles value
#' @param end if <= 1 it is taken as percentage of the highest values, 
#' otherwise as the highest value
#' @param shape1 non-negative parameters of the Beta distribution
#' @param shape2 non-negative parameters of the Beta distribution
#' @param impute_data_frame logical value to create the histogram data frame
#' @param impute_prefix prefix to put infront the column names
#' @param seed set a seed for the random number generator (default is 1234)
#' @export
#' @importFrom stats rbeta
#' @examples
#' data_identified <- 
#'    data.frame(Protein.IDs=c(letters,LETTERS),
#'               Intensity.A=c(rnorm(40),rep(NA,12)),
#'               Intensity.B=c(rnorm(35),rep(NA,17)),
#'               Intensity.C=c(rnorm(45),rep(NA,7)),
#'               Intensity.D=c(rnorm(42),rep(NA,10)))
#' imputed_values_list <- 
#'     old.imputeBetaRandomNumbersPerColumn(data_identified[2:5])
#' data_identified <- cbind(data_identified,
#'                          imputed_values_list$imputed_values)
old.imputeBetaRandomNumbersPerColumn <- function(data_set,
                                             start=.01,
                                             end=.05,
                                             shape1=2,
                                             shape2=2,
                                             impute_data_frame=TRUE,
                                             impute_prefix='imputed.',
                                             seed=1234) {
  original_data <- data_set
  if(impute_data_frame) {
    imputed_values_df  <- data.frame()
  }
  set.seed(seed)
  imputing_data = data.frame()
  for(col_name in names(data_set)){
    if(start <= 1) {
      min_index <-
        ifelse(as.integer(length(data_set[[col_name]]) * start) < 1,
               1,
               as.integer(length(data_set[[col_name]]) * start))
      beta_min <- sort(data_set[[col_name]], na.last=TRUE)[min_index]
      # beta_min <- quantile(data_set[[col_name]], start, na.rm=TRUE)
    } else {
      beta_min <- start
    }
    if(end <= 1) {
      max_index <-
        ifelse(as.integer(length(data_set[[col_name]]) * end) < 1,
               1,
               as.integer(length(data_set[[col_name]]) * end))
      beta_max <- sort(data_set[[col_name]], na.last=TRUE)[max_index]
      # beta_max <- quantile(data_set[[col_name]], end, na.rm=TRUE)
    } else {
      beta_max <- end
    } 
    count_NA_values <- sum(is.na(data_set[[col_name]]))
    seed_as_string <- ifelse(is.null(seed),'NULL',seed)
    imputing_data <- 
      rbind(imputing_data, 
            data.frame(column=col_name,
                       start=start,
                       end=end,
                       shape1=shape1,
                       shape2=shape2,
                       NA_values=count_NA_values,
                       beta_min=beta_min,
                       beta_max=beta_max,
                       seed=seed_as_string))
    random_numbers <- stats::rbeta(count_NA_values,
                                   shape1,
                                   shape2) * (beta_max - beta_min) + beta_min
    if(impute_data_frame) {
      imputed_values_df <- 
        rbind(imputed_values_df,
              data.frame(value_type=c('original'),
                         value=na.omit(data_set[[col_name]]),
                         column=c(col_name),
                         stringsAsFactors=FALSE))
      if(length(random_numbers) > 0) {
        imputed_values_df <- 
          rbind(imputed_values_df,
                data.frame(value_type=c('imputed'),
                           value=random_numbers,
                           column=c(col_name)))
      }
    }
    data_set[col_name] <- replace(data_set[col_name],
                                  is.na(data_set[col_name]),
                                  random_numbers)
  }
  colnames(data_set) <- paste0(impute_prefix, names(data_set))
  result <- list(imputed_values=data_set,
                 imputing_data=imputing_data,
                 original_data=original_data)
  if(impute_data_frame) {
    result$imputed_histogram <- imputed_values_df
  }
  return(result)
}


#' This function will impute missing values (NA) with random numbers based on
#' the actual distribution of values.
#' 
#' The function expects just the columns to replace the NAs of a data set and 
#' will replace experiment by experiment the missing values. The distribution 
#' is calculated for each experiment seperately and the values are imputed
#' with center of the median of measured values.
#' If there are no measured values and only NAs, we use a defined quantile of
#' the dataset as center. 
#' The parameter \code{na_replace} has two different meanings. If it is between
#' 0 and 1, it is defined as the quantile of the distribution. Else, it is 
#' defined as center for missing values. 
#' 
#' @return
#' It returns the a list with three data frames. One (\code{imputed_values}) 
#' with the original and the imputed values in the same format as the original 
#' data. This data frame can be cbind to the original data set. Additionally, 
#' there will be a data frame (\code{imputed_histogram}) of the original and 
#' imputed values to  use the function \code{plotImputedValues()} to check for 
#' the distribution of imputed values. 
#' 
#' @param data_set the columns to impute values, mostly the LFQ columns
#' @param min_distr minimum number of measured values to calculate distribution
#' @param na_replace if <= 1 it is taken as quantile, otherwise as center for
#' imputing with calculated distribution
#' @param average_function function to create the density, mean or median!
#' @param impute_data_frame logical value to create the histogram data frame
#' @param impute_prefix prefix to put infront the column names
#' @param seed set a seed for the random number generator (default is 1234)
#' @export
#' @importFrom reshape2 melt
#' @examples
#' data_identified <- 
#'    data.frame(Protein.IDs=c('a','b','c','d','e'),
#'               log2.LFQ.intensity.LS_1=c(30.5,NA,30.1,30.2,NA),
#'               log2.LFQ.intensity.LS_2=c(31.1,NA,30.0,NA,NA),
#'               log2.LFQ.intensity.LS_3=c(31.2,NA,NA,30.02,NA),
#'               log2.LFQ.intensity.LS_4=c(32,32.2,31,NA,NA),
#'               log2.LFQ.intensity.SS_1=c(22.5,22.2,22.5,22.2,NA),
#'               log2.LFQ.intensity.SS_2=c(NA,NA,21.1,21.4,NA),
#'               log2.LFQ.intensity.SS_3=c(NA,23.05,NA,24.02,NA),
#'               log2.LFQ.intensity.SS_4=c(NA,22.9,NA,22.5,NA))
#' imputed_values_list <- 
#'     imputeOriginalDistributionPerExperiment(data_identified[2:9])
#' data_identified <- cbind(data_identified,
#'                          imputed_values_list$imputed_values)
#' plotImputedValues(imputed_values_list$imputed_histogram)
#' ggplot(imputed_values_list$dist_hist, aes(values)) + 
#'    geom_histogram(binwidth=.1) + facet_wrap(~ experiment)
imputeOriginalDistributionPerExperiment <- 
  function(data_set, min_distr=3, na_replace=.001, average_function='mean', 
           impute_data_frame=TRUE, impute_prefix='imputed.', seed=1234) {
    original_data <- data_set
    if(impute_data_frame) {
      imputed_values_df  <- data.frame()
    }
    set.seed(seed)
    imputing_data = data.frame()
    column_names <- unique(sub('(.*\\.[^\\.]+)_\\d+', 
                               '\\1', 
                               names(data_set), 
                               perl=TRUE))
    dist_hist_df <- data.frame()
    for(experiment in column_names) {
      df <- data_set[grep(experiment, names(data_set))]
      original_df <- data_set[grep(experiment, names(data_set))]
      experiment_name <- 
        unique(sub('.*\\.([^\\.]+)_\\d+', '\\1', names(df), perl=TRUE))
      df$value_count <- apply(original_df, 1, function(x) sum(!is.na(x)))
      df$medians <- apply(original_df, 1, average_function, na.rm=TRUE)
      melt_df <- na.omit(reshape2::melt(df[df$value_count >= min_distr,], 
                              'medians', names(original_df)))
      if(na_replace <= 1 & na_replace > 0) {
        na_value <- quantile(melt_df$value, c(na_replace))
      } else {
        na_value <- na_replace
      }
      dist_hist <- melt_df$value - melt_df$medians
      count_NA_values <- sum(is.na(original_df))
      seed_as_string <- ifelse(is.null(seed),'NULL',seed)
      imputing_data <- 
        rbind(imputing_data, 
              data.frame(experiment=experiment_name,
                         min_distr=min_distr,
                         na_replace=na_replace,
                         nas_imputed=na_value,
                         NA_values=count_NA_values,
                         seed=seed_as_string))
      dist_hist_df <- rbind(dist_hist_df,
                            data.frame(experiment=experiment_name,
                                       values=dist_hist))
      
      imp_df <- t(apply(original_df, 1, function(x) {
        replace(x, 
                is.na(x), 
                sample(dist_hist, sum(is.na(x))) + median(x, na.rm=TRUE))
      }))
      imp_df <- t(apply(imp_df, 1, function(x) {
        replace(x, 
                is.na(x), 
                sample(dist_hist, sum(is.na(x))) + na_value)
      }))
      
      if(impute_data_frame) {
        imputed_values_df <- 
          rbind(imputed_values_df,
                data.frame(value_type=c('original'),
                           value=original_df[!is.na(original_df)],
                           column=c(experiment_name),
                           stringsAsFactors=FALSE))
        if(length(original_df[is.na(original_df)]) > 0) {
          imputed_values_df <- 
            rbind(imputed_values_df,
                  data.frame(value_type=c('imputed'),
                             value=imp_df[is.na(original_df)],
                             column=c(experiment_name)))
        }
      }
      data_set[grep(experiment, names(data_set))] <- imp_df
    }
    colnames(data_set) <- paste0(impute_prefix, names(data_set))
    result <- list(imputed_values=data_set,
                   imputing_data=imputing_data,
                   original_data=original_data,
                   dist_hist=dist_hist_df)
    if(impute_data_frame) {
      result$imputed_histogram <- imputed_values_df
    }
    return(result)
  }







