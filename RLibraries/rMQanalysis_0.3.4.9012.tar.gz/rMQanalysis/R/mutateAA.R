#' Try to mutate a sequence based on a probability string and an amino acid 
#' exchange.
#' 
#' This function is designed to modify the amino acid with the highest probabiliy
#' by a given exchange. If the exchange does not fit the amino acid, the function
#' returns NULL.
#' @export
#' @param x sequence/probability string
#' @param exchange a vector of length 2 with format c(TO, FROM)
#' @param silent suppress the warning message in case the exchange doesn't fit
#' @examples 
#' mutateAA('ARND(.11)K(.79)W(.1)V',c('F','K'))
mutateAA <- function(x, exchange, silent=FALSE) {
  probVector <- rMQanalysis::probabilityToVector(x)
  if(length(exchange) != 2) {
    stop('exchange needs to be a vector of length 2 format c(to, from)')
  }
  if(names(which.max(probVector)) == exchange[2]) {
    new_seq <- names(probVector)
    new_seq[which.max(probVector)] <- exchange[1]
    return(paste(new_seq, collapse=''))
  } else {
    if(!silent) warning("we couldn't make the exchange!", call.=FALSE)
    return(NULL)
  }
}
