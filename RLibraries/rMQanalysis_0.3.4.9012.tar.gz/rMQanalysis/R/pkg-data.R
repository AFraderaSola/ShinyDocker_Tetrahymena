#' Just a test dataset without NA values to check the filter funtions
#' 
#' This is not a real dataset, but we will use this to do automated testing and
#' other stuff with the provided functions
#' 
#' @docType data
#' @keywords datasets
#' @format A data frame with 95 rows and 32 variables
#' @name proteinGroups
NULL
# 
# #' Just a test dataset with NA values to check the filter funtions
# #' 
# #' This is not a real dataset, but we will use this to do automated testing and
# #' other stuff with the provided functions
# #' 
# #' @docType data
# #' @keywords datasets
# #' @format A data frame with 95 rows and 32 variables
# #' @name proteinGroups_withNA
# NULL

#' Aminoacid masses, abbreviations and formulars
#' @format A data frame with 21 rows and 6 columns
#' \describe{
#'   \item{full}{full name of amino acid}
#'   \item{formular}{chemical formular of the amino acid}
#'   \item{three}{3 letter code}
#'   \item{one}{1 letter code}
#'   \item{monoisotopic_mass}{mass of the monoisotopic peak}
#'   \item{average_mass}{average mass}
#' }
#' @source \url{http://www.matrixscience.com/help/aa_help.html}
'aminoacid_mass'