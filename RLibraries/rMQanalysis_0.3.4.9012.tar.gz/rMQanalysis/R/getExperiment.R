#' This function expects a protein groups data frame or a vector with column 
#' namesand tries to extract the experiments set by MaxQuant.
#' @export
#' @param x A data frame or a vector with column names
#' @param regex An alternative regex
#' @examples 
#' data_frame_column_names <- 
#'   c('Protein.IDs', 'Intensity', 'Intensity.exp.a_1', 'Intensity.exp.a_2',
#'     'Intensity.exp.a_3', 'Intensity.exp.b_1', 'Intensity.exp.b_2', 
#'     'Intensity.exp.b_3')
#' my_experiments <- getExperiments(data_frame_column_names)
getExperiments <- function(x, regex='^Intensity[\\.|\\ ]') {
  if(is.data.frame(x)) {
    column_names <- names(x)
  } else if(is.vector(x)) {
    column_names <- x
  } else {
    stop('We expect a vector or a data frame as an input!', call.=FALSE)
  }
  
  intensity_columns <- grep(regex, column_names, value=TRUE)
  matching_intensity_columns <- 
    grepl(paste0(regex, '(.*)_\\d+'), intensity_columns)
  
  if(!all(matching_intensity_columns)) {
    stop(sprintf('There is one experiment defined without replicate number (%s)!\n',
                 intensity_columns[!matching_intensity_columns]),
         'Please use "_1" in case of a single replicate.',
         call.=FALSE)
  }
  unique_experiments <- 
    unique(gsub(paste0(regex, '(.*)_\\d+'),
              '\\1',
              intensity_columns))
  return(unique_experiments)
}