#' This function creates a boxplot for ratio values
#' 
#' @param pg_ratios The ratio data frame
#' @param log2_column The column name of the log2 values
#' @param max_label The maximum number of labeled protein for lower and upper end.
#' @export
#' @import ggplot2
#' @importFrom ggrepel geom_text_repel
createRatioBoxplot <- function(pg_ratios, log2_column, max_label=10) {
  plot_label <- NULL
  y_label <- sub('\\( ', '(', sub('^log2\\.Ratio\\.(.)\\.(.)\\.(normalized)?.*', 
                                  'log2(\\3 Ratio \\1/\\2)', 
                                  log2_column))
  outlier_borders <-
    grDevices::boxplot.stats(
      pg_ratios[[log2_column]]
    )$stats[c(1,5)]
  
  top_outlier <- maxOutliers(pg_ratios[[log2_column]], 
                             lower_limit=outlier_borders[1], upper_limit=outlier_borders[2],
                             upper_max=max_label, lower_max=max_label)
  gbox <- 
    ggplot(pg_ratios, 
           aes_string(factor(1), log2_column)) +
    geom_boxplot(na.rm=TRUE, outlier.alpha=.3) +
    theme_bw() + ylab(y_label) +
    theme(axis.title.x=element_blank(), axis.text.x=element_blank())
  if(length(top_outlier) > 0) {
    gbox <- gbox +
      ggrepel::geom_text_repel(data=pg_ratios[unique(top_outlier),], 
                               aes(label=plot_label)) 
  }
  return(gbox)
}
