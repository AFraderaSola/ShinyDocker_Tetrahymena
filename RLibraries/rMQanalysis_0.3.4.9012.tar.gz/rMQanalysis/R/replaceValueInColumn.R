#' Replacing a value in specific columns
#' @export
#' @param data_set the dataset we want to replace
#' @param col_regex a regex to select the column
#' @param old the old value we want to replace
#' @param new the new value we want to set
#' @examples 
#' \dontrun{
#' pg_ident <- replaceValueInColumn(pg_ident, '^LFQ', 0, NA)
#' }
replaceValueInColumn <- function(data_set, col_regex, old=0, new=NA) {
  selected_columns <- getColumnIndex(data_set, col_regex)
  data_set[selected_columns][ 
    data_set[selected_columns] == old ]  <- new
}
