#' Theme with IMB presets for ggplot.
#' 
#' Themes set the general aspect of the plot such as the colour of the 
#' background, gridlines, the size and colour of fonts. It uses the ggplot2
#' theme_bw() function and adds some parameters. Check \code{?theme_bw} to get
#' further help.
#' @export
#' @param base_size base font size
#' @param base_family base font family
#' @examples
#' p <- ggplot(mtcars) + geom_point(aes(x = wt, y = mpg,
#' colour=factor(gear))) + facet_wrap(~am)
#' 
#' p
#' p + theme_imb()
theme_imb <- function (base_size = 12, base_family = "") {
  half_line <- base_size/2
  theme_bw(base_size = base_size, base_family = base_family) %+replace% 
    theme(plot.title=element_text(size=rel(1.2), margin=margin(b=half_line * 1.8)),
          axis.title.y=element_text(angle = 90, margin=margin(r=half_line * 1.8)),
          axis.title.x=element_text(margin=margin(t=half_line * 1.8))) 
}

#' Theme with IMB presets for ggplot for small figures.
#' 
#' Themes set the general aspect of the plot such as the colour of the 
#' background, gridlines, the size and colour of fonts. It uses the ggplot2
#' theme_bw() function and adds some parameters. Check \code{?theme_bw} to get
#' further help.
#' @export
#' @param base_size base font size
#' @param base_family base font family
#' @examples
#' p <- ggplot(mtcars) + geom_point(aes(x = wt, y = mpg,
#' colour=factor(gear))) + facet_wrap(~am)
#' 
#' p + # for this plot we need to set only min and max breaks on both axis
#' scale_x_continuous(breaks=range(labeling::extended(min(mtcars$wt), 
#'                                                    max(mtcars$wt), 
#'                                                    m=3)),
#'                    minor_breaks=labeling::extended(min(mtcars$wt), 
#'                                                    max(mtcars$wt), 
#'                                                    m=9)) +
#'   scale_y_continuous(breaks=range(labeling::extended(min(mtcars$mpg), 
#'                                                      max(mtcars$mpg), 
#'                                                      m=2, 
#'                                                      Q=c(1,5,2,4,3,6))),
#'                      minor_breaks=labeling::extended(min(mtcars$mpg), 
#'                                                      max(mtcars$mpg), 
#'                                                      m=8))
#' p + theme_imb_small()
theme_imb_small <- function (base_size = 9, base_family = "") {
  half_line <- base_size/2
  theme_bw(base_size = base_size, base_family = base_family) %+replace% 
    theme(plot.title=element_text(size=rel(1.2), margin=margin(b=half_line * 1.8)),
          axis.title.y=element_text(angle = 90, margin=margin(r=half_line * -1.5)),
          axis.title.x=element_text(margin=margin(t=half_line * -1.8)))
}


#' Creates a data frame with all informations about the missed cleavage
#' 
#' This function creates a data frame with all informations about the missed 
#' cleavages in a peptides table. Using this data frame, it is possible to plot
#' the information with the \code{plotMissedCleavage} function.
#' @param data the filtered peptides data frame
#' @export
#' @return A data frame with informations about the missed cleavage
#' @examples
#' peptides_filename <- 
#'   system.file('extdata', 
#'               'SILAC_1to3_peptides.txt', 
#'               package='rMQanalysis' )
#' peptides <- read.delim(peptides_filename)
#' peptides_filtered <- filterWholeDataset(peptides, by_bysite=FALSE)
#' mc_df <- getMissedCleavageDF(peptides_filtered)
getMissedCleavageDF <- function(data) {
  missed_cleavages <- data.frame(index=c(0,1,2))
  missed_cleavages$count <- 
    sapply(missed_cleavages$index,function(x) {
      sum(data$Missed.cleavages == x)
    })
  missed_cleavages_total <- sum(missed_cleavages$count)
  missed_cleavages$amount <-
    sapply(missed_cleavages$count,
           function(x){x*100/missed_cleavages_total})
  missed_cleavages$round_amount <- round(missed_cleavages$amount,1)
  mylog(sprintf("missed cleavages: 0 = %.1f; 1 = %.1f; 2 = %.1f",
          missed_cleavages$amount[1],
          missed_cleavages$amount[2],
          missed_cleavages$amount[3]))
  return(missed_cleavages)
}

#' Creates the enrichement curve within a volcano plot.
#' 
#' This function expects a c and s0 value and will return a geom_path object
#' to use within ggplot. The function uses the following equation:
#' y = c / (x - s0) + -log10(pvalue)
#' 
#' @param c defines the steepness of the curve
#' @param s0 defines the minimum fold change
#' @param pvalue the p-value threshold
#' @param step used to generate the x and y values
#' @param xlim calculate the y values up to this x value
#' @param linetype the linetype for representation (1=solid, 2=dashed etc)
#' @param size the size of the line
#' @export
#' @return A geom_path to add to a ggplot
#' @examples
#' ggplot() +
#'   createEnrichmentCurve(1,1)
createEnrichmentCurve <- function(c, s0, pvalue=1, step=.01, xlim=50,
                                  linetype=2, size=.1) {
  x <- seq(s0,xlim,step)
  y <- c / (x - s0) + -log10(pvalue)
  return(annotate("path", 
                  x=c(-x,NA,x), 
                  y=c(y,NA,y), 
                  linetype=linetype, size=size))
}


#' Create a data frame with all possible unique permutation of a list. Very 
#' usefull to create all available scatter plots for example.
#' 
#' This functions will create a data frame of all unique combinations of 
#' names (or numbers) in a list. It is usefull to create plots of all available
#' columns in a data frame, or plot all columns against one specific. Check the
#' examples below.
#' 
#' @param names a vector with names to permutate
#' @param compare_to a number/index to compare the list to
#' @param include_itself includes the first or compare_to element itself
#' @export
#' @return A data frame with all permutations, one per row.
#' @examples
#' library(ggplot2)
#' # creating some test data
#' test_df <- data.frame(a=rnorm(1000),
#'                       b=rnorm(1000,2),
#'                       c=rnorm(1000,5),
#'                       d=rnorm(1000,3))
#'                       
#' # defining a function to plot the data 
#' # x[[1]] is the 1st column name, x[[2]] the 2nd
#' f <- function(x, data_frame) {
#'   ggplot(data_frame, aes_string(x[[1]], x[[2]])) + geom_point()
#' }
#' 
#' # since permuteNames returns a data frame, we use apply to execute each plot
#' apply(permuteNames(names(test_df)), 1, f, data_frame=test_df)
#' # we can also compare all columes just against column 4
#' apply(permuteNames(names(test_df), compare_to=4), 1, f, data_frame=test_df)
#' 
#' # doing something more complicated
#' # adding column with condition to test_df
#' test_df$condition <- rep(c('a','b'),each=500)
#' 
#' #defining new function which colors by this condition
#' f2 <- function(x, data_frame) {
#'   ggplot(data_frame, aes_string(x=x[[1]], y=x[[2]], color='condition')) + 
#'   geom_point() + ggtitle(sprintf('my plot %s vs %s', x[[1]], x[[2]]))
#' }
#' 
#' # make sure to only use the permuteNames function on the data columns ([-5])
#' apply(permuteNames(names(test_df)[-5], compare_to=4), 
#'       1, 
#'       f2, 
#'       data_frame=test_df)
permuteNames <- function(names, compare_to=0, include_itself=FALSE) {
  if(is.numeric(compare_to) & compare_to > 0 & compare_to <= length(names)) {
    permuted_df <- data.frame(name_a=names[compare_to],
                                name_b=names[-compare_to])
  } else if(compare_to == 0) { 
    permuted_df <- data.frame()
    while(length(names) > 1) {
      name_a <- names[1]
      names <- names[-1]
      for(name_b in names) {
        permuted_df <- 
          rbind(permuted_df,                           
                data.frame(name_a=name_a, name_b=name_b))
      }
    }
  } else if(compare_to >= length(names)) {
    stop('compare_to is greater then length of names')
  } else {
    stop('compare_to must be 0 or a possitive integer!')
  }
  permuted_df[] <- lapply(permuted_df, as.character)
  if(include_itself) {
    permuted_df <- rbind(c(permuted_df[1,1],permuted_df[1,1]),
                         permuted_df)
  }
  return(permuted_df)
}


#' This functions calculates a different averages between replicates within a
#' LFQ data set.
#' 
#' The functions expects some column names to work properly. First of all, it 
#' will cut of the replicate number of the LFQ columns. They \strong{(must)} be
#' append with an underline and number (ex. _1). Additionally, it expects a 
#' column with log2 converted LFQ values, beginning with log2.LFQ... And also 
#' some columns with imputed values, beginning with imputed.log2.LFQ... To 
#' create these, please use the \code{imputeBetaRandomNumbersPerColumn} or 
#' \code{imputeNormRandomNumbersPerColumn} functions provided by this package.
#' Additionally, check the examples below for a little how to.
#' 
#' The function will create some new columns for each experiment: 
#' \itemize{
#'    \item \strong{value_count_} which has the number of quantified values per
#'    experiment. 
#'    \item \strong{median/mean1_meas_} (\emph{old version: median/mean_narm_}) 
#'    is the mean or median of the measured log2 values but missing values will
#'    not be replaced by imputed and this might result in NAs in this column.
#'    \item \strong{median/mean2_naimp_meas_} (\emph{old version: median/mean_}) 
#'    which is the mean or median of the measured log2 values together with 
#'    imputed values.  
#'    \item \strong{median/mean3_less1_imp_} 
#'    (\emph{old version: median/mean_w_imp_}) uses the 
#'    \strong{median/mean1_meas_} column (\emph{old version: median/mean_narm_}), 
#'    but the NAs get replaced by the imputed median/mean. This means, if we 
#'    measure at least one value, this value overrules the imputed and will be 
#'    used.
#' }
#' 
#' @param data_set a data set with some specific columns. Please read the help!
#' @param lfq_regex a regex to remove the replicate identifier from the column
#' name
#' @export
#' @importFrom stats median
#' @return returns the data frame with the new columns
#' @examples
#' # creating some sample data, similar to MaxQuant LFQ output table
#' set.seed(1234)
#' df <- data.frame(
#'    LFQ.intensity.exp_1=sample(c(rnorm(40,5,1) + 30,rep(NA,10))),
#'    LFQ.intensity.exp_2=sample(c(rnorm(30,5,1) + 30,rep(NA,20))),
#'    LFQ.intensity.exp_3=sample(c(rnorm(35,5,1) + 30,rep(NA,15))),
#'    LFQ.intensity.expb_1=sample(c(rnorm(40,5,1) + 30,rep(NA,10))),
#'    LFQ.intensity.expb_2=sample(c(rnorm(40,5,1) + 30,rep(NA,10))),
#'    LFQ.intensity.expb_3=sample(c(rnorm(40,5,1) + 30,rep(NA,10))))
#' df <- cbind(df,log2=log2(df[grep('^LFQ',names(df))]))
#' imputed_beta_values <- 
#'    imputeBetaRandomNumbersPerColumn(df[grep('^log2.LFQ', names(df))],
#'    20,30,seed=1234)
#' df <- cbind(df,imputed_beta_values$imputed_values)
#' # This sample data looks almost like a LFQ max quant output
#' 
#' # now we can calculate the averages
#' df <- calculateAverages(df)
calculateAverages <- function(data_set, lfq_regex='^(.*)_\\d+$') {
  global_regex <- '^log2\\.LFQ\\.intensity\\..*'
  lfq_columns <- unique(gsub(lfq_regex, 
                             '\\1', 
                             grep(global_regex, names(data_set), value=TRUE)))
  if(length(lfq_columns) < 1) {
    stop(sprintf('There are no "%s"-columns in this data set!', 
                 global_regex))
  }
  for(col_name in lfq_columns) {
    # we create some column names first
    experiment <- gsub('^log2\\.LFQ\\.intensity\\.(.*)$','\\1', col_name)
    log_col_name <- paste0('^', col_name)
    imp_col_name <- paste0('^imputed\\.', col_name)
    count_col_name <- paste0('value_count_', experiment)
    mean_col_name <- paste0('mean2_naimp_meas_', experiment)
    mean_narm_col_name <- paste0('mean1_meas_', experiment)
    mean_narm_imp_col_name <- paste0('mean3_less1_imp_', experiment)
    median_col_name <- paste0('median2_naimp_meas_', experiment)
    median_narm_col_name <- paste0('median1_meas_', experiment)
    median_narm_imp_col_name <- paste0('median3_less1_imp_', experiment)
    
    # we have to figure out, on which columns we want to work on
    log_col_numbers <- 
      grep(paste0(log_col_name, '_\\d+'), colnames(data_set))
    if(length(log_col_numbers) < 1) {
      stop(sprintf('There is no column matching "%s" in the dataset.',
                   log_col_name))
    }
    imp_col_numbers <- 
      grep(paste0(imp_col_name, '_\\d+'), colnames(data_set))
    if(length(imp_col_numbers) < 1) {
      stop(sprintf('There is no column matching "%s" in the dataset.',
                   imp_col_name))
    }
    
    # now we can calculate the values and save into the columns
    # we first calculate the mean for imputed columns
    # we then calc the mean on the log column with na removed
    # the still missing values will be replaced by the mean of the 
    # imputed values
    data_set[mean_col_name] <- 
      apply(data_set[imp_col_numbers], 1, mean)
    data_set[mean_narm_col_name] <- 
      apply(data_set[log_col_numbers], 1, mean, na.rm=TRUE)
    data_set[is.nan(data_set[[mean_narm_col_name]]),mean_narm_col_name] <- NA
    data_set[mean_narm_imp_col_name] <- data_set[mean_narm_col_name]
    data_set[mean_narm_imp_col_name] <- 
      replace(data_set[mean_narm_imp_col_name],
              is.na(data_set[mean_narm_imp_col_name]),
              data_set[mean_col_name][is.na(
                data_set[mean_narm_imp_col_name])])
    
    # we do the same with median
    data_set[median_col_name] <- 
      apply(data_set[imp_col_numbers], 1, stats::median)
    data_set[median_narm_col_name] <- 
      apply(data_set[log_col_numbers], 1, stats::median, na.rm=TRUE)
    data_set[median_narm_imp_col_name] <- data_set[median_narm_col_name]
    data_set[median_narm_imp_col_name] <- 
      replace(data_set[median_narm_imp_col_name],
              is.na(data_set[median_narm_imp_col_name]),
              data_set[median_col_name][is.na(
                data_set[median_narm_imp_col_name])])
    
    # we also count, how many values we measured
    data_set[count_col_name] <- 
      apply(data_set[log_col_numbers],1,function(x) sum(!is.na(x)))
  }
  return(data_set)
}

#' Function to split a column by a seperator and elongate the table. Check the
#' help of \code{cSplit} from the \code{splitstackshape} package for more info
#' since this is just a wrapper.
#' 
#' @param data_set a data.frame to work on
#' @param splitCols the columns to split
#' @param sep a seperatot to split the column
#' @param direction a direction how to split the columns
#' @param drop drop the original column
#' @param ... Other parameters passed on to the cSplit function
#' @export
#' @importFrom splitstackshape cSplit
#' @examples
#' jnk <- data.frame(a=c('1,2,3,4,5','1,2,3','2,3'),
#'                   b=c('a,b,c,d,e','a,b,c','a,b'),
#'                   c=c(5,4,3))
#' print(jnk)
#' splitColumnBySep(jnk, 'a', ',')
#' splitColumnBySep(jnk, 'a', ',', drop=FALSE)
#' splitColumnBySep(jnk, 'a', ',', 'wide')
#' splitColumnBySep(jnk, 'a', ',', 'wide', drop=FALSE)
#' splitColumnBySep(jnk, c('a','b'), ',', 'long', drop=FALSE)
#' 
#' # usefull example
#' pg_file <- 
#'   system.file('extdata', 
#'               'SILAC_1to3_proteinGroups.txt', 
#'               package='rMQanalysis' )
#' pg <- read.delim(pg_file)
#' splitColumnBySep(pg[,c('Protein.IDs','id')], 'Protein.IDs')
splitColumnBySep <- function(data_set, splitCols, sep=';', direction='long', drop=TRUE, ...) {
  if(direction == 'long' & !drop) {
    orig_names <- sub('$','_orig', splitCols)
    df <- as.data.frame(data_set[,splitCols])
    names(df) <- orig_names
    df2 <- cbind(data_set, df)
    return(splitstackshape::cSplit(df2, splitCols, sep, 'long'))
  } else {
    return(splitstackshape::cSplit(data_set, splitCols, sep, direction, drop=drop,...))
  }
}

#' Averages columns of time series with some options of multiplying and other stuff
#' 
#' I tried to create a function which can average timeseries and models some 
#' values based on different column types. For example, if you calculate your
#' LFQ values within Max Quant with standard 2 LFQ values (high qualitity), it
#' is also possible to calculate only with minimum 1 LFQ value (low quality). 
#' Unfortunately, the values are not possible to destinguish, if they are 
#' calculated by one or more values. So the prefered way by now is to calculate
#' standard 2LFQ values... And in a second run 1LFQ values and join them.
#' 
#' Sometimes, these 1LFQ values are way of, but still better compared to 
#' random imputed numbers. So the idea is, if the 1LFQ values are in at least
#' 3 replicates, we can trust these values and take an average. This is 
#' possible with this function.
#' 
#' @param data_set data set with the already calculated log2 values
#' @param average_function function to averagethe values, for example 'mean' or 'median'
#' @param columns_regexs a vector with regular expressions to search for columns. The order of this vector represents the priority of the values
#' @param min_values a named list with minimum values for each column type. Check examples.
#' @param multiply_values a named list to with multiplicators for each column type. Check examples!
#' @importFrom reshape2 melt dcast
#' @importFrom stats na.omit
#' @importFrom plyr ddply .
calculateAverages2 <- function(data_set, 
                               average_function='mean', 
                               columns_regexs=c('^log2.LFQ'), 
                               min_values=list(A=c(1)),
                               multiply_values=list(A=c(1,1))) {
  experiment <- id <- NULL
  columns_to_average <- lapply(columns_regexs, function(x) grep(x, names(data_set)))
  if(any(length(columns_to_average) != sapply(min_values, length))) {
    stop('Each list element in "min_values" needs the same length as "columns_regexs".')
  }
  if('id' %in% names(data_set)) {
    if(unique(data_set$id) != nrow(data_set)) {
      warning('data_set id column is not unique! Please rename or remove the column.')
    }
  } else {
    data_set$id <- seq(nrow(data_set))
  }
  cols_to_use <- grep(paste(columns_regexs, collapse='|'), names(data_set), value=TRUE)
  melt_data <- suppressMessages(reshape2::melt(data_set[c('id',cols_to_use)], 
                                     id.vars='id',
                                     measure_vars=cols_to_use,
                                     variable.name='original_column'))
  
  melt_data <- cbind(colsplit(melt_data$original_column, '_', c('column','replicate')),
                     melt_data)
  melt_data$experiment <- sub('.*\\.([^\\.]+)', '\\1', melt_data$column)
  melt_data$regex_index <- NA
  for(i in seq(columns_regexs)) {
    regex <- columns_regexs[i]
    matching_rows <- grep(regex, melt_data$original_column)
    melt_data$regex_index[matching_rows] <- i
  }
  # x <- subset(melt_data, id==2 & experiment == 'SDCme')
  # multiply_values <- list(A=c(1,0),B=c(0,1),C=c(2,1))
  averaged_data <- plyr::ddply(melt_data, .(experiment,id), function(x) {
    x <- stats::na.omit(x[order(x$regex_index),])
    x <- x[match(unique(x$replicate), x$replicate),]
    # reg_index <- sapply(seq(min_values[[1]]), function(y) sum(x$regex_index == y))
    reg_index <- sapply(seq(length(min_values[[1]])), function(y) sum(x$regex_index == y))
    value_type <- names(which(unlist(lapply(min_values, function(y) all(reg_index >= y) ))))[1]
    if(!is.na(value_type)) {
      x <- x[rep(seq(x$regex_index), multiply_values[[value_type]][x$regex_index]),]
      c(value_type=value_type,
        average=match.fun(average_function)(x$value, na.rm=TRUE))
    } else {
      c(value_type=NA, average=NA)
    }
  })
  averaged_data$average <- as.numeric(averaged_data$average)
  averages <- reshape2::dcast(averaged_data, id ~ experiment, value.var='average')[-1]
  names(averages) <- paste(average_function, names(averages), sep='_')
  value_types <- reshape2::dcast(averaged_data, id ~ experiment, value.var='value_type')[-1]
  names(value_types) <- paste('value_types', names(value_types), sep='_')
  
#   # first check unique experiments
#   experiments <- unique(sub('.*\\.([^_]+)_\\d+', '\\1', names(data_set[columns_to_average[[1]]])))
#   
#   # now we do for each experiment seperatly
#   
#   # collect for each columns regex the related values
#   for(experiment in experiments) {
#     intensity_values <- list()
#     intensity_counts <- list()
#     for(i in seq(columns_to_average)) {
#       cols <- names(data_set[columns_to_average[[i]]])
#       subdata_set <- data_set[grep(sprintf('\\.%s_', experiment), cols, value=TRUE)]
#       intensity_values[[i]] <- subdata_set
#       intensity_counts[[i]] <- 
#         apply(subdata_set, 1, function(x) sum(!is.na(x)))
#     }
#     intensity_counts <- as.data.frame(intensity_counts)
#     names(intensity_counts) <- letters[1:length(intensity_counts)]
#     
#     min_value_types <- c()
#     average_value <- c()
#     for(line in seq(nrow(intensity_counts))) {
#       min_value_type <- NA
#       for(index in names(min_values)) {
#         min_value <- min_values[[index]]
#         if(all(intensity_counts[line,] >= min_value)) {
#           min_value_type <- index
#           break
#         }
#       }
#       min_value_types <- c(min_value_types, min_value_type)
#     }
#     for(i in seq(columns_to_average)) {
#       cols <- names(data_set[columns_to_average[[i]]])
#       subdata_set <- data_set[grep(sprintf('\\.%s_', experiment), cols, value=TRUE)]
#       intensity_values[[i]] <- subdata_set
#       intensity_values[[i]]$count <- 
#         apply(subdata_set, 1, function(x) sum(!is.na(x)))
#       
#       averages <- c()
#       averages_type <- c()
#       intensity_counts <- as.data.frame(sapply(intensity_values, function(x) x$count))
#       for(i in nrow(data_set)) {
#         row_pattern <- NULL
#         while(is.null(row_pattern)) {
#           
#         }
#         for(min_pattern in names(min_values)) {
#           min_value <- min_values[[min_pattern]]
#           if(all(intensity_counts[i,] >= min_value)) {
#             averages_type <- c(averages_type, min_pattern)
#           }
#           averages_type[i] <- 
#             ifelse(apply(intensity_counts, 1, function(x) all(x >= min_value)),
#                    min_pattern, NA)
#         }      
#       }
# 
#       averages <- apply(as.data.frame(averages, stringsAsFactors=FALSE), 
#                         1, 
#                         function(x) x[which(!is.na(x))[1]])
#       
#     }
  # }
  # test the min values conditions
  # if any of those fit, save the average in place
  # also save the min values condition in a df
  
  
#   jnk <- data.frame()
#   for(cols in columns_to_average) {
#     col_names <- names(data_set[cols])
#     experiments <- sub('.*\\.([^_\\.]+)_\\d+', '\\1', col_names)
#     for(experiment in experiments) {
#       exp_cols <- grep(sprintf('.*\\.%s_\\d+', experiment), col_names)
#       average_name <- paste0('average_', experiment)
#       jnk[[average_name]] <- 
#         apply(data_set[exp_cols], 1, average_function, na.rm=TRUE)
#     }
#   }
  result <- list(averages=averages,
                 value_types=value_types, 
                 columns_used=lapply(columns_regexs, function(x) grep(x, names(data_set), value=TRUE)),
                 columns_regexs=columns_regexs, 
                 min_values=min_values,
                 multiply_values=multiply_values)
  return(result)
}


#' This functions calculates a different averages between replicates within a
#' LFQ data set.
#' 
#' @param data_set a data set with some specific columns. Please read the help!
#' @param lfq_regex a regex to remove the replicate identifier from the column
#' name
#' @export
#' @importFrom stats median
#' @return returns the data frame with the new columns
#' @examples
#' # creating some sample data, similar to MaxQuant LFQ output table
#' set.seed(1234)
#' df <- data.frame(
#'    LFQ.intensity.exp_1=sample(c(rnorm(40,5,1) + 30,rep(NA,10))),
#'    LFQ.intensity.exp_2=sample(c(rnorm(30,5,1) + 30,rep(NA,20))),
#'    LFQ.intensity.exp_3=sample(c(rnorm(35,5,1) + 30,rep(NA,15))),
#'    LFQ.intensity.expb_1=sample(c(rnorm(40,5,1) + 30,rep(NA,10))),
#'    LFQ.intensity.expb_2=sample(c(rnorm(40,5,1) + 30,rep(NA,10))),
#'    LFQ.intensity.expb_3=sample(c(rnorm(40,5,1) + 30,rep(NA,10))))
#' df <- cbind(df,log2=log2(df[grep('^LFQ',names(df))]))
#' imputed_beta_values <- 
#'    imputeBetaRandomNumbersPerColumn(df[grep('^log2.LFQ', names(df))],
#'    20,30,seed=1234)
#' df <- cbind(df,imputed_beta_values$imputed_values)
#' # This sample data looks almost like a LFQ max quant output
#' 
#' # now we can calculate the averages
#' df <- calculateAverages(df)
calculateAverages3 <- function(data_set, lfq_regex='^(.*)_\\d+$') {
  global_regex <- '^log2\\.LFQ\\.intensity\\..*'
  lfq_columns <- unique(gsub(lfq_regex, 
                             '\\1', 
                             grep(global_regex, names(data_set), value=TRUE)))
  if(length(lfq_columns) < 1) {
    stop(sprintf('There are no "%s"-columns in this data set!', 
                 global_regex))
  }
  df <- data.frame(row.names=seq(nrow(data_set)))
  for(col_name in lfq_columns) {
    # we create some column names first
    experiment <- gsub('^log2\\.LFQ\\.intensity\\.(.*)$','\\1', col_name)
    log_col_name <- paste0('^', col_name)
    imp_col_name <- paste0('^imputed\\.', col_name)
    count_col_name <- paste0('value_count_', experiment)
    mean_col_name <- paste0('mean_', experiment)
    
    # we have to figure out, on which columns we want to work on
    log_col_numbers <- 
      grep(paste0(log_col_name, '_\\d+'), colnames(data_set))
    if(length(log_col_numbers) < 1) {
      stop(sprintf('There is no column matching "%s" in the dataset.',
                   log_col_name))
    }
    imp_col_numbers <- 
      grep(paste0(imp_col_name, '_\\d+'), colnames(data_set))
    if(length(imp_col_numbers) < 1) {
      stop(sprintf('There is no column matching "%s" in the dataset.',
                   imp_col_name))
    }
    
    # now we can calculate the values and save into the columns
    # we first calculate the mean for imputed columns
    # we then calc the mean on the log column with na removed
    # the still missing values will be replaced by the mean of the 
    # imputed values
    df[mean_col_name] <- 
      apply(data_set[imp_col_numbers], 1, mean)
    
    # we also count, how many values we measured
    df[count_col_name] <- 
      apply(data_set[log_col_numbers],1,function(x) sum(!is.na(x)))
  }
  return(df)
}

