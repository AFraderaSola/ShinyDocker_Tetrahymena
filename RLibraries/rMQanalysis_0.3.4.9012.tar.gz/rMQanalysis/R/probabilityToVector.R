#' Converting a sequence probability string into a vector
#' 
#' This function is used within the mutateAA function to find the position for
#' the mutation.
#' @export
#' @param x the sequence probability string
#' @examples 
#' probabilityToVector('ARND(.11)K(.79)W(.1)V')
probabilityToVector <- function(x) {
  a <- strsplit(toupper(x), '\\(|\\)')[[1]]
  my_seq <- c()
  my_probs <- c()
  
  for(e in a) {
    if(grepl('[A-Z]+', e)) {
      my_subseq <- unlist(strsplit(e, ''))
      my_seq <- c(my_seq, my_subseq)
      my_probs <- c(my_probs, rep(0, length(my_subseq)))
    } else {
      my_probs[length(my_probs)] <- as.numeric(e)
    }
  }
  names(my_probs) <- my_seq
  return(my_probs)
}