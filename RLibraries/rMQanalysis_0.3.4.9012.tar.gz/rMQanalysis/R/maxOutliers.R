#' This function returns the index of min and max outlier related to upper and 
#' lower limit.
#' @param x The values to check for outliers
#' @param upper_limit The limit for upper range. We check > upper_limit
#' @param lower_limit The limit for lower range. We check < lower_limit
#' @param upper_max The number of indexes to return for upper values
#' @param lower_max The number of indexes to return for lower values
#' @import utils 
#' @export
maxOutliers <- function(x, upper_limit=1, lower_limit=-1, 
                        upper_max=10, lower_max=10) {
  
  outlier <- 
    which(sapply(x, 
                 function(value) {
                   any(value < lower_limit | value > upper_limit)
                 })
    )
  top_outlier <- outlier[c(utils::head(order(x[outlier]), upper_max),
                           utils::tail(order(x[outlier]), lower_max))]
  return(top_outlier)
}
