#' This is a wrapper function to handle a known problem while saving an excel 
#' workbook with xlsx package.
#' 
#' This function handles a know error while saving workbooks from xlsx. 
#' Sometimes the saving step complains about memory issues which can be solved 
#' by restarting the R session. We catch this error and return it as a warning 
#' instead of error and also give the advice to restart.
#' @param wb a workbook object as returned by createWorkbook or loadWorkbook.
#' @param file the path to the file you intend to read or write. Can be an xls or xlsx format.
#' @importFrom xlsx saveWorkbook
#' @export
saveWorkbookMQ <- function(wb, file) {
  tryCatch(xlsx::saveWorkbook(wb=wb, file=file),
           error=function(e) {
             if(grepl('java.lang.OutOfMemoryError: Java heap space',e)) {
               warning('A known problem occured by saving the Excel file and didn\'t saved.\n',
                       'Please restart the R session and try it again.',
                       call.=FALSE)
             } else if(grepl('GC overhead limit exceeded',e)) {
               warning('A known problem occured by saving the Excel file and didn\'t saved.\n',
                       'Please restart the R session and try it again.',
                       call.=FALSE)
             } else {
               warning(sprintf('errormessage: %s\n', e),
                       'A known problem occured by saving the Excel file and didn\'t saved.\n',
                       'Please restart the R session and try it again.\n',
                       'ALSO, PLEASE! Send the errormessage above to m.dejung@imb.de. Thanks!',
                       call.=FALSE)
             }
           })
}