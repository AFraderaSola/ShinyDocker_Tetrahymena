#' Handle MaxQuant output in an easy way
#' 
#' This package is developed to help handling the MaxQuant output from massspec
#' data. It will provide functions to filte datasets by specific columns and
#' determine the number of identified proteins and other stuff.
#' 
#' Some functions are already working like a log function \code{mylog} and a
#' function to filter the dataset by common volumns \code{filterWholeDataset}.
#' 
#' @docType package
#' @name rMQanalysis
NULL