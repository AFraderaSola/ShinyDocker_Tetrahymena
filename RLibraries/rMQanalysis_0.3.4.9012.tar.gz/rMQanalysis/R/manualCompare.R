#' This function creates a comparison data frame based on user input in case of 
#' multiple possible experiments.
#' @param pg This needs to be a MQProteinGroups R6class.
#' @param normalized A logical if we should use standard or normalized columns
#' @param column_prefix The prefix used for log2 transformed columns
#' @importFrom stringr str_trim
#' @export
manualCompare <- function(pg, normalized, column_prefix) {
  for(i in seq_along(pg$getRatioColumnNames(normalized=normalized))) {
    cat(sprintf('% 2d: %s (%s)\n', 
                i, 
                pg$getRatioColumnNames(normalized=normalized)[i],
                rMQanalysis::colnameToLabel(pg$getRatioColumnNames(normalized=normalized)[i])))
  }
  default_compare_string <- switch(length(pg$getRatioColumnNames()),
                                   NULL,'1 2','1 2; 2 3; 1 3',NULL,NULL,NULL)
  # default_compare_string <- '1 2'
  if(is.null(default_compare_string)) {
    cat('Which are the pairs? Use the following syntax to compare 1 vs 2 and 1 vs 3: \n',
        '1 2; 1 3...')
    compare_string <- readline(sprintf('Your pairing: ', default_compare_string))
  } else {
    compare_string <- default_compare_string
  }
  compare_list <- 
    strsplit(stringr::str_trim(unlist(strsplit(compare_string, ';'))), 
             ',| +')
  df <- data.frame()
  ratio_cols <- pg$getRatioColumnNames(normalized=normalized)
  ratio_cols <- paste0(column_prefix, ratio_cols)
  for(x in compare_list) {
    df <- rbind(df, 
                permuteNames(ratio_cols[as.numeric(x)]))
  }
  print(df)
  return(df)
}
