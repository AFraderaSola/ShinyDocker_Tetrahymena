#' Extracting a single page from a pdf as jpg file.
#' 
#' Since the scanner produces pdf files and we need jpg images for the sample submission
#' sheets, I wrote a little function to convert specific pages to jpg.
#' @export
#' @param pdf The path to the pdf file
#' @param page which page to extract
#' @param filename Output file name
extractSampleSubmissionSheet <- 
  function(pdf, page, filename='samplesubmissionsheet.jpg') {
  pdftools::pdf_convert(pdf, 
                        format='jpeg',
                        page=page, 
                        dpi=150, 
                        filenames=filename)
}
