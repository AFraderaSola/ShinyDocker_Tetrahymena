#' A MaxQuant txt file
#' 
#' A class which holds a MaxQuant data file and provides tools for extracting
#' rows and filter the file, etc.
#' 
#' 
#' @section Usage:
#' \preformatted{mq_summary <- MQSummary$new(file_name)
#'
#' mq_summary$getLocation()
#' 
#' mq_summary$getData()
#' }
#'
#' @section Arguments:
#' \code{file_name} A file name of the MaxQuant output file.
#' 
#' \code{logical_filter} A logical vector in the same length as the original data.
#' 
#' \code{identifier} Identifier to search for.
#'
#' \code{column} The column we apply the filter on.
#' 
#' \code{ignore_case} If \code{TRUE}, the filter ignores upper and lower case letters.
#' 
#' @section Methods:
#' \code{$new()} Initialize a MaxQuant File object. The data just get read.
#'   
#' \code{$getLocation()} Returns the original location of the file.
#'
#' \code{$getRowsByIdentifier()} Searches for one or multiple identifiers within 
#' a specific column and returns the matching subset.
#'   
#' \code{$getData()} Returns the filtered subset.
#' 
#' \code{$setFilter()} Possibility to manually filter the file.
#'
#' @name MQSummary
#' @examples
#' pypath = Sys.which('python')
#' if(nchar(pypath) > 0) { 
#'   py = PythonEnv$new(path = pypath, port = 6011)
#'   py$start()
#'   py$running
#'   py$stop(force = TRUE)
#' } else 
#' message("No Python distribution found!")
NULL

#' @export
MQSummary <- R6::R6Class(
  'MQSummary',
  inherit=MQFile,
  public=list(
    initialize=function(file_path=NA) {
      super$readFile(file_path)
      mq_summary <- head(
        private$data, 
        -1 # we skip the Total row
      )
      mq_summary <- mq_summary[!is.na(mq_summary$MS),] # we skip the experiment summaries
      
      private$raw_file <- mq_summary[['Raw.file']]
      private$experiment <- mq_summary[['Experiment']]
      private$fraction <- mq_summary[['Fraction']]
      private$enzyme <- mq_summary[['Enzyme']]
      private$enzyme_mode <- mq_summary[['Enzyme.mode']]
      private$ms_count <- mq_summary[['MS']]
      private$ms_ms_count <- mq_summary[['MS.MS']]
      
      private$label <- mq_summary[grep('Labels', names(mq_summary))]
      known_label <- 
        apply(private$label, 1, function(x) {
          any(sapply(self$common_labels, identical, unname(x)))
        })
      if(!all(known_label)) {
        warning('Not all labels are common: "', 
                paste(private$label[!known_label,], collapse=', '),
                '". Please check the MQ analysis.',
                call.=FALSE)
      }
    },
    
    getExperimentName=function(unique_experiments=FALSE, make_names=FALSE) {
      # my_experiments <- 
      #   ifelse(unique_experiments, 
      #          unique(private$experiment),
      #          private$experiment)
      if(unique_experiments) {
        my_experiments <- unique(private$experiment)
      } else {
        my_experiments <- private$experiment
      }
        
      if(make_names) {
        return(sub('^xyz', '', make.names(paste0('xyz', my_experiments))))
      } else {
        return(my_experiments)
      }
    },
    
    getExperimentType=function() {
      if(length(private$experiment) <= 1) {
        return('FOR')
      } else if(length(private$experiment) == 2) {
        return('FORREV')
      } else {
        return('UNKNOWN')
      }
    },
    getRawFile=function() {
      return(private$raw_file)
    },
    getFraction=function() {
      return(private$fraction)
    },
    getEnzyme=function() {
      return(private$enzyme)
    },
    getEnzymeMode=function() {
      return(private$enzyme_mode)
    },
    getLabelMode=function() {
      if(length(private$label) == 3) {
        return('TRIPPLE')
      } else if(length(private$label) == 2) {
        return('DOUBLE')
      } else if (length(private$label) == 1) {
        return('NONE')
      } else {
        warning('We can not determine the label mode.', call.=FALSE)
      }
    },
    getLabel=function() {
      return(private$label)
    },
    getLabelType=function() {
      if(any(grepl('^Dimeth', unlist(private$label)))) {
        return('DIMETHYL')
      } else if(any(grepl('^Arg|^Lys', private$label))) {
        return('SILAC')
      } else {
        return('NONE')
      }
    },
    
    common_labels=list(
      c(NA),
      c(NA, 'Arg10;Lys8'),
      c(NA, 'Arg6;Lys4', 'Arg10;Lys8'),
      c(NA, 'Lys8'),
      c(NA, 'Lys4', 'Lys8'),
      c('DimethLys0;DimethNter0', 'DimethLys4;DimethNter4'),
      c('DimethLys0;DimethNter0'),
      c('DimethLys4;DimethNter4'),
      c('DimethLys0;DimethNter0', 'DimethLys4;DimethNter4', 'DimethLys8;DimethNter8')
    )
  ),
  private=list(
    location=NULL,
    raw_file=NULL,
    experiment=NULL,
    fraction=NULL,
    enzyme=NULL,
    enzyme_mode=NULL,
    label=NULL,
    ms_count=NULL,
    ms_ms_count=NULL
  )
)


# s <- MQSummary$new('../../cfppdfs/cfppdfs/tests/SILAC_DML_DATA/silac_triple_for/combined/txt/summary.txt')
# s$getExperiment()
# s$getLabelMode()
# s$getLabel()
# 
# s <- MQSummary$new('~/Downloads/summary.txt')
# s$getExperiment()
# s$getLabelMode()
# s$getLabel()
# 
# s <- MQSummary$new('~/Downloads/summary_frac.txt')
# s$getExperiment()
# s$getLabelMode()
# s$getLabel()
