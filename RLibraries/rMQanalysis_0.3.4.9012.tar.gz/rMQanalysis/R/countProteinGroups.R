#' This function counts the protein groups after different filtering steps.
#' @export
#' @param pg The original protein groups data frame
#' @param pg_flt The protein groups data frame after filtering
#' @param pg_ident The protein groups data frame after the filter for identification
#' @import dplyr
#' @import ggplot2
#' @return The functions returns a list with 'data' and 'plot' object.
#' @examples 
#' \dontrun{
#' pg <- read.delim('proteinGroups.txt')
#' pg_flt <- rMQanalysis::filterWholeDataset(pg)
#' pg_ident <- rMQanalysis::filterIdentifiedProteins(pg_flt)
#' pg_ident <- calculateAverages(pg_ident)
#' pg_data <- countProteinGroups(pg, pg_flt, pg_ident)
#' print(pg_data$data)
#' ggsave('protein_counts.pdf', pg_data$plot)
#' print(pg_data$plot)
#' }
countProteinGroups <- function(pg, pg_flt, pg_ident) {
  dataset <- NULL
  value_count_columns <- grep('value_count', names(pg_ident))
  if(length(value_count_columns) < 1) {
    stop('There are no "value_count_" columns within pg_ident data frame.\n',
         'Make sure to create these columns first by using "rMQanalysis::calculateAverages()".',
         call.=FALSE)
  }
  pg_df <- dplyr::bind_rows( # counting proteins after each filtering step
    pg %>% 
      dplyr::group_by_(.dots =  intersect(names(pg), c("species"))) %>% 
      dplyr::summarise(count=n()) %>% 
      dplyr::mutate(dataset='original'),
    pg_flt %>% 
      dplyr::group_by_(.dots =  intersect(names(pg_flt), c("species"))) %>% 
      dplyr::summarise(count=n()) %>% 
      dplyr::mutate(dataset='filtered'),
    pg_ident %>% 
      dplyr::group_by_(.dots =  intersect(names(pg_ident), c("species"))) %>% 
      dplyr::summarise(count=n()) %>% 
      dplyr::mutate(dataset='identified'),
    pg_ident[apply(pg_ident[value_count_columns] >= 2, 1, any),] %>% 
      dplyr::group_by_(.dots =  intersect(names(pg_ident), c("species"))) %>% 
      dplyr::summarise(count=n()) %>% 
      dplyr::mutate(dataset='2 quantified'),
    pg_ident[apply(pg_ident[value_count_columns] >= 3, 1, any),] %>% 
      dplyr::group_by_(.dots =  intersect(names(pg_ident), c("species"))) %>% 
      dplyr::summarise(count=n()) %>% 
      dplyr::mutate(dataset='3 quantified'),
    pg_ident[apply(pg_ident[value_count_columns] >= 4, 1, any),] %>% 
      dplyr::group_by_(.dots =  intersect(names(pg_ident), c("species"))) %>% 
      dplyr::summarise(count=n()) %>% 
      dplyr::mutate(dataset='4 quantified')
  )
  pg_df$dataset <- factor(pg_df$dataset,
                          levels=c('original', 'filtered', 'identified', 
                                   '2 quantified', '3 quantified', '4 quantified'))
  
  y_label_pos <- -max(pg_df$count) * 0.05
  graph_protein_count <- 
    ggplot2::ggplot(pg_df, ggplot2::aes(x=dataset, y=count)) + 
    ggplot2::geom_bar(stat='identity', na.rm=TRUE) +
    ggplot2::scale_y_continuous(limits=c(
      -max(pg_df$count) * 0.07, 
      max(pg_df$count) * 1.1)) +
    ggplot2::geom_text(ggplot2::aes(label=count), y=y_label_pos, 
                       color='black', na.rm=TRUE) +
    ggplot2::ylab('protein groups') + 
    ggplot2::xlab('filtering step') +
    ggplot2::ggtitle('protein groups after each filtering step') +
    rMQanalysis::theme_imb() +
    ggplot2::theme(axis.text.x=ggplot2::element_text(angle=45, hjust=1))
  if('species' %in% names(pg_df)) {
    graph_protein_count <- 
      graph_protein_count + ggplot2::facet_wrap(~ species)
  }
  return(list(data=pg_df, plot=graph_protein_count))
}