#' Calculates averages between replicates and imputes missing values.
#' 
#' This function calculate averages between replicates of specific time points.
#' It additionally imputes values for replicates with missing values. If the 
#' values of these replicates fit a criteria, the imputing happens around the 
#' mean of the other replicates with a distribution calculated from each 
#' timepoint with a \code{logspline} density estimation. If the replicates do 
#' not fit the criteria, we impute around a small values which is calculates 
#' as the quantile of all measured values of the individual time point 
#' (\code{replace_na}). 
#' 
#' About the criteria, we can define groups of columns by a regular expression 
#' (\code{columns_regexs}). The function uses all matching columns of the 
#' first regex and replaces NAs by values from the second regex matching 
#' columns etc. We then can define minimum value counts to calculate an 
#' average (\code{min_values}). Here we provide a list, for example 
#' \code{list(A=c(2,0), B=c(0,3), C=c(1,2))}, which represent 3 different 
#' criterias. If we have at least 2 values of regex 1 \code{OR} 3 values of 
#' regex 2 \code{OR} 1 of regex 1 and 2 of regex 2, we will calculate an 
#' average for this timepoint. \code{A, B} and \code{C} have no special 
#' meaning here, but I will return a data frame (\code{value_types}) to report 
#' which row and column fits whcih \code{min_values} criteria.
#' 
#' We also give the posibility to multyply each regex matching column type 
#' (\code{multiply_values}). For example a setting like 
#' \code{list(A=c(1,0), B=c(1,1), C=c(2,1))} would discard all values from 
#' regex 2 if condition \code{A} in \code{min_values} fits the criteria. If 
#' condition \code{B} would match, we would use the values from regex 1 and 
#' regex 2 together. And as the third option, we would double weight the 
#' values from regex 1. Remember, \code{min_values} has to be a list with 
#' the same length as \code{multiply_values}.
#' 
#' After the averaging, there is also a possibility to fill gaps for 
#' timepoints and we can define a maximal gap width (\code{max_gaps}). 
#' Note: the first and last timepoint will never be filled.
#' 
#' @param data_set data set with the already calculated log2 values
#' @param average_function function to averagethe values, for example 'mean' or 'median'
#' @param columns_regexs a vector with regular expressions to search for columns. The order of this vector represents the priority of the values
#' @param min_values a named list with minimum values for each column type. Check examples.
#' @param multiply_values a named list to with multiplicators for each column type. Check examples!
#' @param replace_na The quantile value to replace NAs
#' @param max_gaps the maximum gab space to impute the averages
#' @param dbg_level the debugging level
#' @importFrom reshape2 melt colsplit
#' @importFrom logspline rlogspline
#' @importFrom zoo na.approx
#' @export
averageAndImputeTimeSeries <- function(data_set, 
                               average_function='mean', 
                               columns_regexs=c('^log2.LFQ'), 
                               min_values=list(A=c(1)),
                               multiply_values=list(A=c(1,1)),
                               replace_na=0.005,
                               max_gaps=1, 
                               dbg_level=1) {
  experiment <- NULL
  mylog('checking some conditions',dbg_level=dbg_level)
  columns_to_average <- lapply(columns_regexs, function(x) grep(x, names(data_set)))
  if(any(length(columns_to_average) != sapply(min_values, length))) {
    stop('Each list element in "min_values" needs the same length as "columns_regexs".')
  }
  if('id' %in% names(data_set)) {
    if(length(unique(data_set$id)) != nrow(data_set)) {
      warning('data_set id column is not unique! Please rename or remove the column.')
    }
  } else {
    data_set$id <- seq(nrow(data_set))
  }
  data_set$myid <- seq(nrow(data_set))
  mylog('calculating logsplines',dbg_level=dbg_level)
  logsplines <- logsplinesPerExperiment(data_set[columns_to_average[[1]]], replace_value=replace_na)
  mylog('preparing data for average calculation',dbg_level=dbg_level)
  cols_to_use <- grep(paste(columns_regexs, collapse='|'), names(data_set), value=TRUE)
  melt_data <- suppressMessages(reshape2::melt(data_set[c('myid',cols_to_use)], 
                                     id.vars='myid',
                                     measure_vars=cols_to_use,
                                     variable.name='original_column'))
  
  melt_data <- cbind(reshape2::colsplit(melt_data$original_column, '_', c('column','replicate')),
                     melt_data)
  melt_data$experiment <- sub('.*\\.([^\\.]+)', '\\1', melt_data$column)
  melt_data$regex_index <- NA
  for(i in seq(columns_regexs)) {
    regex <- columns_regexs[i]
    matching_rows <- grep(regex, melt_data$original_column)
    melt_data$regex_index[matching_rows] <- i
  }
  
  averages_result <- calculateAveragesAndIndividuals(melt_data, min_values, multiply_values, 
                                                     average_function, dbg_level)
  
  if(max_gaps > 0) {
    mylog('filling gaps',dbg_level=dbg_level)
    averages2 <- as.data.frame(t(apply(averages_result$averages, 1, function(x) {
      if(sum(!is.na(x)) > 1) {
        zoo::na.approx(x, na.rm=F, maxgap=max_gaps)
      } else {
        x
      }
    })))
    names(averages2) <- names(averages_result$averages)
    averages_result$averages <- averages2
  }
  
  # impute missing values -----------------------------
  mylog('impute missing values',dbg_level=dbg_level)
  individual_before_impute <- averages_result$individual_data
  for(line in seq(nrow(averages_result$individual_data))) {
    subdf <- averages_result$individual_data[line,]
    subaverage <- averages_result$averages[line,]
    experiments <- unique(sub(".*\\.([^_]+)_\\d+$", '\\1', names(subdf)))
    for(experiment in experiments) {
      cols_ind <- grep(sprintf('.*\\.%s_\\d+$', experiment), names(subdf))
      col_av <- grep(sprintf('^med?i?an_%s$', experiment), names(subaverage))
      na_count <- sum(is.na(subdf[cols_ind]))
      if(na_count > 0) {
        na_value <- ifelse(is.na(subaverage[[col_av]]),
                           logsplines$replace_values[[experiment]],
                           subaverage[[col_av]])
        averages_result$individual_data[line, cols_ind] <- 
          replace(subdf[cols_ind], is.na(subdf[cols_ind]), 
                  na_value + 
                    logspline::rlogspline(na_count, logsplines$logsplines[[experiment]]))
      }
    }
  }
  mylog('returning averaging results',dbg_level=dbg_level)
  result <- list(averages=averages_result$averages,
                 value_types=averages_result$value_types, 
                 columns_used=lapply(columns_regexs, function(x) grep(x, names(data_set), value=TRUE)),
                 columns_regexs=columns_regexs, 
                 min_values=min_values,
                 multiply_values=multiply_values,
                 logsplines=logsplines,
                 individual_data=averages_result$individual_data,
                 before_impute=individual_before_impute)
  return(result)
}


#' Calculating averages and also individual (imputed) values.
#' 
#' This function uses a melted data frame and calculates the average for each 
#' experiment and also returns the individual values because some of them 
#' might be rejected and need to be imputed in later steps. Make sure the 
#' \code{melt_data} has a column called \code{myid} which provides the correct 
#' ids.
#' 
#' @param melt_data a melted data frame produced within averageAndImputeTimeSeries 
#' @param min_values The min_values list from averageAndImputeTimeSeries 
#' @param multiply_values The multiply values list from averageAndImputeTimeSeries 
#' @param average_function An verage function used in averageAndImputeTimeSeries 
#' @param dbg_level A debugging level
#' @importFrom data.table rbindlist
#' @importFrom stats na.omit
#' @importFrom reshape2 dcast
calculateAveragesAndIndividuals <- function(melt_data, min_values, multiply_values, average_function, dbg_level=0) {
  experiment <- myid <- NULL
  mylog('calculateAveragesAndIndividuals starts now',dbg_level=dbg_level)
  
  averaged_data_list <- list()
  individual_data_list <- list()
  line_count <- 0
  experiment_count <- 0
  
  for(this_id in unique(melt_data$myid)) { # expects a myid column
    line_count <- line_count + 1
    if(line_count %% 500 == 0) {
      mylog(sprintf('line %s of %s', line_count, length(unique(melt_data$myid))),
            dbg_level=dbg_level)
    }
    
    submelt_data <- subset(melt_data, myid == this_id)
    
    # creating data frame with one rows of NA values
    my_names <- paste0('imputed.', 
                       unique(interaction(submelt_data$experiment, submelt_data$replicate, sep='_')))
    individual_data_list[[this_id]] <- data.frame(split(rep(NA, length(my_names)), my_names))
    
    
    for(this_experiment in unique(submelt_data$experiment)) {
      experiment_count <- experiment_count + 1
      x <- subset(submelt_data, experiment == this_experiment)
      x <- stats::na.omit(x[order(x$regex_index),])
      x <- x[match(unique(x$replicate), x$replicate),]
      
      reg_index <- sapply(seq(length(min_values[[1]])), function(y) sum(x$regex_index == y))
      value_type <- names(which(unlist(lapply(min_values, function(y) all(reg_index >= y) ))))[1]
      
      if(!is.na(value_type)) { # set calculated values in data frame
        x <- x[rep(seq(x$regex_index), multiply_values[[value_type]][x$regex_index]), ]
        result <- data.frame(myid=this_id, 
                             experiment=this_experiment, 
                             value_type=value_type,
                             average=match.fun(average_function)(x$value, na.rm=TRUE), 
                             stringsAsFactors=FALSE)
        for(line in seq(nrow(x))) {
          experiment_column <- paste0('imputed.', 
                                      unique(interaction(x$experiment[line], x$replicate[line], sep='_')))
          individual_data_list[[this_id]][[experiment_column]] <- x$value[line]
        }
      } else { # set NAs in the data frame
        result <- data.frame(myid=this_id, 
                             experiment=this_experiment, 
                             value_type=NA, 
                             average=NA, 
                             stringsAsFactors=FALSE)
      }
      averaged_data_list[[experiment_count]] <- result
    }
  }
  
  averaged_data <- data.frame(data.table::rbindlist(averaged_data_list))
  individual_data <- data.frame(data.table::rbindlist(individual_data_list))
  
  averages <- dcast(averaged_data, myid ~ experiment, value.var='average')[-1]
  names(averages) <- paste(average_function, names(averages), sep='_')
  
  value_types <- dcast(averaged_data, myid ~ experiment, value.var='value_type')[-1]
  names(value_types) <- paste('value_types', names(value_types), sep='_')
  
  result <- list(averages=averages,
                 value_type=value_types,
                 individual_data=individual_data)
}



#' Calculating logspline and the quantile of each experiment or timepoint.
#' 
#' We filter each experiment to minimum 3 (\code{min_count}) values and 
#' calculate the mean. The next step is to get the distribution of all 
#' measured values and replicates around this distribution and provide this as 
#' a logspline object. This can be used to calculate missing values with the 
#' same distribution as the experiment. Furthermore we also calculate a 
#' quantile (\code{replace_value}) of all measured values which can be used to 
#' impute low values but within a range of logical values.
#' 
#' @return The function returns a list with a list of logsplines and a list of 
#' quantile values.
#' 
#' @param data_set A data set with log2 transformed values, and only the 
#' values, no other columns
#' @param replace_value A quantile used for each experiment for later imputing
#' @param min_count The minimum number of measured values for calculating 
#' logsplines
#' @importFrom logspline logspline
#' @importFrom stats quantile
logsplinesPerExperiment <- function(data_set, replace_value=0.005, min_count=3) {
  count <- NULL
  experiments <- unique(sub(".*\\.([^_]+)_\\d+$", '\\1', names(data_set)))
  my_logsplines <- list()
  my_replace_values <- list()
  for(experiment in experiments) {
    df <- data_set[grep(sprintf('.*\\.%s_\\d+$', experiment), names(data_set))]
    if(replace_value > 1) {
      my_replace_values[[experiment]] <- replace_value
    } else {
      my_replace_values[[experiment]] <- 
        stats::quantile(unlist(df), replace_value, na.rm=TRUE)
    }
    df$count <- apply(df, 1, function(x) sum(!is.na(x)))
    df_subset <- subset(df, count >= min_count, select=-grep('^count$', names(df)))
    means <- apply(df_subset, 1, mean, na.rm=TRUE)
    df_diff <- subset(df, count >= min_count, select=-grep('^count$', names(df))) - means
    my_logsplines[[experiment]] <- logspline::logspline(unlist(df_diff))
  }
  result <- list(
    logsplines=my_logsplines,
    replace_values=my_replace_values
  )
}