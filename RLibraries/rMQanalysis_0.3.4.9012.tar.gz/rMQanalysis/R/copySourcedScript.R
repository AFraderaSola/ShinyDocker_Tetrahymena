#' This function will try to copy the sourced file into the working directory.
#' 
#' The function catches the path and file name of the sourced script and 
#' creates a copy with timestamp in a subdirectory. In case you call the 
#' function in the console, it might give you the revealing error message.
#' @export
#' @param path a path to copy the executed scripts
#' @importFrom utils compareVersion
#' @examples 
#' copySourcedScript()
#' copySourcedScript('.')
copySourcedScript <- function(path='executed_scripts', copy_workdir=TRUE) {
  tryCatch({
    script_name <- sys.frame(1)$ofile
    
    if(utils::compareVersion(paste(unlist(R.Version()[c('major','minor')]), collapse='.'), 
                             '3.2.0') < 0) {
      dir.create(path, showWarnings=FALSE)
    } else {
      if(!dir.exists(path)) dir.create(path)
    }
    
    copy_script_name <- 
      paste0(sub('\\.R', '', basename(script_name)),
             '_',
             format(Sys.time(), '%Y%m%d%H%M%S'),
             '.R')
    
    file.copy(script_name,
              file.path(path,copy_script_name))
    if(copy_workdir & !file.exists(file.path('.', basename(script_name)))) {
      file.copy(script_name,
                file.path('.', basename(script_name)))
    }
  },
  error=function(e) {
    expected_messages <- c('not that many frames on the stack',
                           'a character vector argument expected')
    if(grepl(paste(expected_messages, collapse='|'), e$message)) {
      warning(sprintf('Script was not copied to "%s" directory!\n', path), 
              sprintf('Please use the Source button instead of just running the lines.\n'),
              call.=FALSE)
    } else {
      warning(e)
    }
  })
}

