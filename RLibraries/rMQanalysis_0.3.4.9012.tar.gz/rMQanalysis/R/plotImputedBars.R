#' Function to plot counts of missing a measured values
#' @param imputed_histogram the imputed_histogram object after imputation
#' @export
#' @import dplyr
#' @import ggplot2
plotImputedBars <- function(imputed_histogram) {
  column <- value_type <- value <- NULL
  imputed_bar_df <- 
    imputed_histogram %>% 
    dplyr::group_by(column, value_type) %>% 
    dplyr::summarise(n=length(value))
  graph_imputed_values_bar <- 
    ggplot(imputed_bar_df, aes(column, n, fill=value_type)) +
    geom_bar(stat='identity', position=position_dodge(), na.rm=TRUE) +
    ggtitle('comparison imputed vs. measured') +
    ylab('count') +
    theme_imb() +
    scale_fill_brewer('', palette='Set1') +
    theme(axis.title.x=element_blank(),
          axis.text.x=element_text(angle=60, hjust=1, vjust=1))
  return(graph_imputed_values_bar)
}