#' This function splits the column name into the experiment identifier.
#' 
#' In general we expect to have the experiment barcodes in the MQ settings set as
#' Heavy/Medium/Light or Heavy/Light. In case of tripple labeling, we exctract 
#' the related number to the correct label.
#' @param column_names The Ratio column names
#' @export
colnameToLabel <- function(column_names) {
  sapply(column_names, function(x) {
    my_regex <- '.*Ratio\\.(.)\\.(.)\\.(normalized\\.)?(.*)'
    file_ids <- gsub(my_regex, '\\4', x)
    my_splits <- strsplit(file_ids, '\\.')
    my_length <- unique(sapply(my_splits, length))
    
    # in case different numbers of barcodes per experiment we stop here
    if(length(my_length) != 1) {
      stop(sprintf('something is wrong with your labels: %s. Need to have the same length.', 
                   paste(x, collapse='; ')))
    } 
    
    # get barcode per label
    if(my_length == 3) {
      my_splits <- lapply(my_splits, setNames, c('H','M','L'))
    } else if(my_length == 2) {
      my_splits <- lapply(my_splits, setNames, c('H','L'))
    } else if(my_length == 1) {
      my_splits <- lapply(my_splits, function(x) setNames(rep(x,3), c('H','M','L')))
    }
    
    y <- gsub(my_regex, '\\1', x)
    z <- gsub(my_regex, '\\2', x)
    paste(unique(c(my_splits[[1]][y], my_splits[[1]][z])), collapse='/')
  })
}
