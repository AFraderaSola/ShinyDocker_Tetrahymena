#' MaxQuant parameters class
#' @export
#' @importFrom  R6 R6Class
MQParameters <- R6::R6Class(
  'MQParameters',
  inherit=MQFile,
  public=list(
    initialize=function(file_path=NA) {
      super$readFile(file_path)
      mq_parameters <- 
        setNames(private$data$Value, private$data$Parameter)
      private$mq_version <- unname(mq_parameters['Version'])
      private$re_quantify <- unname(as.logical(mq_parameters['Re-quantify']))
      private$timestamp <- 
        unname(
          as.POSIXlt(mq_parameters['Date of writing'], 
                     format='%m/%d/%Y %H:%M:%S'))
      private$match_between_runs <- 
        unname(as.logical(mq_parameters['Match between runs']))
      private$fasta_file <- 
        gsub('\\\\', '/', strsplit(mq_parameters['Fasta file'], ';')[[1]]) 
    },
    getVersion=function() {
      private$mq_version
    },
    getTimestamp=function() {
      private$timestamp
    },
    getMatchBetweenRuns=function() {
      private$match_between_runs
    },
    getReQuantify=function() {
      private$re_quantify
    },
    getFastaFile=function(alternative_dirs=NULL) {
      if(is.null(alternative_dirs)) {
        return(private$fasta_file)
      } else {
        existing_fasta_files <- c()
        for(fasta in private$fasta_file) {
          possible_fasta_file <- 
            c(private$fasta_file,
              file.path(alternative_dirs, basename(fasta)))
          existing_fasta_file <- file.exists(possible_fasta_file)
          if(any(existing_fasta_file))  {
            existing_fasta_files <- 
              c(existing_fasta_files,
                possible_fasta_file[min(which(existing_fasta_file))])
          } else {
            warning("Could not find fasta file: ",
                    unique(basename(possible_fasta_file)),
                    call.=FALSE)
          }
        }
        return(existing_fasta_files)
      }
    }
  ),
  private=list(
    location=NULL,
    mq_version=NULL,
    fasta_file=NULL,
    re_quantify=NULL,
    timestamp=NULL,
    match_between_runs=NULL
  )
)
