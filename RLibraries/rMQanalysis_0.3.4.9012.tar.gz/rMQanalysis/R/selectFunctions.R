#' Get a data frame of clicked coordinates, grouped into polygons.
#' 
#' We use the grid package and the grid.locator function to identify click 
#' positions within a graph. These can be used to draw the rectangles later
#' with ggplot. 
#' 
#' @param x the x coordinates of the points to plot
#' @param y the y coordinates of the points to plot
#' @param by how many coordonates should be grouped
#' 
#' @return a data frame with the clicked coordinates and the id related to the
#' polygon
#' @export
#' @examples
#' \dontrun{
#' polygons <- clickedCoordinates(data$x, data$y)
#' ggplot() + geom_polygon(data=polygons, 
#'              aes(x=x, y=y, group=id, fill=factor(id)), alpha=.1))
#' }
#' @importFrom grid grid.newpage grid.xaxis grid.yaxis grid.points
#' @importFrom grid pushViewport plotViewport dataViewport grid.locator
clickedCoordinates <- function(x,y, by=4) {
  grid::grid.newpage()
  clicked_coordinates <- data.frame()
  clicked_pos <- FALSE
  grid::pushViewport(grid::plotViewport(c(3,3,3,3)))
  grid::pushViewport(grid::dataViewport(x,y))
  grid::grid.xaxis()
  grid::grid.yaxis()
  grid::grid.points(x,y,size = unit(3,'points'))
  while(typeof(clicked_pos) != typeof(NULL)) {
    clicked_pos <- grid::grid.locator() 
    clicked_coordinates <- rbind(clicked_coordinates,
                                 data.frame(x=as.numeric(clicked_pos$x),
                                            y=as.numeric(clicked_pos$y)))
  }
  clicked_coordinates$id <- rep(seq(1,100),
                                1,
                                nrow(clicked_coordinates),
                                by)
  return(clicked_coordinates)
}

#' Get a vector which points are within an polygon. This polygon is defined by
#' clicking in a plot.
#' 
#' We use the grid package and the grid.locator function to identify click 
#' positions within a graph. Then we use the sp package an the point.in.polygon
#' function to check if the point is within this area.
#' 
#' @param x the x coordinates of the points to plot
#' @param y the y coordinates of the points to plot
#' 
#' @return a logical vector if inside the polygon or not
#' @export
#' @examples
#' \dontrun{
#' data$within_area <- withinSelectedArea(data$x, data$y)
#' subset(data, within_area)
#' }
#' @importFrom sp point.in.polygon
withinSelectedArea <- function(x, y) {
  polygon <- clickedCoordinates(x, y)
  point_in_polygon <- sp::point.in.polygon(x, y, polygon$x, polygon$y)
  return(point_in_polygon == 1)
}


#' Object of type Enriched, which can be used to calculate the number of 
#' enriched or depleted x,y coordinates within a volcano plot.
#' 
#' This function expects the x (fold change) and y values (log2 pvalues) used 
#' within an volcano plot. The c, s0 and p-value is set to a standard and can  
#' be changed. It will calculate, which of the xy pairs are above
#' the curve (enriched) or below (background). It also reports two separate 
#' vectors with the positive or negative enriched xy pairs. Additionally, it 
#' also has the curve data saved, so you can print the curve related to your
#' data points. This will hopefully reduce errors. Use \code{str()} to get 
#' informations of the data structure.
#' 
#' @param x A data frame with x values in column 1 and y values in column 2, or
#' a vector with x values, ex. difference between two conditions
#' @param y Not needed if x is a data frame of length(2). Otherwise, the y 
#' value of the protein groups, so normally the log2 of pvalue
#' @param c Defines the steepness of the curve
#' @param s0 Defines the minimum fold change
#' @param pvalue The p-value where the curve converges
#' @param ... forward values to the enrichment curve, such as linetype or size
#' @export
#' @return A object of class Enriched.
#' @examples
#' # imagine a data frame with log10 transformed p-values and differences 
#' # within two conditions. Here represented with random numbers:
#' set.seed(1234)
#' df <- data.frame(gene_names=c(letters[1:25], LETTERS[1:25]),
#'                  difference=rnorm(50, 0, 10),
#'                  log10_pvalue=abs(rnorm(50,1,5)))
#' check_enriched <- Enriched(df[c(2,3)], c=4, s0=2.5, pvalue=.01)
#' print(check_enriched)
#' df$enriched <- check_enriched$enriched
#' ggplot(df, aes(x=difference, y=log10_pvalue, color=enriched)) + 
#'   geom_point() + plot(check_enriched) + ylim(0,15) + 
#'   geom_text(aes(label=gene_names), vjust=1.2)
Enriched <- function(x, y=NULL, c=1, s0=1, pvalue=0.05, ...) {
  if(class(x) == 'data.frame') {
    if(length(x) == 2) {
      y <- x[[2]]
      x <- x[[1]]
    } else {
      stop('x hast to be a data frame with length 2!')
    }
  }
  results <- list()
  results$curve <- createEnrichmentCurve(c, s0, pvalue, ...)
  results$positive <- ( c / (x - s0) - y + -log10(pvalue) <= 0 & x >= s0 )
  results$negative <- ( c / (-x - s0) - y  + -log10(pvalue) <= 0 & -x >= s0 )
  results$enriched <- results$positive | results$negative
  results$background <- !results$enriched
  class(results) <- append(class(results), 'Enriched')
  return(results)
}
#' Text representation of a Enriched object.
#' 
#' @export
#' @param x The Enriched object
#' @param ... not used
#' @method print Enriched
print.Enriched <- function(x, ...) {
  cat(sprintf('positive: %s\tnegative: %s\tenriched: %s\tbackground: %s\n',
              sum(x$positive),
              sum(x$negative),
              sum(x$enriched),
              sum(x$background)))
}
#' Graphical representation of the enrichment threshold curve.
#' 
#' @export
#' @param x The Enriched object
#' @param ... not used
#' @method plot Enriched
plot.Enriched <- function(x, ...) {
  return(x$curve)
}