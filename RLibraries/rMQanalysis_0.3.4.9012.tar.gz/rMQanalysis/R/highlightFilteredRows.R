#' Highlight protein groups with no standard filter settings
#' 
#' This function uses an excel spread sheet and highlights all rows which do not
#' match our standard filter settings.
#' @export
#' @param sheet The excel spread sheet to modify
#' @param data The dataset to check for filtering
#' @param color The color to highlight the rows
#' @importFrom xlsx getRows getCells Fill CellStyle setCellStyle
highlightFilteredRows <- function(sheet, data, color='#FFD133') {
  rows <- getRows(sheet, 
                  unique(c(which(data$Unique.peptides == 0) + 1, 
                           which(data$Unique.peptides == 1 &
                                   data$Razor...unique.peptides == 1) + 1, 
                           which(data$Potential.contaminant == '+') + 1,
                           which(data$Only.identified.by.site == '+') + 1))
  )
  cells <- getCells(rows)
  fo1 <- Fill(foregroundColor=color)   # create fill object # 1
  cs1 <- CellStyle(excel_wb, fill=fo1)  
  jnk <- sapply(names(cells), function(i) setCellStyle(cells[[i]], cs1))
}
