#' Create a sheet of a data frame to append to excel work book
#' 
#' With the "own_link" parameter you can create links to websites on your own.
#' In general you need an URL like "https://www.uniprot.org/uniprot/?query=%s"
#' and we replace the %s with the first protein ID or, if you provide a separator
#' (link_sep), we concatenate the IDs with this separator (e.g. "+OR+"). Don't 
#' forget to set "link" parameter to "own".
#' 
#' @export
#' @param excel_wb The excel workbook created by xlsx package
#' @param data_frame The data frame you want to attach to the work book
#' @param sheet_name The sheet name for this data frame
#' @param text_regex The regex used to identify the plain text columns
#' @param scientific_regex The regex to define the columns formated in scientific notation
#' @param freeze Define if we freeze the first row and column
#' @param link Creates a link to website like none (default), uniprot, ensembl or "own" link
#' @param own_link a base link to a website
#' @param link_sep a separator between each ID or NULL will only use first ID
#' @importFrom xlsx createSheet DataFormat CellStyle addDataFrame setColumnWidth createFreezePane addHyperlink getRows getCells getCellValue
#' @importFrom stats setNames
#' @importFrom tibble add_column
createSheetOfDF <- function(excel_wb, data_frame, sheet_name,
                            text_regex='^Proteins|^Leading.razor.protein|^Protein.IDs|^Protein.names|^Gene.names|^my_label',
                            scientific_regex='^[I|LFQ\\.i]ntensity', 
                            freeze=TRUE,
                            link=c('uniprot', 'ensembl', 'none', 'own'),
                            own_link='',
                            link_sep=NULL) {
  link <- match.arg(link)
  sheet <- xlsx::createSheet(excel_wb, sheetName=sheet_name)
  text_format_cols <- grep(text_regex, names(data_frame)) + as.numeric(link != 'none')
  scientific_format_cols <- grep(scientific_regex, names(data_frame)) + as.numeric(link != 'none')
  
  text_format = xlsx::CellStyle(excel_wb, dataFormat=xlsx::DataFormat("@"))
  scientific_format <- xlsx::CellStyle(excel_wb, dataFormat=xlsx::DataFormat('0.00E+00'))
  
  format_list <- stats::setNames(
    c(rep(list(text_format), length(text_format_cols)),
      rep(list(scientific_format), length(scientific_format_cols))),
    c(text_format_cols, scientific_format_cols))
  
  headline_style <- xlsx::CellStyle(excel_wb) + 
    xlsx::Alignment(wrapText=TRUE)
  cleanIDs <- function(x) {
    grep('\\|', 
         x, 
         value=TRUE, invert=TRUE)
  }
  link_column <- switch(
    link, 
    uniprot=sprintf(
      'https://www.uniprot.org/uniprot/?query=%s',
      sapply(strsplit(as.character(data_frame$Protein.IDs), ';'), function(x) {
        x <- cleanIDs(x)
        paste(sprintf('(accession:%s)', tolower(x)[1:min(15,length(x))]), 
              collapse='+OR+')
      })),
    ensembl=sprintf(
      'http://www.ensembl.org/Multi/Search/Results?q=%s',
      sapply(strsplit(as.character(data_frame$Protein.IDs), ';'), function(x) {
        x <- cleanIDs(x)
        paste(x[1:min(10,length(x))], collapse='%20OR%20')
      })),
    own=if(is.null(link_sep)) {
      sprintf(
        own_link,
        sapply(strsplit(as.character(data_frame$Protein.IDs), ';'), function(x) {
          x <- cleanIDs(x)
          x[1]
        })
      )} else {
        sprintf(
          own_link,
          sapply(strsplit(as.character(data_frame$Protein.IDs), ';'), function(x) {
            x <- cleanIDs(x)
            paste(x[1:min(15,length(x))], collapse=link_sep)
          })
        )
      },
    none=NULL)
  if(!is.null(link_column)) {
    data_frame <- 
      tibble::add_column(
        data_frame, 
        Link=link_column, 
        .after=2)
  }
  if('Protein.IDs' %in% names(data_frame)) {
    data_frame$Protein.IDs <- 
      ifelse(nchar(as.character(data_frame$Protein.IDs)) > 32500,
             paste(substring(as.character(data_frame$Protein.IDs), 1, 32500), 
                   '... truncated due to excel limiations!'),
             as.character(data_frame$Protein.IDs))
  }
  
  if('Majority.protein.IDs' %in% names(data_frame)) {
    data_frame$Majority.protein.IDs <- 
      ifelse(nchar(as.character(data_frame$Majority.protein.IDs)) > 32500,
             paste(substring(as.character(data_frame$Majority.protein.IDs), 1, 32500), 
                   '... truncated due to excel limiations!'),
             as.character(data_frame$Majority.protein.IDs))
  }
  
  xlsx::addDataFrame(data_frame, sheet, col.names = TRUE, row.names = FALSE, 
                     colStyle = format_list,
                     colnamesStyle=headline_style)
  
  if(!is.null(link_column)) {
    rows <- xlsx::getRows(sheet)
    cells <- xlsx::getCells(rows, colIndex=grep('^Link$', names(data_frame)))
    
    invisible(sapply(cells[-1], function(x) {
      xlsx::addHyperlink(x, xlsx::getCellValue(x))
      # setCellValue(x, 'Uniprot Link')
    }))
  }
  
  xlsx::setColumnWidth(sheet, 1, 25)
  if(freeze) xlsx::createFreezePane(sheet, 2, 2, 2, 2)
  return(sheet)
}
