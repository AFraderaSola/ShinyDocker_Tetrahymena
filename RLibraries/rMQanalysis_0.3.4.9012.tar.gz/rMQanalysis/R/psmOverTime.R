#' Printing PeptideSpectrumMatch over time
#' @param evidence Filename of the evidence file from MQ analysis
#' @param pwiz_stat Filename or data frame of spectrumTableStatistics()
#' @param wrap Wrap facets for each raw file
#' @param ncol the number of columns for wrapping facets
#' @param title provide a title to the image
#' @export
#' @import ggplot2
#' @import dplyr
psmOverTime <- function(evidence, pwiz_stat=NULL, wrap=TRUE, ncol=1,
                               title=NULL) {
  Raw.file <- minute <- MS.MS.Count <- ms1 <- ms2 <- value <- variable <- n <- 
    id <- NULL
  evidence <- read.delim(evidence)
  evidence$minute <- round(evidence$Retention.time)
  evidence_stats <- ddply(evidence, .(Raw.file, minute), summarize,
                          n=length(id),
                          ms2id=sum(MS.MS.Count))
  
  if(!is.null(pwiz_stat)) {
    if(typeof(pwiz_stat) == typeof('')) {
      pwiz <- read.delim(pwiz_stat)
    } else {
      pwiz <- pwiz_stat
    }
    pwiz$Raw.file <- sub('.raw','',pwiz$Raw.file)
    
    pwiz_stats <- 
      pwiz %>%
      dplyr::group_by(Raw.file, minute) %>%
      dplyr::summarise(ms1=sum(ms1),
                       ms2=sum(ms2))
    ms_stats <- merge(pwiz_stats, evidence_stats, all.x=TRUE)
  } else {
    ms_stats <- evidence_stats
  }
  m_stats <- melt(ms_stats, c('Raw.file','minute','n'))
  
  breaks_max <- max(m_stats$n, na.rm=TRUE)
  breaks_steps <- round(breaks_max / 10)
  graph <- ggplot(m_stats, aes(minute, value, color=variable, group=variable)) + 
    geom_line() + ggtitle(title) + ylab('count') +
    geom_point(data=subset(m_stats, variable == 'ms2id'), aes(size=n)) + 
    scale_size_continuous(name="peptides", 
                          breaks=seq(0, breaks_max, breaks_steps)) +
    scale_y_continuous(breaks=seq(0, 500000, 50)) +
    theme_imb()
  if(wrap) graph <- graph + facet_wrap(~ Raw.file, ncol=1, scales='free')
  return(graph)
}
