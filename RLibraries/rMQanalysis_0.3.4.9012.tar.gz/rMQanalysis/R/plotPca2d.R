#' Plotting a two dimensional PCA with ggplot2
#' 
#' @param pairvector A numeric list with pairs oc PC to compare e.g. list(c(1,2))
#' @param pr_comp The result of the prcomp function
#' @param experiment_regex here we define the regex to extract replicate number 
#' and experiment name. First column is used as condition, second as replicate.
#' @param no_legend You can switch of the legend within the plots
#' @export
#' @import ggplot2
#' @importFrom RColorBrewer brewer.pal
#' @examples 
#' sample_data <- data.frame(log2.LFQ.intensity.conA_1=runif(1000),
#'                           log2.LFQ.intensity.conA_2=runif(1000),
#'                           log2.LFQ.intensity.conB_1=runif(1000),
#'                           log2.LFQ.intensity.conB_2=runif(1000))
#' pg_prcomp <- prcomp(t(na.omit(sample_data)), scale.=TRUE)
#' plotPca2d(c(1,2), pg_prcomp)
#' 
#' pairs <- list(c(1,2), c(1,3), c(2,3))
#' pdf(file='all_pca.pdf', width=8, height=8)
#' sapply(pairs, plotPca2d, pg_prcomp)
#' dev.off()
plotPca2d <- 
  function(pairvector, pr_comp, 
           experiment_regex='.*intensity\\.(.*)_(\\d+)',
           no_legend=FALSE) {
    condition <- NULL
    highest_pc <- min(max(unlist(pairvector)), ncol(pr_comp$x))
    x_label <- paste0("PC", pairvector[1])
    y_label <- paste0("PC", pairvector[2])
    
    prcomp_table <- as.data.frame(pr_comp$x[,1:highest_pc])
    prcomp_table$replicate <- as.factor(sub(experiment_regex,'\\2', rownames(prcomp_table)))
    prcomp_table$condition <- as.factor(sub(experiment_regex,'\\1', rownames(prcomp_table)))
    
    pca_graph1_prcomp <- 
      ggplot(prcomp_table, 
             aes_string(x=x_label, 
                        y=y_label, 
                        group='condition')) + 
      geom_point(aes(shape=condition, color=condition)) + theme_imb() + 
      xlab(sprintf('%s - %.1f%%', 
                   x_label, 
                   summary(pr_comp)$importance[2,pairvector[1]] * 100)) +
      ylab(sprintf('%s - %.1f%%', 
                   y_label, 
                   summary(pr_comp)$importance[2,pairvector[2]] * 100)) +
      scale_shape_manual(values=c(rep(c(15,16,17,18,5,6,7,8), each=8))) +
      scale_color_manual(
        values=rep(RColorBrewer::brewer.pal(9, 'Set1')[-6], 
                   ceiling(length(unique(prcomp_table$condition))/8))) +
      geom_text(aes(label=replicate), vjust=1.2)
    if(no_legend) {
      pca_graph1_prcomp <- pca_graph1_prcomp +
        guides(shape=FALSE, color=FALSE)
    }
    return(pca_graph1_prcomp)
  }




