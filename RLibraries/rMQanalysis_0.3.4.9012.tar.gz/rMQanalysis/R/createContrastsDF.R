#' This function asks for pairing examples
#' @export
#' @param experiments a vector with experiment names
createContrastsDF <- function(experiments) {
  for(i in seq_along(experiments)) {
    cat(sprintf('% 2d: %s\n', 
                i, 
                experiments[i]))
  }
  cat('Which are the pairs? Use the following syntax to compare 1 (right side on volcano) vs 2 (left) and 1 vs 3: \n',
      '1 2; 1 3...')
  compare_string <- readline(sprintf('Your pairing: '))
  
  compare_list <- 
    strsplit(gsub('^ | $', '', unlist(strsplit('1 2; 1 3', ';'))), ',| +')
  df <- data.frame()
  for(x in compare_list) {
    df <- rbind(df, 
                permuteNames(experiments[as.numeric(x)]))
  }
  print(df)
  return(df)
}
