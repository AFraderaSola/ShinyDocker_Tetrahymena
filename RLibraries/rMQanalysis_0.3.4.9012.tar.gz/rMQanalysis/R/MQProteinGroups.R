#' @export
MQProteinGroups <- R6::R6Class(
  'MQProteinGroups',
  inherit=MQFile,
  public = list(
    initialize = function(file_path=NA) {
      super$readFile(file_path)
      
    },
    filterData = function(peptides=2, razor_unique=2, unique=1, 
                          reverse=TRUE, contaminants=TRUE, by_site=TRUE,
                          additional_filter=NULL) {
      filter_list <- list(
        peptides = private$data[['Peptides']] >= peptides,
        razor_unique = private$data[['Razor...unique.peptides']] >= razor_unique,
        unique = private$data[['Unique.peptides']] >= unique
      )
      if(reverse) {
        filter_list[['reverse']] <- is.na(private$data[['Reverse']]) | private$data[['Reverse']] == ''
      } else {
        filter_list[['reverse']] <- TRUE
      }
      
      if(contaminants) {
        contaminant_column <- ifelse('Potential.contaminant' %in% names(private$data),
                                     'Potential.contaminant',
                                     'Contaminant')
        filter_list[['contaminants']] <- 
          is.na(private$data[[contaminant_column]]) | 
          private$data[[contaminant_column]] == ''
      } else {
        filter_list[['contaminants']] <- TRUE
      }
      
      if(by_site) {
        filter_list[['only_identified_by_site']] <- 
          is.na(private$data[['Only.identified.by.site']]) | 
          private$data[['Only.identified.by.site']] == ''
      } else {
        filter_list[['only_identified_by_site']] <- TRUE
      }
      
      if(!is.null(additional_filter)) {
        if(is.logical(additional_filter) &
           (length(additional_filter) == nrow(private$data) | 
            length(additional_filter) == 1)) {
          filter_list[['additional_filter']] <- additional_filter
        } else {
          warning('addition filter needs to be logical and the same length as ',
                  'the original data.',
                  call.=FALSE)
        }
      }
      
      private$filters <- filter_list
      super$setFilter(Reduce('&', filter_list))
      invisible(self)
    },
    getFilters = function() {
      return(private$filters)
    },
    getProteins = function(ids, column='Protein.IDs') {
      result <- data.frame()
      for(id in ids) {
        result <- 
          rbind(result, 
                super$getRowsByIdentifier(id, column=column, ignore_case=TRUE))
      }
      return(result)
    },
    
    getFilterCounts = function(mq_summary) {
      # creating some nicer looking names from the ratio columns, just used for
      # plotting
      if(is.null(mq_summary$getExperimentName())) {
        nice_ratio_labels <- sub('Ratio\\.(.)\\.(.)',
                                 '# ratios \\1/\\2',
                                 self$getRatioColumnNames())
        # TODO we should add the barcode from the RawFile in this case
      } else {
        nice_ratio_labels <- sub('Ratio\\.(.)\\.(.)\\.(.*)$', 
                                 '# ratios \\1/\\2\n\\3', 
                                 self$getRatioColumnNames())
      }
      
      
      if(length(mq_summary$getExperimentName())) {
        nice_identified_labels <- 
          paste0('# identified\n', 
                 mq_summary$getExperimentName(unique_experiments=TRUE))
      } else {
        nice_identified_labels <- NULL
      }
      
      # these rows are automatically filter our complete data set! So maybe I have to 
      # move this into a different place to make it more obvious.
      pg_df <- 
        data.frame(
          dataset = factor(c('# original', '# filtered', '# uniqe 1', '# identified'), 
                           levels=c('# original', '# filtered', '# uniqe 1', '# identified', 
                                    nice_ratio_labels, nice_identified_labels)),
          count = c(self$getNRow(), 
                    self$filterData(peptides=1, razor_unique=1, unique=1)$getNRow(), 
                    self$filterData(peptides=2, razor_unique=1, unique=1)$getNRow(), 
                    self$filterData()$getNRow()))
      
      if(length(mq_summary$getExperimentName())) {
        identified_counts <- 
          cbind(dataset=nice_identified_labels,
                as.data.frame(sapply(mq_summary$getExperimentName(make_names=TRUE), function(prefix) {
                  search_regex <- paste0(c('Razor\\.\\.\\.unique\\.peptides\\.',
                                           'Unique\\.peptides\\.'), prefix,
                                         collapse='|')
                  sum(apply(self$getData()[grep(search_regex, names(self$getData()))], 1, function(x) {
                    x[1] >= 2 & x[2] >= 1
                  }))
                }))
          )
        names(identified_counts) <- names(pg_df)
        pg_df <- rbind(pg_df, identified_counts)
      }
      
      # adding the ratio counts for each experiment column
      for(i in 1:length(nice_ratio_labels)) {
        pg_df <- rbind(pg_df,
                       data.frame(dataset=nice_ratio_labels[i],
                                  count=sum(!is.na(self$getData()[[self$getRatioColumnNames()[i]]]))))
      }
      return(pg_df)
    },
    
    getScatterPlotColumnNames = function(mq_summary, normalized=FALSE, column_prefix='') {
      ratio_cols <- self$getRatioColumnNames(normalized=normalized)
      ratio_cols <- paste0(column_prefix, ratio_cols)
      if(length(ratio_cols) %in% c(2,3)) {
        permute_df <- permuteNames(ratio_cols)
      } else if(length(ratio_cols) == 6) {
        permute_df <- rbind(
          permuteNames(ratio_cols[1:3]),
          permuteNames(ratio_cols[4:6]),
          permuteNames(ratio_cols[c(1,4)]),
          permuteNames(ratio_cols[c(2,5)]),
          permuteNames(ratio_cols[c(3,6)])
        )
      } else {
        stop('something went wrong in getScatterPlotColumnsNames.')
      }
      return(permute_df)
    },
    
    getRatioColumnNames = function(normalized=FALSE) {
      base_regex <- 'Ratio\\.[HM]\\.[ML]'
      if(normalized) {
        column_regex <- paste0(base_regex, '\\.normalized')
        exclude_regex <- 'variability|count|type'
      } else {
        column_regex <- base_regex
        exclude_regex <- 'normalized|variability|count|type'
      }
      
      ratio_columns <- 
        names(private$data)[
          grepl(paste0(column_regex, '\\.'), names(private$data)) & 
            !grepl(exclude_regex, names(private$data))
          ]
      if(length(ratio_columns) == 0) {
        ratio_columns <- 
          names(private$data)[
            grepl(column_regex, names(private$data)) & 
              !grepl(exclude_regex, names(private$data))
            ]
      }
      if(length(ratio_columns) == 0) {
        stop('It looks like there are no ratio columns in the proteinGroups file.',
             'Did you forgot to select a label in MaxQuant?',
             call.=FALSE)
      }
      return(ratio_columns)
    },
    
    getLFQColumnNames = function() {
      column_regex <- '^LFQ\\.intensity\\.'
      ratio_columns <- grep(column_regex, names(private$data), value=TRUE)
      if(length(ratio_columns) == 0) {
        ratio_columns <- NULL
      }
      return(ratio_columns)
    },
    
    getLog2Intensities = function() {
      column_regex <- '^Intensity\\.(.)$'
      intensity_columns <- self$getData()[grep(column_regex, names(private$data))]
      intensity_columns[intensity_columns == 0] <- NA
      return(log2(intensity_columns))
    },
    
    getAbundanceData = function(label_column='plot_label') {
      column_regex <- '^Protein.IDs$|^Intensity$|Intensity\\.[^HML]\\.?'
      column_regex <- paste0(column_regex, '|', label_column)
      intensity_columns <- self$getData()[grep(column_regex, names(private$data))]
      intensity_columns[intensity_columns == 0] <- NA
      return(intensity_columns)
    }
  ),
  private = list(
    filters = list()
  )
)
