#' A MaxQuant txt file
#' 
#' A class which holds a MaxQuant data file and provides tools for extracting
#' rows and filter the file, etc.
#' 
#' 
#' @section Usage:
#' \preformatted{mqf <- MQFile$new(file_name)
#'
#' mqf$getLocation()
#' 
#' mqf$getData()
#' }
#'
#' @section Arguments:
#' \code{file_name} A file name of the MaxQuant output file.
#' 
#' \code{logical_filter} A logical vector in the same length as the original data.
#' 
#' \code{identifier} Identifier to search for.
#'
#' \code{column} The column we apply the filter on.
#' 
#' \code{ignore_case} If \code{TRUE}, the filter ignores upper and lower case letters.
#' 
#' @section Methods:
#' \code{$new()} Initialize a MaxQuant File object. The data just get read.
#'   
#' \code{$getLocation()} Returns the original location of the file.
#'
#' \code{$getRowsByIdentifier()} Searches for one or multiple identifiers within 
#' a specific column and returns the matching subset.
#'   
#' \code{$getData()} Returns the filtered subset.
#' 
#' \code{$setFilter()} Possibility to manually filter the file.
#'
#' @name MQFile
#' @examples
#' pypath = Sys.which('python')
#' if(nchar(pypath) > 0) { 
#'   py = PythonEnv$new(path = pypath, port = 6011)
#'   py$start()
#'   py$running
#'   py$stop(force = TRUE)
#' } else 
#' message("No Python distribution found!")
NULL


MQFile <- R6::R6Class(
  'MQFile',
  public=list(
    readFile = function(file_name) {
      if(!file.exists(file_name)) {
        warning(sprintf('File "%s" does not exist.',
                        file_name),
                call.=FALSE)
        return(FALSE)
      }
      special_columns <- c(
        Experiment='character' # in the summary file needs to be character
        )
      private$location <- normalizePath(file_name)
      jnk <- read.delim(file_name, stringsAsFactors=FALSE, nrows=1)
      existing_special_columns <- 
        special_columns[names(special_columns) %in% names(jnk)]
      private$data <- read.delim(file_name, 
                                 stringsAsFactors=FALSE,
                                 colClasses=existing_special_columns)
      # return(mq_file)
    },
    getLocation = function() {
      private$location
    },
    getRowsByIdentifier = function(identifier, column, ignore_case=F) {
      if(!column %in% names(private$data)) {
        warning(sprintf(
          'File "%s" has no column called "%s".\n',
          private$location, 
          column
        ),
        call.=FALSE)
        return(NULL)
      }
      search_string <- paste0(c('^', ';', '^', ';'),
                              rep(identifier, each=4),
                              c('$','$',';',';'), 
                              collapse='|')
      private$data[
        private$filter & 
          grepl(search_string, private$data[[column]], ignore.case=ignore_case),
        ]
      
    },
    getData = function() {
      private$data[private$filter,]
    },
    getFilter = function() {
      return(private$filter)
    },
    setFilter = function(logical_filter) {
      if(is.logical(logical_filter) & 
         (length(logical_filter) == nrow(private$data) |
          length(logical_filter) == 1)) {
        private$filter <- logical_filter
      }
      invisible(self)
    },
    getNRow = function(filtered=TRUE) {
      if(filtered) {
        nrow(private$data[private$filter,])
      } else {
        nrow(private$data)
      }
    }
  ),
  private = list(
    location=NULL,
    data=NULL,
    filter=TRUE
  )
)