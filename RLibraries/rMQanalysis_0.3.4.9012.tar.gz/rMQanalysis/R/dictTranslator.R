#' Function to translate strings into longer names or other names. Also to give
#' groups of string the same string.
#' 
#' Have a look into the examples. This function translate strings into an 
#' abbreviation or longer strings. Can be used to name clear timepoints or 
#' rename experiments etc.
#' @param x a vector to translate
#' @param dict a list with the translations
#' @export
#' @examples 
#' a <- list(embryo=c('00h','01h','02h','03h','04h','05h','06h','08h',
#'                    '10h','12h','14h','16h','18h','20h'),
#'           larvae=c('L1','L2','L3e','L3l'),
#'           pupae=c('p1','p2','p3','p4','p5'),
#'           `longer translations need backticks`=c('vm','m','vf','f'))
#' b <- c('L3l', 'L1', '00h', 'vm')
#' dictTranslator(b, a)
#' d <- c('L3l','not in list')
#' dictTranslator(d, a)
dictTranslator <- function(x, dict) {
  dict <- unlist(dict)
  result <- sub('\\d+$', '', names(dict)[match(x, dict)])
  ifelse(is.na(result),
         { warning('NAs are introduced!', call.=FALSE) 
         NA },
         result)
}