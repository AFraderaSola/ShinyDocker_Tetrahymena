#' Plotting multiple PCA plots on a single page.
#' @export
#' @param species A vector with species names used inside the prcomp_list
#' @param prcomp_list A list with principal componant analysis
#' @param plot_graph If you want to plot the graph for each species
#' @importFrom gridExtra arrangeGrob
#' @importFrom grid grid.newpage grid.draw
#' @examples 
#' \dontrun{
#' prcomp_list <- 
#' lapply(unique(pg_ident$species), function(x) {
#'   filter(pg_quant, species == x) %>%
#'     select(matches(pca_column_regex)) %>%
#'     na.omit(.) %>%
#'     t(.) %>%
#'     prcomp(., scale.=TRUE)
#' })
#' 
#' names(prcomp_list) <- unique(pg_ident$species)
#' 
#' pca_plots <- lapply(names(prcomp_list), multiPCAPlot, prcomp_list=prcomp_list)
#' 
#' pdf(file='PCAs.pdf', width=11.69, height=8.27)
#' jnk <- sapply(pca_plots, function(x) {
#'   grid.newpage()
#'   grid.draw(x)
#' })
#' jnk <- dev.off()
#' }
multiPCAPlot <- function(species, prcomp_list, plot_graph=FALSE) {
  pairs <- list(c(1,2), c(1,3), c(2,3), c(1,4), c(2,4), c(3,4))
  jnk1 <- rMQanalysis::plotPca2d(c(1,2), prcomp_list[[species]])
  graph_legend <- rMQanalysis::getLegend(jnk1)
  jnk3 <- lapply(pairs, rMQanalysis::plotPca2d, prcomp_list[[species]], no_legend=TRUE)
  jnk4 <- arrangeGrob(grobs=jnk3, ncol=3)
  # jnk4 <- do.call('arrangeGrob', c(jnk3, ncol=3))
  jnk5 <- gridExtra::arrangeGrob(jnk4, graph_legend,
                      ncol=2, widths=c(10,1),
                      top=sprintf('%s principal component analysis',
                                  species))
  if(plot_graph) {
    grid::grid.newpage()
    grid::grid.draw(jnk5)
  }
  return(jnk5)
}



#' A helper function to extract a legend from a plot so you can reuse it later
#' @export
#' @param a.gplot A plot object with legend
#' @examples 
#' \dontrun{
#' pairs <- list(c(1,2), c(1,3), c(2,3), c(1,4), c(2,4), c(3,4))
#' jnk1 <- rMQanalysis::plotPca2d(c(1,2), prcomp_list[[species]])
#' graph_legend <- rMQanalysis::getLegend(jnk1)
#' jnk3 <- lapply(pairs, rMQanalysis::plotPca2d, prcomp_list[[species]], no_legend=TRUE)
#' jnk4 <- arrangeGrob(grobs=jnk3, ncol=3)
#' jnk5 <- arrangeGrob(jnk4, graph_legend,
#'                     ncol=2, widths=c(10,1),
#'                     top=sprintf('%s principal component analysis',
#'                                 species))
#' grid.newpage()
#' grid.draw(jnk5)
#' }
getLegend <- function(a.gplot){
  tmp <- ggplot_gtable(ggplot_build(a.gplot))
  leg <- which(sapply(tmp$grobs, function(x) x$name) == "guide-box")
  legend <- tmp$grobs[[leg]]
  return(legend)
}



